memory.limit(size=56000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(gbm)
library(sf)
library(sp)
library(cowplot)
library(automap)
library(ggplot2)
library(grid)
library(gridExtra)
# A function that fits the BRT model ('gbm.step' from dismo package) on pre-defined folds, and saves outputs ####
brt_blocks <- function(data = datcombo, pred.stack = pred_ontario, seed = 1222, pred.variables ,output.folder, blocks=NULL, keep.out = TRUE, tc=3,lr=0.001,bf=0.5, save.points.shp=FALSE){ 
  # Arguments for this function
  ## data: data.frame object containing data for model fitting
  ## pred.stack: the raster stack/brick used as prediction dataset
  ## pred.variables: a character vector giving the names of predictor variables that will be included in BRT models
  ## blocks: object resulting from 'spatialBlocks' function that contains classification of sample points into folds
  ## output.folder: path to output folder (if folder does not exist it is created)
  ## keep.out: logical, whether to keep the output in the workspace. both blocks object and the brt output are automatically saved in the output folder regardless
  ## tc: BRT tree complexity
  ## lr: BRT learning rate
  ## bf: BRT bag fraction
  ## save.points.shp: logical, whether to save survey points as a shapefile in output folder
  
  # fit BRT models using pre-determined folds for CV
  if (is.null(blocks)){
    folds<-NULL
    n.folds<-10
  }
  
  else {
    folds<-blocks$foldID
    n.folds<-blocks$k
  }
  
  x1 <-
    try(brt <-
          gbm.step(
            datcombo,
            gbm.y = "ABUND",
            gbm.x = pred.variables,
            fold.vector = folds,
            n.folds = n.folds,
            family = "poisson",
            tree.complexity = tc,
            learning.rate = lr,
            bag.fraction = bf,
            offset = datcombo$logoffset,
            site.weights = datcombo$wt,
            keep.fold.models = T,
            keep.fold.fit = T
          ))
  
  if(class(x1)=="NULL"){#retry models that didn't converge with smaller learning rate
    x1 <-
      try(brt <-
            gbm.step(
              datcombo,
              gbm.y = "ABUND",
              gbm.x = pred.variables,
              fold.vector = folds,
              n.folds = n.folds,
              family = "poisson",
              tree.complexity = tc,
              learning.rate = lr/10,
              bag.fraction = bf,
              offset = datcombo$logoffset,
              site.weights = datcombo$wt,
              keep.fold.models = T,
              keep.fold.fit = T
            ))
  }
  
  if(class(x1)=="NULL"){#retry models that didn't converge with smaller learning rate
    x1 <-
      try(brt <-
            gbm.step(
              datcombo,
              gbm.y = "ABUND",
              gbm.x = pred.variables,
              fold.vector = folds,
              n.folds = n.folds,
              family = "poisson",
              tree.complexity = tc,
              learning.rate = lr/100,
              bag.fraction = bf,
              offset = datcombo$logoffset,
              site.weights = datcombo$wt,
              keep.fold.models = T,
              keep.fold.fit = T
            ))
  }
  
  if(class(x1)=="NULL"){
    stop("Restart model with even smaller learning rate, or other predictors!")
  }
  
  # Define/create folders for storing outputs
  if (class(x1) != "try-error") {
    z <- output.folder
    
    if (file.exists(z) == FALSE) {
      dir.create(z)
    }
    
    if (is.null(blocks)){
      save(brt, file = paste(z, speclist[j], "brtAB.R", sep = ""))
    }
    
    else {
      save(blocks, file = paste(z, speclist[j], "blocks.R", sep = ""))
      save(brt, file = paste(z, speclist[j], "brtAB.R", sep = ""))
    }  
    
    
    ## Model evaluation
    varimp <- as.data.frame(brt$contributions)
    write.csv(varimp, file = paste(z, speclist[j], "varimp.csv", sep = ""))
    cvstats <- t(as.data.frame(brt$cv.statistics))
    write.csv(cvstats, file = paste(z, speclist[j], "cvstats.csv", sep =
                                      ""))
    pdf(paste(z, speclist[j], "_plot.pdf", sep = ""))
    gbm.plot(
      brt,
      n.plots = length(pred.variables),
      smooth = TRUE,
      plot.layout = c(3, 3),
      common.scale = T
    )
    dev.off()
    pdf(paste(z, speclist[j], "_plot.var-scale.pdf", sep = ""))
    gbm.plot(
      brt,
      n.plots = length(pred.variables),
      smooth = TRUE,
      plot.layout = c(3, 3),
      common.scale = F,
      write.title = F
    )
    dev.off()
    
    
    ## Model prediction
    
    rast <-
      predict(pred.stack,
              brt,
              type = "response",
              n.trees = brt$n.trees)
    writeRaster(
      rast,
      filename = paste(z, speclist[j], "_pred1km", sep = ""),
      format = "GTiff",
      overwrite = TRUE
    )
    
    data_sp <-SpatialPointsDataFrame(coords = data[, c("X","Y")], data = data, proj4string = LCC)
    png(paste(z, speclist[j], "_pred1km.png", sep = ""))
    plot(rast, zlim = c(0, 1))
    points(data_sp$X, data_sp$Y, cex = 0.05)
    dev.off()
    
    if(save.points.shp==T){
      writeOGR(
        data_sp,
        dsn = paste(z, "surveypoints.shp", sep = ""),
        layer = "data_sp",
        driver = "ESRI Shapefile"
      )
    }
    
    if(keep.out==T) {return(brt)}
  }
}


#load data and prepare objects ####
load("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/pointswithdataApril5_D.RData")

#load raster brick as prediction stack. This raster brick can be
#omitted in favour of just using the point count data to create 
#training and test data folds for cross validatio, but will be
#necessary for predicting Wood Thrush distribution across the entire
#study area. Names in the predictor stack have to be exactly the 
#same as the variables used in the BRTs.

pred_newbrunswick<-brick("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/pred_newbrunswick.grd")
pred_novascotia<-brick("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/pred_novascotia.grd")
pred_quebec<-brick("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/pred_quebec.grd")
pred_ontario<-brick("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/pred_ontario.grd")
pred_landis_stlLowlands<-brick("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/pred_landis_stlLowlands.grd")

LAEA<-CRS("+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Including Exceedance Among Predictors - Full Model                 #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedE#start with observations where exceedance values are complete

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# Full model ####
# list variables for full model
pred.variables<-c("barren.150m",
                  "conif.150m",
                  "cult.150m",
                  "decid.150m",
                  "grassland.150m",
                  "mixed.150m",
                  "orchard.150m",
                  "shrub.150m",
                  "urban.150m",
                  "water.150m",
                  "wetland.150m",
                  "barren.250m",
                  "conif.250m",
                  "cult.250m",
                  "decid.250m",
                  "grassland.250m",
                  "mixed.250m",
                  "orchard.250m",
                  "shrub.250m",
                  "urban.250m",
                  "water.250m",
                  "wetland.250m", 
                  "barren.1000m",
                  "conif.1000m",
                  "cult.1000m",
                  "decid.1000m",
                  "grassland.1000m",
                  "mixed.1000m",
                  "orchard.1000m",
                  "shrub.1000m",
                  "urban.1000m",
                  "water.1000m",
                  "wetland.1000m", 
                  "barren.2000m",
                  "conif.2000m",
                  "cult.2000m",
                  "decid.2000m",
                  "grassland.2000m",
                  "mixed.2000m",
                  "orchard.2000m",
                  "shrub.2000m",
                  "urban.2000m",
                  "water.2000m",
                  "wetland.2000m",
                  "Structure_Biomass_Branch.local",              
                  "Structure_Biomass_Foliage.local",             
                  "Structure_Biomass_StemBark.local",            
                  "Structure_Biomass_StemWood.local",            
                  "Structure_Biomass_TotalDead.local",  
                  "Structure_Stand_Age.local",
                  "Structure_Biomass_TotalLiveAboveGround.local",
                  "Structure_Biomass_Branch.250m",              
                  "Structure_Biomass_Foliage.250m",             
                  "Structure_Biomass_StemBark.250m",            
                  "Structure_Biomass_StemWood.250m",            
                  "Structure_Biomass_TotalDead.250m",  
                  "Structure_Stand_Age.250m",
                  "Structure_Biomass_TotalLiveAboveGround.250m",
                  "Structure_Biomass_Branch.1000m",              
                  "Structure_Biomass_Foliage.1000m",             
                  "Structure_Biomass_StemBark.1000m",            
                  "Structure_Biomass_StemWood.1000m",            
                  "Structure_Biomass_TotalDead.1000m",  
                  "Structure_Stand_Age.1000m",
                  "Structure_Biomass_TotalLiveAboveGround.1000m",
                  "Structure_Biomass_Branch.2000m",              
                  "Structure_Biomass_Foliage.2000m",             
                  "Structure_Biomass_StemBark.2000m",            
                  "Structure_Biomass_StemWood.2000m",            
                  "Structure_Biomass_TotalDead.2000m",  
                  "Structure_Stand_Age.2000m",
                  "Structure_Biomass_TotalLiveAboveGround.2000m",
                  "Roadside150",
                  "MajorRoad150",
                  "elev",
                  "slope",
                  "TPI",
                  "TRI",
                  "swamp.150m","swamp.250m","swamp.1000m","swamp.2000m",
                  "exceedance.05",
                  "exceedance.20")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind <- which(names(pred_ontario) %in% pred.variables)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind]])
end_time <- Sys.time()
end_time - start_time#Time difference of 19.52071 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
                      speciesData = datcombo_sp,
                      species = "OCCU",
                      rasterLayer = NULL,#pred_abs_2011[[1]],
                      iteration = 250,
                      theRange = sp.auto.arr1$range,
                      selection = "random",
                      maskBySpecies = FALSE
  )
end_time <- Sys.time()
end_time - start_time#Time difference of 53.41356 mins

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt1<- brt_blocks(data=datcombo,pred.variables = pred.variables, output.folder = "3_BRT_outputs/Version 1 models/with exceedance/full_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
end_time<-Sys.time()
end_time-start_time
#Time difference of 2.513349 hours

save(brt1, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/brt1.RData")

load("3_BRT_outputs/Version 1 models/with exceedance/full_model/spautoarr1andblocks.RData")
load("3_BRT_outputs/Version 1 models/with exceedance/full_model/brt1.RData")

rast <-
  predict(pred_novascotia,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/with exceedance/full_model/pred_250m_stlLowlands.tif", overwrite=TRUE)
#Exceedance doesn't seem to be important in predicting Wood Thrush abundance among the 
#points where exceedance data are available

############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - Full Model                  #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedD#start with observations where exceedance values are complete

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# Full model ####
# list variables for full model
pred.variables2<-c("barren.150m",
                  "conif.150m",
                  "cult.150m",
                  "decid.150m",
                  "grassland.150m",
                  "mixed.150m",
                  "orchard.150m",
                  "shrub.150m",
                  "urban.150m",
                  "water.150m",
                  "wetland.150m",
                  "barren.250m",
                  "conif.250m",
                  "cult.250m",
                  "decid.250m",
                  "grassland.250m",
                  "mixed.250m",
                  "orchard.250m",
                  "shrub.250m",
                  "urban.250m",
                  "water.250m",
                  "wetland.250m", 
                  "barren.1000m",
                  "conif.1000m",
                  "cult.1000m",
                  "decid.1000m",
                  "grassland.1000m",
                  "mixed.1000m",
                  "orchard.1000m",
                  "shrub.1000m",
                  "urban.1000m",
                  "water.1000m",
                  "wetland.1000m", 
                  "barren.2000m",
                  "conif.2000m",
                  "cult.2000m",
                  "decid.2000m",
                  "grassland.2000m",
                  "mixed.2000m",
                  "orchard.2000m",
                  "shrub.2000m",
                  "urban.2000m",
                  "water.2000m",
                  "wetland.2000m",
                  "Structure_Biomass_Branch.local",              
                  "Structure_Biomass_Foliage.local",             
                  "Structure_Biomass_StemBark.local",            
                  "Structure_Biomass_StemWood.local",            
                  "Structure_Biomass_TotalDead.local",  
                  "Structure_Stand_Age.local",
                  "Structure_Biomass_TotalLiveAboveGround.local",
                  "Structure_Biomass_Branch.250m",              
                  "Structure_Biomass_Foliage.250m",             
                  "Structure_Biomass_StemBark.250m",            
                  "Structure_Biomass_StemWood.250m",            
                  "Structure_Biomass_TotalDead.250m",  
                  "Structure_Stand_Age.250m",
                  "Structure_Biomass_TotalLiveAboveGround.250m",
                  "Structure_Biomass_Branch.1000m",              
                  "Structure_Biomass_Foliage.1000m",             
                  "Structure_Biomass_StemBark.1000m",            
                  "Structure_Biomass_StemWood.1000m",            
                  "Structure_Biomass_TotalDead.1000m",  
                  "Structure_Stand_Age.1000m",
                  "Structure_Biomass_TotalLiveAboveGround.1000m",
                  "Structure_Biomass_Branch.2000m",              
                  "Structure_Biomass_Foliage.2000m",             
                  "Structure_Biomass_StemBark.2000m",            
                  "Structure_Biomass_StemWood.2000m",            
                  "Structure_Biomass_TotalDead.2000m",  
                  "Structure_Stand_Age.2000m",
                  "Structure_Biomass_TotalLiveAboveGround.2000m",
                  "Roadside150",
                  "MajorRoad150",
                  "elev",
                  "slope",
                  "TPI",
                  "TRI",
                  "swamp.150m","swamp.250m","swamp.1000m","swamp.2000m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind2 <- which(names(pred_ontario) %in% pred.variables2)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind2]])
end_time <- Sys.time()
end_time - start_time#Time difference of 19.0394 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 1.593549 hours

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt1<- brt_blocks(data=datcombo, pred.variables = pred.variables2, output.folder = "3_BRT_outputs/Version 1 models/without exceedance/full_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
end_time<-Sys.time()
end_time-start_time
#Time difference of 13.31805 hours

save(brt1, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/brt1.RData")

#load("3_BRT_outputs/Version 1 models/without exceedance/full_model/spautoarr1andblocks.RData")
#load("3_BRT_outputs/Version 1 models/without exceedance/full_model/brt1.RData")

rast <-
  predict(pred_novascotia,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt1,
          type = "response",
          n.trees = brt1$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/without exceedance/full_model/pred_250m_stlLowlands.tif", overwrite=TRUE)


############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - Local Model                 #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedD

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# Local model ####
# list variables for local model
pred.variables3<-c("barren.150m",
                   "conif.150m",
                   "cult.150m",
                   "decid.150m",
                   "grassland.150m",
                   "mixed.150m",
                   "orchard.150m",
                   "shrub.150m",
                   "urban.150m",
                   "water.150m",
                   "wetland.150m",
                   "Structure_Biomass_Branch.local",              
                   "Structure_Biomass_Foliage.local",             
                   "Structure_Biomass_StemBark.local",            
                   "Structure_Biomass_StemWood.local",            
                   "Structure_Biomass_TotalDead.local",  
                   "Structure_Stand_Age.local",
                   "Structure_Biomass_TotalLiveAboveGround.local",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.150m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind3 <- which(names(pred_ontario) %in% pred.variables3)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind3]])
end_time <- Sys.time()
end_time - start_time#Time difference of 3.126103 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 1.593549 hours

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt2<- brt_blocks(data=datcombo, pred.variables = pred.variables3, output.folder = "3_BRT_outputs/Version 1 models/without exceedance/local_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
end_time<-Sys.time()
end_time-start_time
#mean total deviance = 5.204 
#mean residual deviance = 3.433 
#estimated cv deviance = 3.967 ; se = 1.172 
#training data correlation = 0.466 
#cv correlation =  0.183 ; se = 0.051 
#elapsed time -  0.07 minutes 
#Time difference of 4.474358 hours

save(brt2, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/brt2.RData")

load("3_BRT_outputs/Version 1 models/without exceedance/local_model/spautoarr1andblocks.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/local_model/brt2.RData")

rast <-
  predict(pred_novascotia,
          brt2,
          type = "response",
          n.trees = brt2$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt2,
          type = "response",
          n.trees = brt2$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt2,
          type = "response",
          n.trees = brt2$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt2,
          type = "response",
          n.trees = brt2$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt2,
          type = "response",
          n.trees = brt2$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/without exceedance/local_model/pred_250m_stlLowlands.tif", overwrite=TRUE)




############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - 250 m Model                 #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedD

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# 250-m model ####
# list variables for 250-m model
pred.variables4<-c("barren.250m",
                   "conif.250m",
                   "cult.250m",
                   "decid.250m",
                   "grassland.250m",
                   "mixed.250m",
                   "orchard.250m",
                   "shrub.250m",
                   "urban.250m",
                   "water.250m",
                   "wetland.250m",
                   "Structure_Biomass_Branch.250m",              
                   "Structure_Biomass_Foliage.250m",             
                   "Structure_Biomass_StemBark.250m",            
                   "Structure_Biomass_StemWood.250m",            
                   "Structure_Biomass_TotalDead.250m",  
                   "Structure_Stand_Age.250m",
                   "Structure_Biomass_TotalLiveAboveGround.250m",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.250m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind4 <- which(names(pred_ontario) %in% pred.variables4)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind4]])
end_time <- Sys.time()
end_time - start_time#Time difference of 8.912223 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 1.676836 hours

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt3<- brt_blocks(data=datcombo, pred.variables = pred.variables4, output.folder = "3_BRT_outputs/Version 1 models/without exceedance/250m_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
end_time<-Sys.time()
end_time-start_time
#mean total deviance = 5.204 
#mean residual deviance = 3.448 
#estimated cv deviance = 4.093 ; se = 1.429 
#training data correlation = 0.455 
#cv correlation =  0.194 ; se = 0.051
#elapsed time -  0.04 minutes 
save(brt3, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/brt3.RData")

load("3_BRT_outputs/Version 1 models/without exceedance/250m_model/spautoarr1andblocks.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/250m_model/brt3.RData")

rast <-
  predict(pred_novascotia,
          brt3,
          type = "response",
          n.trees = brt3$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt3,
          type = "response",
          n.trees = brt3$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt3,
          type = "response",
          n.trees = brt3$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt3,
          type = "response",
          n.trees = brt3$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt3,
          type = "response",
          n.trees = brt3$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/without exceedance/250m_model/pred_250m_stlLowlands.tif", overwrite=TRUE)



############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - 1000 m Model                #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedD

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# 1000-m model ####
# list variables for 1000-m model
pred.variables5<-c("barren.1000m",
                   "conif.1000m",
                   "cult.1000m",
                   "decid.1000m",
                   "grassland.1000m",
                   "mixed.1000m",
                   "orchard.1000m",
                   "shrub.1000m",
                   "urban.1000m",
                   "water.1000m",
                   "wetland.1000m",
                   "Structure_Biomass_Branch.1000m",              
                   "Structure_Biomass_Foliage.1000m",             
                   "Structure_Biomass_StemBark.1000m",            
                   "Structure_Biomass_StemWood.1000m",            
                   "Structure_Biomass_TotalDead.1000m",  
                   "Structure_Stand_Age.1000m",
                   "Structure_Biomass_TotalLiveAboveGround.1000m",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.1000m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind5 <- which(names(pred_ontario) %in% pred.variables5)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind5]])
end_time <- Sys.time()
end_time - start_time#Time difference of 9.407053 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 1.522541 hours

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt4<- brt_blocks(data=datcombo, pred.variables = pred.variables5, output.folder = "3_BRT_outputs/Version 1 models/without exceedance/1000m_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
#
#mean total deviance = 5.204 
#mean residual deviance = 3.259 
#estimated cv deviance = 4.214 ; se = 1.294 
#training data correlation = 0.497 
#cv correlation =  0.155 ; se = 0.043 
#elapsed time -  0.2 minutes
end_time<-Sys.time()
end_time-start_time
#Time difference of 12.7133 hours
save(brt4, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/brt4.RData")

#load("3_BRT_outputs/Version 1 models/without exceedance/1000m_model/spautoarr1andblocks.RData")
#load("3_BRT_outputs/Version 1 models/without exceedance/1000m_model/brt4.RData")

rast <-
  predict(pred_novascotia,
          brt4,
          type = "response",
          n.trees = brt4$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt4,
          type = "response",
          n.trees = brt4$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt4,
          type = "response",
          n.trees = brt4$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt4,
          type = "response",
          n.trees = brt4$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt4,
          type = "response",
          n.trees = brt4$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/without exceedance/1000m_model/pred_250m_stlLowlands.tif", overwrite=TRUE)

## Map and sample points
basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap<-spTransform(basemap.latlong, LCC)
plot(rast4)
plot(basemap, add=TRUE)

basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap<-spTransform(basemap.latlong, LAEA)
basemap<-basemap[!is.na(basemap$STATEABB),]
novascotia<-basemap[basemap$STATEABB=="CA-NS",]
plot(rast)
plot(novascotia, add=TRUE)

basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap<-spTransform(basemap.latlong, LAEA)
basemap<-basemap[!is.na(basemap$STATEABB),]
quebec<-basemap[basemap$STATEABB=="CA-QC",]
plot(rast3)
plot(quebec, add=TRUE)

basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap<-spTransform(basemap.latlong, LAEA)
basemap<-basemap[!is.na(basemap$STATEABB),]
quebec<-basemap[basemap$STATEABB=="CA-QC",]
plot(rast5)
plot(quebec, add=TRUE)

basemap.latlong<-readOGR("0_data/raw/PoliticalBoundaries_Shapefiles/NA_PoliticalDivisions/data/bound_p/boundary_p_v2.shp") ## Basemap for point plots
basemap<-spTransform(basemap.latlong, LAEA)
basemap<-basemap[!is.na(basemap$STATEABB),]
newbrunswick<-basemap[basemap$STATEABB=="CA-NB",]
plot(rast2)
plot(newbrunswick, add=TRUE)

############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - 2000 m Model                #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedD

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# 2000-m model ####
# list variables for 2000-m model
pred.variables6<-c("barren.2000m",
                   "conif.2000m",
                   "cult.2000m",
                   "decid.2000m",
                   "grassland.2000m",
                   "mixed.2000m",
                   "orchard.2000m",
                   "shrub.2000m",
                   "urban.2000m",
                   "water.2000m",
                   "wetland.2000m",
                   "Structure_Biomass_Branch.2000m",              
                   "Structure_Biomass_Foliage.2000m",             
                   "Structure_Biomass_StemBark.2000m",            
                   "Structure_Biomass_StemWood.2000m",            
                   "Structure_Biomass_TotalDead.2000m",  
                   "Structure_Stand_Age.2000m",
                   "Structure_Biomass_TotalLiveAboveGround.2000m",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.2000m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind6 <- which(names(pred_ontario) %in% pred.variables6)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind6]])
end_time <- Sys.time()
end_time - start_time#Time difference of 9.748034 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 1.720421 hours

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt5<- brt_blocks(data=datcombo, pred.variables = pred.variables6, output.folder = "3_BRT_outputs/Version 1 models/without exceedance/2000m_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
end_time<-Sys.time()
end_time-start_time
#mean total deviance = 5.204 
#mean residual deviance = 3.23 
#estimated cv deviance = 4.098 ; se = 1.569 
#training data correlation = 0.506 
#cv correlation =  0.211 ; se = 0.047 
#elapsed time -  0.1 minutes 

save(brt5, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/brt5.RData")

#load("3_BRT_outputs/Version 1 models/without exceedance/2000m_model/spautoarr1andblocks.RData")
#load("3_BRT_outputs/Version 1 models/without exceedance/2000m_model/brt5.RData")

rast <-
  predict(pred_novascotia,
          brt5,
          type = "response",
          n.trees = brt5$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt5,
          type = "response",
          n.trees = brt5$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt5,
          type = "response",
          n.trees = brt5$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt5,
          type = "response",
          n.trees = brt5$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt5,
          type = "response",
          n.trees = brt5$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/without exceedance/2000m_model/pred_250m_stlLowlands.tif", overwrite=TRUE)


############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - Selected Scales Model       #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
datcombo<-SScombo.recombinedD#start with observations where exceedance values are complete

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# Full model ####
# list variables for full model
pred.variables7<-c("decid.150m",
                   #"barren.150m",
                   #"conif.150m",
                   #"cult.150m",
                   #"grassland.150m",
                   #"mixed.150m",
                   #"orchard.150m",
                   #"shrub.150m",
                   #"urban.150m",
                   #"water.150m",
                   #"wetland.150m",
                   #"barren.250m",
                   #"conif.250m",
                   "cult.250m",
                   #"decid.250m",
                   #"grassland.250m",
                   #"mixed.250m",
                   #"orchard.250m",
                   #"shrub.250m",
                   #"urban.250m",
                   #"water.250m",
                   #"wetland.250m", 
                   #"barren.1000m",
                   #"conif.1000m",
                   #"cult.1000m",
                   #"decid.1000m",
                   "grassland.1000m",
                   #"mixed.1000m",
                   #"orchard.1000m",
                   #"shrub.1000m",
                   "urban.1000m",
                   #"water.1000m",
                   #"wetland.1000m", 
                   "barren.2000m",
                   "conif.2000m",
                   #"cult.2000m",
                   #"decid.2000m",
                   #"grassland.2000m",
                   "mixed.2000m",
                   "orchard.2000m",
                   "shrub.2000m",
                   #"urban.2000m",
                   "water.2000m",
                   "wetland.2000m",
                   #"Structure_Biomass_Branch.local",              
                   #"Structure_Biomass_Foliage.local",             
                   "Structure_Biomass_StemBark.local",            
                   #"Structure_Biomass_StemWood.local",            
                   #"Structure_Biomass_TotalDead.local",  
                   #"Structure_Stand_Age.local",
                   #"Structure_Biomass_TotalLiveAboveGround.local",
                   "Structure_Biomass_Branch.250m",              
                   #"Structure_Biomass_Foliage.250m",             
                   #"Structure_Biomass_StemBark.250m",            
                   "Structure_Biomass_StemWood.250m",            
                   #"Structure_Biomass_TotalDead.250m",  
                   #"Structure_Stand_Age.250m",
                   #"Structure_Biomass_TotalLiveAboveGround.250m",
                   #"Structure_Biomass_Branch.1000m",              
                   #"Structure_Biomass_Foliage.1000m",             
                   #"Structure_Biomass_StemBark.1000m",            
                   #"Structure_Biomass_StemWood.1000m",            
                   "Structure_Biomass_TotalDead.1000m",  
                   #"Structure_Stand_Age.1000m",
                   #"Structure_Biomass_TotalLiveAboveGround.1000m",
                   #"Structure_Biomass_Branch.2000m",              
                   "Structure_Biomass_Foliage.2000m",             
                   #"Structure_Biomass_StemBark.2000m",            
                   #"Structure_Biomass_StemWood.2000m",            
                   #"Structure_Biomass_TotalDead.2000m",  
                   "Structure_Stand_Age.2000m",
                   "Structure_Biomass_TotalLiveAboveGround.2000m",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.150m")#,"swamp.250m","swamp.1000m","swamp.2000m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind7 <- which(names(pred_ontario) %in% pred.variables7)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind7]])
end_time <- Sys.time()
end_time - start_time#Time difference of 12.0884 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_full <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 7.135354 hours

save(sp.auto.arr1, sp_block_full, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
brt6<- brt_blocks(data=datcombo, pred.variables = pred.variables7, output.folder = "3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/", blocks=sp_block_full, save.points.shp = TRUE, lr=0.01)  
#mean total deviance = 5.204 
#mean residual deviance = 3.235 
#estimated cv deviance = 3.977 ; se = 1.575 
#training data correlation = 0.486 
#cv correlation =  0.255 ; se = 0.061 
#elapsed time -  0.04 minutes 
end_time<-Sys.time()
end_time-start_time
#Time difference of 3.032543 hours

save(brt6, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/brt6.RData")

#load("3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/spautoarr1andblocks.RData")
#load("3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/brt7.RData")

rast <-
  predict(pred_novascotia,
          brt6,
          type = "response",
          n.trees = brt6$n.trees)
writeRaster(rast, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/pred_250m_novascotia.tif", overwrite=TRUE)
rast2 <-
  predict(pred_newbrunswick,
          brt6,
          type = "response",
          n.trees = brt6$n.trees)
writeRaster(rast2, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/pred_250m_newbrunswick.tif", overwrite=TRUE)
rast3 <-
  predict(pred_quebec,
          brt6,
          type = "response",
          n.trees = brt6$n.trees)
plot(rast3)
writeRaster(rast3, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/pred_250m_quebec.tif", overwrite=TRUE)
rast4 <-
  predict(pred_ontario,
          brt6,
          type = "response",
          n.trees = brt6$n.trees)
plot(rast4)
writeRaster(rast4, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/pred_250m_ontario.tif", overwrite=TRUE)
rast5 <-
  predict(pred_landis_stlLowlands,
          brt6,
          type = "response",
          n.trees = brt6$n.trees)
plot(rast5)
writeRaster(rast5, file="3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/pred_250m_stlLowlands.tif", overwrite=TRUE)


#https://rspatial.org/raster/sdm/9_sdm_brt.html



############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Comparison of the different models                                 #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################

load("3_BRT_outputs/Version 1 models/with exceedance/full_model/brt1.RData")
brt0<-brt1
rm(brt1)

#Creating custom individual partial dependence plots as PNG files
png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotA.png')
p1<-plot(brt0, 
         i.var = "decid.2000m",
         return.grid=TRUE)
plot(p1, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Deciduous 2000 m (%) R.I. 14.9 %")
lines(p1$decid.2000m, p1$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotB.png')
p2<-plot(brt0, 
         i.var = "swamp.150m",
         return.grid=TRUE)
plot(p2, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Swamp 150 m (%) R.I. 6.6 %")
lines(p2$swamp.150m, p2$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotC.png')
p3<-plot(brt0, 
         i.var = "Structure_Biomass_Foliage.2000m",
         return.grid=TRUE)
plot(p3, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Foliage Biomass 2000 m (t/ha) R.I. 5 %")
lines(p3$Structure_Biomass_Foliage.2000m, p3$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotD.png')
p4<-plot(brt0, 
         i.var = "decid.1000m",
         return.grid=TRUE)
plot(p4, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Deciduous 1000 m (%) R.I. 4.2 %")
lines(p4$decid.1000m, p4$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotE.png')
p5<-plot(brt0, 
         i.var = "Structure_Biomass_StemBark.2000m",
         return.grid=TRUE)
plot(p5, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Stem-Bark Biomass 2000 m (t/ha) R.I. 4.2 %")
lines(p5$Structure_Biomass_StemBark.2000m, p5$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotF.png')
p6<-plot(brt0, 
         i.var = "Roadside150",
         return.grid=TRUE)
plot(p6, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Within 150 m of Any Road (Y) R.I. 4 %")
lines(p6$Roadside150, p6$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotG.png')
p7<-plot(brt0, 
         i.var = "swamp.2000m",
         return.grid=TRUE)
plot(p7, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Swamp 2000 m (%) R.I. 3.9 %")
lines(p7$swamp.2000m, p7$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotH.png')
p8<-plot(brt0, 
         i.var = "swamp.1000m",
         return.grid=TRUE)
plot(p8, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Swamp 1000 m (%) R.I. 3.9 %")
lines(p8$swamp.1000m, p8$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotI.png')
p9<-plot(brt0, 
         i.var = "swamp.250m",
         return.grid=TRUE)
plot(p9, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Swamp 250 m (%) R.I. 3 %")
lines(p9$swamp.250m, p9$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder/partial-dep-plotJ.png')
p10<-plot(brt0, 
          i.var = "Structure_Biomass_TotalDead.2000m",
          return.grid=TRUE)
plot(p10, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Total Dead Biomass 2000 m (t/ha) R.I. 3 %")
lines(p10$Structure_Biomass_TotalDead.2000m, p10$y, col="red")
dev.off()

#create multi-panel plot from PNG files
library(magick)
library(dplyr)
library(tidyr)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "3_BRT_outputs/Version 1 models/with exceedance/full_model/png_output_folder",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".png", path = "3_BRT_outputs/Version 1 models/with exceedance/exceedance-BRT-partial-dependence-plots.jpg",
    quality = 100
  )


gc()
load("3_BRT_outputs/Version 1 models/without exceedance/full_model/brt1.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/local_model/brt2.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/250m_model/brt3.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/1000m_model/brt4.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/2000m_model/brt5.RData")
load("3_BRT_outputs/Version 1 models/without exceedance/selected_scales_model/brt6.RData")

# Model deviance
df<- data.frame(grp=c("Exceedance", "Full model", "Local", "250 m", "1000 m", "2000 m", "Selected scales"),
                deviance=c(brt0$cv.statistics$deviance.mean,
                           brt1$cv.statistics$deviance.mean,
                           brt2$cv.statistics$deviance.mean,
                           brt3$cv.statistics$deviance.mean,
                           brt4$cv.statistics$deviance.mean,
                           brt5$cv.statistics$deviance.mean,
                           brt6$cv.statistics$deviance.mean),
                se=c(brt0$cv.statistics$deviance.se,
                     brt1$cv.statistics$deviance.se,
                     brt2$cv.statistics$deviance.se,
                     brt3$cv.statistics$deviance.se,
                     brt4$cv.statistics$deviance.se,
                     brt5$cv.statistics$deviance.se,
                     brt6$cv.statistics$deviance.se)
                )
df$grp <- factor(df$grp, levels = c("Exceedance", "Local", "250 m", "1000 m", "2000 m", "Full model", "Selected scales"))
k1<-ggplot(df, aes(grp,deviance,ymin=deviance-se,ymax=deviance+se))+
  geom_pointrange()+ylab("Deviance")

tiff('3_BRT_outputs/Version 1 models/BRTdeviances.tiff', units="in", width=12, height=8, res=300)
k1
dev.off()

# correlation
df2<- data.frame(grp=c("Exceedance", "Full model", "Local", "250 m", "1000 m", "2000 m", "Selected scales"),
                 correlation=c(brt0$cv.statistics$correlation.mean,
                               brt1$cv.statistics$correlation.mean,
                               brt2$cv.statistics$correlation.mean,
                               brt3$cv.statistics$correlation.mean,
                               brt4$cv.statistics$correlation.mean,
                               brt5$cv.statistics$correlation.mean,
                               brt6$cv.statistics$correlation.mean),
                 se=c(brt0$cv.statistics$correlation.se,
                      brt1$cv.statistics$correlation.se,
                      brt2$cv.statistics$correlation.se,
                      brt3$cv.statistics$correlation.se,
                      brt4$cv.statistics$correlation.se,
                      brt5$cv.statistics$correlation.se,
                      brt6$cv.statistics$correlation.se)
                 )
df2$LCL<-df2$correlation-1.96*df2$se
df2$UCL<-df2$correlation+1.96*df2$se
df2$grp <- factor(df2$grp, levels = c("Exceedance", "Local", "250 m", "1000 m", "2000 m", "Full model", "Selected scales"))
k2<-ggplot(df2, aes(grp,correlation,ymin=correlation-se,ymax=correlation+se))+
  geom_pointrange()+ylab("Cross-validation correlation")

tiff('3_BRT_outputs/Version 1 models/BRT.CVcorrelation.tiff', units="in", width=12, height=8, res=300)
k2
dev.off()

# Calibration:  The estimated intercepts and slopes of linear regression models of predictions against observations. The intercept measures the magnitude and direction of bias, with values close to 0 indicating low or no bias. 
#The slope yields information about the consistency in the bias as a function of the mean, with a value of 1 indicating a consistent bias if the intercept is a nonzero value.
## intercept
df3<- data.frame(grp=c("Exceedance", "Full model", "Local", "250 m", "1000 m", "2000 m", "Selected scales"),
                 calibration.intercept=c(brt0$cv.statistics$calibration.mean[1],
                                         brt1$cv.statistics$calibration.mean[1],
                                         brt2$cv.statistics$calibration.mean[1],
                                         brt3$cv.statistics$calibration.mean[1],
                                         brt4$cv.statistics$calibration.mean[1],
                                         brt5$cv.statistics$calibration.mean[1],
                                         brt6$cv.statistics$calibration.mean[1]),
                 se=c(brt0$cv.statistics$calibration.se[1],
                      brt1$cv.statistics$calibration.se[1],
                      brt2$cv.statistics$calibration.se[1],
                      brt3$cv.statistics$calibration.se[1],
                      brt4$cv.statistics$calibration.se[1],
                      brt5$cv.statistics$calibration.se[1],
                      brt6$cv.statistics$calibration.se[1])
                 )
df3$LCL<-df3$calibration.intercept-1.96*df3$se
df3$UCL<-df3$calibration.intercept+1.96*df3$se
df3$grp <- factor(df3$grp, levels = c("Exceedance", "Local", "250 m", "1000 m", "2000 m", "Full model", "Selected scales"))
k3<-ggplot(df3, aes(grp,calibration.intercept,ymin=calibration.intercept-se,ymax=calibration.intercept+se))+
  geom_pointrange()+ylab("Calibration intercept")

tiff('3_BRT_outputs/Version 1 models/BRT.calibrationintercept.tiff', units="in", width=12, height=8, res=300)
k3
dev.off()

## slope
df4<- data.frame(grp=c("Exceedance", "Full model", "Local", "250 m", "1000 m", "2000 m", "Selected scales"),
                 calibration.slope=c(brt0$cv.statistics$calibration.mean[2],
                                     brt1$cv.statistics$calibration.mean[2],
                                     brt2$cv.statistics$calibration.mean[2],
                                     brt3$cv.statistics$calibration.mean[2],
                                     brt4$cv.statistics$calibration.mean[2],
                                     brt5$cv.statistics$calibration.mean[2],
                                     brt6$cv.statistics$calibration.mean[2]),
                 se=c(brt0$cv.statistics$calibration.se[2],
                      brt1$cv.statistics$calibration.se[2],
                      brt2$cv.statistics$calibration.se[2],
                      brt3$cv.statistics$calibration.se[2],
                      brt4$cv.statistics$calibration.se[2],
                      brt5$cv.statistics$calibration.se[2],
                      brt6$cv.statistics$calibration.se[2])
)
df4$LCL<-df4$calibration.slope-1.96*df4$se
df4$UCL<-df4$calibration.slope+1.96*df4$se
df4$grp <- factor(df4$grp, levels = c("Exceedance", "Local", "250 m", "1000 m", "2000 m", "Full model", "Selected scales"))
k4<-ggplot(df4, aes(grp,calibration.slope,ymin=calibration.slope-se,ymax=calibration.slope+se))+
  geom_pointrange()+ylab("Calibration slope")

tiff('3_BRT_outputs/Version 1 models/BRT.calibrationslope.tiff', units="in", width=12, height=8, res=300)
k4
dev.off()

tiff('3_BRT_outputs/Version 1 models/BRT.comparemodels.multipanel.tiff', units="in", width=12, height=8, res=300)
grid.arrange(k1,k2,k3,k4, nrow=2, ncol=2)
dev.off()
#Selected scales BRT appears best in terms of CV correlation and calibration


# Plotting deviance for each brt model ####
dev_plot<-function(brt){
  m<-brt[[1]]
  y.bar <- min(m$cv.values) 
  y.min <- min(m$cv.values - m$cv.loss.ses)
  y.max <- max(m$cv.values + m$cv.loss.ses)
  
  plot(m$trees.fitted, m$cv.values, type = 'l', ylab = "Holdout deviance", xlab = "no. of trees", ylim = c(y.min,y.max))
  abline(h = y.bar, col = 3)
  
  lines(m$trees.fitted, m$cv.values + m$cv.loss.ses, lty=2)  
  lines(m$trees.fitted, m$cv.values - m$cv.loss.ses, lty=2)  
  
  target.trees <- m$trees.fitted[match(TRUE,m$cv.values == y.bar)]
  abline(v = target.trees, col=4)
}

dev_plot(brt6)#Error: $ operator is invalid for atomic vectors

names(brt6)
pdf("3_BRT_outputs/Version 1 models/topBRT.relative-importance.pdf",width=7,height=25)
summary(brt6)
dev.off()

df.summ.brt6<-data.frame(summary(brt6))
write.csv(df.summ.brt6, file="3_BRT_outputs/Version 1 models/topBRTrelative-importance.csv")
#horizontal bar plot
my.theme <- theme_classic() +
  theme(text=element_text(size=24, family="Arial"),
        axis.text.x=element_text(size=24),
        axis.text.y=element_text(size=24),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

df.summ.brt6B<-df.summ.brt6[1:10,]
df.summ.brt6B$name<-c("Swamp 150 m", "Shrub 2000 m",
                      "Deciduous 150 m", "Dead Biomass 1000 m",
                      "Major Road Within 150 m", "Grassland 1000 m",
                      "Road Within 150 m", "Coniferous 2000 m",
                      "Cropland 250 m", "Branch Biomass 250 m")
tiff('3_BRT_outputs/Version 1 models/top-BRT-relative-importance.tiff', units="in", width=12, height=8, res=300)
ggplot(df.summ.brt6B, aes(reorder(x = name, rel.inf, mean), y = rel.inf))+
  geom_col(fill = "blue", width = 0.7)+coord_flip()+
  ylab("Relative importance (%)")+
  xlab("Predictor")+my.theme
dev.off()

#Using gbm.plot to generate partial dependence plots
pdf("3_BRT_outputs/Version 1 models/top-BRT-gbm_plot.var-scale.pdf")
gbm.plot(
  brt6,
  n.plots = 10,
  smooth = TRUE,
  plot.layout = c(4, 3),
  common.scale = F,
  write.title = F
)
dev.off()

#Creating custom individual partial dependence plots as PNG files
png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotA.png')
p1<-plot(brt6, 
     i.var = "swamp.150m",
     return.grid=TRUE)
plot(p1, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Swamp 150 m R.I. 17.66 %")
lines(p1$swamp.150m, p1$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotB.png')
p2<-plot(brt6, 
     i.var = "shrub.2000m",
     return.grid=TRUE)
plot(p2, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Shrub 2000 m (%) R.I. 14.28 %")
lines(p2$shrub.2000m, p2$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotC.png')
p3<-plot(brt6, 
     i.var = "decid.150m",
     return.grid=TRUE)
plot(p3, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Deciduous 150 m (%) R.I. 9.45 %")
lines(p3$decid.150m, p3$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotD.png')
p4<-plot(brt6, 
     i.var = "Structure_Biomass_TotalDead.1000m",
     return.grid=TRUE)
plot(p4, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Dead Biomass 1000 m (t/ha) R.I. 6.87 %")
lines(p4$Structure_Biomass_TotalDead.1000m, p4$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotE.png')
p5<-plot(brt2, 
     i.var = "MajorRoad150",
     return.grid=TRUE)
plot(p5, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Within 150 m of Major Road (Y) R.I. 6.03 %")
lines(p5$MajorRoad150, p5$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotF.png')
p6<-plot(brt6, 
     i.var = "grassland.1000m",
     return.grid=TRUE)
plot(p6, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Grassland 1000 m (%) R.I. 5.94 %")
lines(p6$grassland.1000m, p6$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotG.png')
p7<-plot(brt6, 
     i.var = "Roadside150",
     return.grid=TRUE)
plot(p7, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Within 150 m of Any Road (Y) R.I. 5.57 %")
lines(p7$Roadside150, p7$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotH.png')
p8<-plot(brt6, 
     i.var = "conif.2000m",
     return.grid=TRUE)
plot(p8, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Coniferous 2000 m (%) R.I. 3.89 %")
lines(p8$conif.2000m, p8$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotI.png')
p9<-plot(brt6, 
     i.var = "cult.250m",
     return.grid=TRUE)
plot(p9, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Cultivated 250 m (%) R.I. 3.87 %")
lines(p9$cult.250m, p9$y, col="red")
dev.off()

png('3_BRT_outputs/Version 1 models/png_output_folder/partial-dep-plotJ.png')
p10<-plot(brt6, 
     i.var = "Structure_Biomass_Branch.250m",
     return.grid=TRUE)
plot(p10, 
     col="red", 
     cex.lab=2, cex.axis=2,
     xlab="Branch Biomass 250 m (t/ha) R.I. 3.70 %")
lines(p10$Structure_Biomass_Branch.250m, p10$y, col="red")
dev.off()

#create multi-panel plot from PNG files
library(magick)
library(dplyr)
library(tidyr)
library(magrittr)
# read images and then create a montage
# tile =2 , means arrange the images in 2 columns
# geometry controls the pixel sixe, spacing between each image in the collage output. 
# read the the png files into a list
pngfiles <-
  list.files(
    path = "3_BRT_outputs/Version 1 models/png_output_folder",
    recursive = TRUE,
    pattern = "\\.png$",
    full.names = T
  )

magick::image_read(pngfiles) %>%
  magick::image_montage(tile = "3", geometry = "x500+10+5") %>%
  magick::image_convert("jpg") %>%
  magick::image_write(
    format = ".png", path = "3_BRT_outputs/Version 1 models/top-BRT-partial-dependence-plots.jpg",
    quality = 100
  )



############################################################################
#                                                                          #
#                                                                          #
#       BRT bootstraps and confidence intervals for                        #
#       model predictions from an area generated only for Version 3        #
#       selected scales model.                                                                        #
#                                                                          #
#                                                                          #
############################################################################
