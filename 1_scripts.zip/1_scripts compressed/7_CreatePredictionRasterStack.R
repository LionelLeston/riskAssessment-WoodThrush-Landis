memory.limit(size=56000)
# Load packages and data
library(data.table)
library(dismo)
library(dplyr)
library(ggplot2)
library(maptools)
library(raster)
library(rgeos)
library(rpart)
library(rgdal)
library(sf)
library(stars)

# Preparing data
# I have a single study area covering multiple provinces
# but not all of the spatial data that I'm using occurs at
# an extent equal to the study area. I have separate layers
# for each province from Landsat and swamp data. I could try
# merging rasters into a single layer but it might be easier
# to create a predictor stack for one province at a time.

# Load avian datasets, region raster(s), project and extract data for each province 
# The variables I need predictors for are stored within:
load("0_data/processed/pointswithdataApril5_C.RData")
# Variables in prediction stacks must have exactly the same names

###################################################################################
#                                                                                 #
#                                                                                 #
#                                                                                 #
#                                 ONTARIO PREDICTION STACK                        #
#                                                                                 #
#                                                                                 #
#                                                                                 #
###################################################################################

#Start with Ontario: use one of the Landsat annual cover (2020) layers from Ontario
ontario <- raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2020/on2020_mixed.150m.tif")
LAEA<-"+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs"
latlong<-"+proj=longlat +datum=WGS84 +no_defs"
LCC <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#I'm getting error messages when trying to define this raster's projection
#The CRS suggests lat long but extent values suggest something else
#The original rasters were in a LAEA projection
projection(ontario)<-LAEA
plot(ontario)
ontario<-projectRaster(ontario, crs=LCC)
plot(ontario)

#Load Ontario 2020 Landsat Layers
#Landsat metrics 150-m scale
on2020 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2020",pattern=".tif$")
setwd("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2020/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) {
  ras<-raster(on2020[i])
  projection(ras)<-LAEA
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_150m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 250-m scale
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2020/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  projection(ras)<-LAEA
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_250m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 1000-m scale
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2020/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  projection(ras)<-LAEA
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_1000m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 2000-m scale
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2020/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  projection(ras)<-LAEA
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_2000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics local scale
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/")
rs2020 <- stack(raster(on2020[1]))
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_v1",".local",names(rs2020))
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_local.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 250 m
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m",pattern="_250m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m/")
rs2020 <- stack(raster(on2020[1]))
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_250m",".250m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_250m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 1000 m
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m",pattern="_1000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m/")
rs2020 <- stack(raster(on2020[1]))
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_1000m",".1000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_1000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 2000 m
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m",pattern="_2000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m/")
rs2020 <- stack(raster(on2020[1]))
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_2000m",".2000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_2000m.grd", format="raster",overwrite=TRUE)

#Load swamp rasters
rlist <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",pattern="OLC")
#OLC layer from which Ontario swamp layer is derived:
#+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs
for(i in rlist){
  rs2020<-raster(paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",i))
  projection(rs2020)<-"+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs"#LAEA#set correct projection: latlong is wrong
  rs2020[is.na(rs2020[])] <- 0
  names(rs2020)<-gsub("OLC","",names(rs2020))
  #rs2020.rp<-resample(rs2020, ontario, method="bilinear")
  #extent(rs2020)<-extent(ontario)
  #for some reason the extents don't line up and I lose 
  #rs2020 values unless I change rs2020 extent before reprojecting
  rs2020.rp<-projectRaster(rs2020, ontario)
  preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
  preds2020 <- mask(preds2020,ontario)
  writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
}

#Load road data
#Major roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/CanVec roads/AllMajorRoads_LCC150/AllMajorRoads_LCC150/AllMajorRoads_LCC150.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"MajorRoad150"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
#values(preds2020)<-ifelse(is.na(values(preds2020)),0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Any Roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/roadonoff/roadonoff.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"Roadside150"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
#values(preds2020)<-ifelse(!values(preds2020)==1,0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".tif"),overwrite=TRUE)

#Exceedance05
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.05"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Exceedance20
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.20"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Elevation
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/NA_Reference_files_ASCII/elevWOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"elev"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Slope
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/slopeLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"slope"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TPI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/tpiLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TPI"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TRI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/triLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TRI"
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)


landsat150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_150m.grd")
landsat250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_250m.grd")
landsat1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_1000m.grd")
landsat2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Landsat2020_2000m.grd")
beaudoinlocal<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_local.grd")
beaudoin250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_250m.grd")
beaudoin1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_1000m.grd")
beaudoin2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Beaudoin2011_2000m.grd")
elev<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.elev.grd")
exceedance.05<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.exceedance.05.grd")
exceedance.20<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.exceedance.20.grd")
MajorRoad150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.MajorRoad150.grd")
Roadside150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.Roadside150.grd")
slope<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.slope.grd")
swamp.150m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.swamp.150m.grd")
swamp.250m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.swamp.250m.grd")
swamp.1000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.swamp.1000m.grd")
swamp.2000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.swamp.2000m.grd")
TPI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.TPI.grd")
TRI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/on.TRI.grd")


pred_ontario<-stack(landsat150,landsat250,landsat1000,landsat2000,beaudoinlocal,beaudoin250,beaudoin1000,beaudoin2000,MajorRoad150,Roadside150,elev,exceedance.05,exceedance.20,slope,swamp.150m,swamp.250m,swamp.1000m,swamp.2000m,TPI,TRI,quick=TRUE)
names(pred_ontario)
#it looks like some layers were not successfully renamed. That could be why
#predictions were not generated for some layers. Need to figure out why
#naming wasn't successful for some variables.
names(pred_ontario[[48]])<-"Structure_Biomass_StemWood.local"
names(pred_ontario[[49]])<-"Structure_Biomass_TotalDead.local"
names(pred_ontario[[50]])<-"Structure_Biomass_TotalLiveAboveGround.local"
names(pred_ontario[[52]])<-"TotalBiomass.local"
names(pred_ontario[[54]])<-"Structure_Biomass_Foliage.250m"
names(pred_ontario[[55]])<-"Structure_Biomass_StemBark.250m"
names(pred_ontario[[58]])<-"Structure_Biomass_TotalLiveAboveGround.250m"
names(pred_ontario[[60]])<-"TotalBiomass.250m"
names(pred_ontario[[61]])<-"Structure_Biomass_Branch.1000m"
names(pred_ontario[[63]])<-"Structure_Biomass_StemBark.1000m"
names(pred_ontario[[64]])<-"Structure_Biomass_StemWood.1000m"
names(pred_ontario[[67]])<-"Structure_Stand_Age.1000m"
names(pred_ontario[[70]])<-"Structure_Biomass_Foliage.2000m"
names(pred_ontario[[72]])<-"Structure_Biomass_StemWood.2000m"
names(pred_ontario[[76]])<-"TotalBiomass.2000m"
names(pred_ontario[[87]])<-"TPI"

writeRaster(pred_ontario, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Ontario/pred_ontario.grd", format="raster",overwrite=TRUE)


###################################################################################
#                                                                                 #
#                                                                                 #
#                                                                                 #
#                                 QUEBEC PREDICTION STACK                         #
#                                                                                 #
#                                                                                 #
#                                                                                 #
###################################################################################

quebec <- raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020/qc2020_mixed.150m.tif")
LAEA<-"+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs"
latlong<-"+proj=longlat +datum=WGS84 +no_defs"
LCC <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#I'm getting error messages when trying to define this raster's projection
#The CRS suggests lat long but extent values suggest something else
#The original rasters were in a LAEA projection
projection(quebec)<-LAEA
plot(quebec)

#Load quebec 2020 Landsat Layers
#Landsat metrics 150-m scale
qc2020 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020",pattern=".tif$")
setwd("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) {
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
preds2020 <- crop(rs2020,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_150m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 250-m scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
preds2020 <- crop(rs2020,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_250m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 1000-m scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
preds2020 <- crop(rs2020,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_1000m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 2000-m scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
preds2020 <- crop(rs2020,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_2000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics local scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_v1",".local",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_local.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 250 m
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m",pattern="_250m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_250m",".250m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_250m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 1000 m
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m",pattern="_1000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_1000m",".1000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_1000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 2000 m
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m",pattern="_2000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_2000m",".2000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_2000m.grd", format="raster",overwrite=TRUE)

#Load swamp rasters
rlist <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",pattern="Quebec")
#According to ArcGIS projection of base raster is NAD 1983 Quebec Lambert
QLCC<-"+proj=lcc +lat_1=60 +lat_2=46 +lat_0=44 +lon_0=-68.5 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs"
for(i in rlist){
  rs2020<-raster(paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",i))
  projection(rs2020)<-QLCC#set correct projection: latlong is wrong
  names(rs2020)<-gsub("Quebec","",names(rs2020))
  rs2020[is.na(rs2020[])] <- 0
  #rs2020.rp<-resample(rs2020, quebec, method="bilinear")
  extent(rs2020)<-extent(quebec)
  #for some reason the extents don't line up and I lose 
  #rs2020 values unless I change rs2020 extent before reprojecting
  #Had to change from projectRaster to resample for Quebec
  #rs2020.rp<-projectRaster(rs2020, quebec)
  rs2020.rp<-resample(rs2020, quebec, method="bilinear")
  preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
  preds2020 <- mask(preds2020,quebec)
  writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
}

#Load road data
#Major roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/CanVec roads/AllMajorRoads_LCC150/AllMajorRoads_LCC150/AllMajorRoads_LCC150.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"MajorRoad150"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
#values(preds2020)<-ifelse(is.na(values(preds2020)),0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Any Roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/roadonoff/roadonoff.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"Roadside150"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
#values(preds2020)<-ifelse(!values(preds2020)==1,0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".tif"), overwrite=TRUE)

#Exceedance05
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.05"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Exceedance20
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.20"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Elevation
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/NA_Reference_files_ASCII/elevWOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"elev"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Slope
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/slopeLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"slope"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TPI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/tpiLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TPI"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TRI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/triLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TRI"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

landsat150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_150m.grd")
landsat250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_250m.grd")
landsat1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_1000m.grd")
landsat2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Landsat2020_2000m.grd")
beaudoinlocal<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_local.grd")
beaudoin250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_250m.grd")
beaudoin1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_1000m.grd")
beaudoin2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Beaudoin2011_2000m.grd")
elev<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.elev.grd")
exceedance.05<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.exceedance.05.grd")
exceedance.20<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.exceedance.20.grd")
MajorRoad150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.MajorRoad150.grd")
Roadside150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.Roadside150.grd")
slope<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.slope.grd")
swamp.150m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.swamp.150m.grd")
swamp.250m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.swamp.250m.grd")
swamp.1000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.swamp.1000m.grd")
swamp.2000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.swamp.2000m.grd")
TPI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.TPI.grd")
TRI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/qc.TRI.grd")

pred_quebec<-stack(landsat150,landsat250,landsat1000,landsat2000,beaudoinlocal,beaudoin250,beaudoin1000,beaudoin2000,MajorRoad150,Roadside150,elev,exceedance.05,exceedance.20,slope,swamp.150m,swamp.250m,swamp.1000m,swamp.2000m,TPI,TRI,quick=TRUE)
names(pred_quebec)
writeRaster(pred_quebec, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Quebec/pred_quebec.grd", format="raster",overwrite=TRUE)



###################################################################################
#                                                                                 #
#                                                                                 #
#                                                                                 #
#                            NEW BRUNSWICK PREDICTION STACK                       #
#                                                                                 #
#                                                                                 #
#                                                                                 #
###################################################################################

newbrunswick <- raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2020/nb2020_mixed.150m.tif")
LAEA<-"+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs"
latlong<-"+proj=longlat +datum=WGS84 +no_defs"
LCC <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#I'm getting error messages when trying to define this raster's projection
#The CRS suggests lat long but extent values suggest something else
#The original rasters were in a LAEA projection
projection(newbrunswick)<-LAEA
plot(newbrunswick)

#Load New Brunswick 2020 Landsat Layers
#Landsat metrics 150-m scale
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2020/")
rs2020 <- stack(raster(nb2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) {
  ras<-raster(nb2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("nb2020_","",names(rs2020))
preds2020 <- crop(rs2020,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_150m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 250-m scale
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2020/")
rs2020 <- stack(raster(nb2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("nb2020_","",names(rs2020))
preds2020 <- crop(rs2020,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_250m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 1000-m scale
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2020/")
rs2020 <- stack(raster(nb2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("nb2020_","",names(rs2020))
preds2020 <- crop(rs2020,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_1000m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 2000-m scale
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2020/")
rs2020 <- stack(raster(nb2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("nb2020_","",names(rs2020))
preds2020 <- crop(rs2020,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_2000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics local scale
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/")
rs2020 <- stack(raster(nb2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_v1",".local",names(rs2020))
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_local.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 250 m
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m",pattern="_250m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m/")
rs2020 <- stack(raster(nb2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_250m",".250m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_250m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 1000 m
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m",pattern="_1000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m/")
rs2020 <- stack(raster(nb2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_1000m",".1000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_1000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 2000 m
nb2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m",pattern="_2000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m/")
rs2020 <- stack(raster(nb2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(nb2020)) { 
  ras<-raster(nb2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_2000m",".2000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_2000m.grd", format="raster",overwrite=TRUE)

#Load swamp rasters
rlist <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",pattern="NewBrunswick")
#According to ArcGIS projection of base raster is NAD 1983 newbrunswick Lambert
for(i in rlist){
  rs2020<-raster(paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",i))
  #projection(rs2020)<-LCC#set correct projection: latlong is wrong
  rs2020[is.na(rs2020[])] <- 0
  names(rs2020)<-gsub("NewBrunswick","",names(rs2020))
  #rs2020.rp<-resample(rs2020, newbrunswick, method="bilinear")
  extent(rs2020)<-extent(newbrunswick)
  #for some reason the extents don't line up and I lose 
  #rs2020 values unless I change rs2020 extent before reprojecting
  #Had to change from projectRaster to resample for newbrunswick
  #rs2020.rp<-projectRaster(rs2020, newbrunswick)
  rs2020.rp<-resample(rs2020, newbrunswick, method="bilinear")
  preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
  preds2020 <- mask(preds2020,newbrunswick)
  writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
}

#Load road data
#Major roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/CanVec roads/AllMajorRoads_LCC150/AllMajorRoads_LCC150/AllMajorRoads_LCC150.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"MajorRoad150"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)
preds2020 <- mask(preds2020,newbrunswick)
#values(preds2020)<-ifelse(is.na(values(preds2020)),0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Any Roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/roadonoff/roadonoff.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"Roadside150"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
#values(preds2020)<-ifelse(!values(preds2020)==1,0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".tif"),overwrite=TRUE)

#Exceedance05
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.05"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Exceedance20
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.20"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Elevation
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/NA_Reference_files_ASCII/elevWOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"elev"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Slope
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/slopeLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"slope"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TPI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/tpiLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TPI"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TRI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/triLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TRI"
rs2020.rp<-projectRaster(rs2020, newbrunswick)
preds2020 <- crop(rs2020.rp,newbrunswick)#rs2020.rp
preds2020 <- mask(preds2020,newbrunswick)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.",names(rs2020),".grd"), format="raster",overwrite=TRUE)


landsat150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_150m.grd")
landsat250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_250m.grd")
landsat1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_1000m.grd")
landsat2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Landsat2020_2000m.grd")
beaudoinlocal<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_local.grd")
beaudoin250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_250m.grd")
beaudoin1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_1000m.grd")
beaudoin2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Beaudoin2011_2000m.grd")
elev<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.elev.grd")
exceedance.05<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.exceedance.05.grd")
exceedance.20<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.exceedance.20.grd")
MajorRoad150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.MajorRoad150.grd")
Roadside150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.Roadside150.grd")
slope<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.slope.grd")
swamp.150m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.swamp.150m.grd")
swamp.250m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.swamp.250m.grd")
swamp.1000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.swamp.1000m.grd")
swamp.2000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.swamp.2000m.grd")
TPI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.TPI.grd")
TRI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/nb.TRI.grd")

pred_newbrunswick<-stack(landsat150,landsat250,landsat1000,landsat2000,beaudoinlocal,beaudoin250,beaudoin1000,beaudoin2000,MajorRoad150,Roadside150,elev,exceedance.05,exceedance.20,slope,swamp.150m,swamp.250m,swamp.1000m,swamp.2000m,TPI,TRI,quick=TRUE)
names(pred_newbrunswick)
writeRaster(pred_newbrunswick, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/New Brunswick/pred_newbrunswick.grd", format="raster",overwrite=TRUE)



###################################################################################
#                                                                                 #
#                                                                                 #
#                                                                                 #
#                            NOVA SCOTIA PREDICTION STACK                         #
#                                                                                 #
#                                                                                 #
#                                                                                 #
###################################################################################

novascotia <- raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2020/ns2020_mixed.150m.tif")
LAEA<-"+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs"
latlong<-"+proj=longlat +datum=WGS84 +no_defs"
LCC <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#I'm getting error messages when trying to define this raster's projection
#The CRS suggests lat long but extent values suggest something else
#The original rasters were in a LAEA projection
projection(novascotia)<-LAEA
plot(novascotia)

#Load novascotia 2020 Landsat Layers
#Landsat metrics 150-m scale
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2020/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(ns2020)) {
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  projection(ras)<-LAEA
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("ns2020_","",names(rs2020))
preds2020 <- crop(rs2020,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_150m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 250-m scale
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2020/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  projection(ras)<-LAEA
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("ns2020_","",names(rs2020))
preds2020 <- crop(rs2020,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_250m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 1000-m scale
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2020/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  projection(ras)<-LAEA
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("ns2020_","",names(rs2020))
preds2020 <- crop(rs2020,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_1000m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 2000-m scale
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2020/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  projection(ras)<-LAEA
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("ns2020_","",names(rs2020))
preds2020 <- crop(rs2020,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_2000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics local scale
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_v1",".local",names(rs2020))
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_local.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 250 m
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m",pattern="_250m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_250m",".250m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_250m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 1000 m
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m",pattern="_1000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_1000m",".1000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_1000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 2000 m
ns2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m",pattern="_2000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m/")
rs2020 <- stack(raster(ns2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(ns2020)) { 
  ras<-raster(ns2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_2000m",".2000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_2000m.grd", format="raster",overwrite=TRUE)

#Load swamp rasters
rlist <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",pattern="NovaScotia")
#According to ArcGIS projection of base raster is NAD 1983 CSRS UTM Zone 20N
#+proj=utm +zone=20 +ellps=GRS80 +units=m +no_defs
UTM20<-"+proj=utm +zone=20 +ellps=GRS80 +units=m +no_defs"
for(i in rlist){
  rs2020<-raster(paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",i))
  rs2020 <- stack(raster(ns2020[1]))
  projection(rs2020)<-UTM20#set correct projection: latlong is wrong
  names(rs2020)<-gsub("NovaScotia","",names(rs2020))
  #rs2020.rp<-resample(rs2020, novascotia, method="bilinear")
  extent(rs2020)<-extent(novascotia)
  #for some reason the extents don't line up and I lose 
  #rs2020 values unless I change rs2020 extent before reprojecting
  #Had to change from projectRaster to resample for novascotia
  #rs2020.rp<-projectRaster(rs2020, novascotia)
  rs2020.rp<-resample(rs2020, novascotia, method="bilinear")
  preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
  preds2020 <- mask(preds2020,novascotia)
  writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
}

#Load road data
#Major roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/CanVec roads/AllMajorRoads_LCC150/AllMajorRoads_LCC150/AllMajorRoads_LCC150.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"MajorRoad150"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)
preds2020 <- mask(preds2020,novascotia)
#values(preds2020)<-ifelse(is.na(values(preds2020)),0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Any Roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/roadonoff/roadonoff.WOTHstudyarea.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"Roadside150"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
#values(preds2020)<-ifelse(!values(preds2020)==1,0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".tif"), overwrite=TRUE)

#Exceedance05
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"exceedance.05"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Exceedance20
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"exceedance.20"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Elevation
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/NA_Reference_files_ASCII/elevWOTHstudyarea.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"elev"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Slope
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/slopeLCC.WOTHstudyarea.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"slope"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TPI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/tpiLCC.WOTHstudyarea.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"TPI"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TRI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/triLCC.WOTHstudyarea.tif")
rs2020 <- stack(raster(ns2020[1]))
names(rs2020)<-"TRI"
rs2020.rp<-projectRaster(rs2020, novascotia)
preds2020 <- crop(rs2020.rp,novascotia)#rs2020.rp
preds2020 <- mask(preds2020,novascotia)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

landsat150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_150m.grd")
landsat250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_250m.grd")
landsat1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_1000m.grd")
landsat2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_2000m.grd")
beaudoinlocal<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_local.grd")
beaudoin250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_250m.grd")
beaudoin1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_1000m.grd")
beaudoin2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_2000m.grd")
elev<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.elev.grd")
exceedance.05<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.exceedance.05.grd")
exceedance.20<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.exceedance.20.grd")
MajorRoad150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.MajorRoad150.grd")
Roadside150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.Roadside150.grd")
slope<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.slope.grd")
swamp.150m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.swamp.150m.grd")
swamp.250m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.swamp.250m.grd")
swamp.1000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.swamp.1000m.grd")
swamp.2000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.swamp.2000m.grd")
TPI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.TPI.grd")
TRI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/ns.TRI.grd")

pred_novascotia<-stack(landsat150,landsat250,landsat1000,landsat2000,beaudoinlocal,beaudoin250,beaudoin1000,beaudoin2000,MajorRoad150,Roadside150,elev,exceedance.05,exceedance.20,slope,swamp.150m,swamp.250m,swamp.1000m,swamp.2000m,TPI,TRI,quick=TRUE)
names(pred_novascotia)
writeRaster(pred_novascotia, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/Nova Scotia/pred_novascotia.grd", format="raster",overwrite=TRUE)

#have to redo the prediction stack because of NA values in the swamp rasters

library(raster)
landsat150<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_150m.grd")
landsat250<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_250m.grd")
landsat1000<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_1000m.grd")
landsat2000<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Landsat2020_2000m.grd")
beaudoinlocal<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_local.grd")
beaudoin250<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_250m.grd")
beaudoin1000<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_1000m.grd")
beaudoin2000<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Beaudoin2011_2000m.grd")
elev<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.elev.grd")
exceedance.05<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.exceedance.05.grd")
exceedance.20<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.exceedance.20.grd")
MajorRoad150<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.MajorRoad150.grd")
Roadside150<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.Roadside150.grd")
slope<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.slope.grd")
swamp.150m<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.swamp.150m.grd")
swamp.150m[is.na(swamp.150m[])] <- 0
swamp.250m<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.swamp.250m.grd")
swamp.250m[is.na(swamp.250m[])] <- 0
swamp.1000m<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.swamp.1000m.grd")
swamp.1000m[is.na(swamp.1000m[])] <- 0
swamp.2000m<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.swamp.2000m.grd")
swamp.2000m[is.na(swamp.2000m[])] <- 0
TPI<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.TPI.grd")
TRI<-stack("0_data/processed/prediction rasters/Nova Scotia/ns.TRI.grd")

pred_novascotia<-stack(landsat150,landsat250,landsat1000,landsat2000,beaudoinlocal,beaudoin250,beaudoin1000,beaudoin2000,MajorRoad150,Roadside150,elev,exceedance.05,exceedance.20,slope,swamp.150m,swamp.250m,swamp.1000m,swamp.2000m,TPI,TRI,quick=TRUE)
names(pred_novascotia)
writeRaster(pred_novascotia, filename="0_data/processed/prediction rasters/Nova Scotia/pred_novascotiaSep2021.grd", format="raster",overwrite=TRUE)

###################################################################################
#                                                                                 #
#                                                                                 #
#                                                                                 #
#                      LANDIS QUEBEC LOWLANDS PREDICTION STACK                    #
#                                                                                 #
#                                                                                 #
#                                                                                 #
###################################################################################

#Get shapefile boundary for Landis scenario in Quebec lowlands
quebec <- raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/lowLands_landTypes.tif")
QLCC<-"+proj=lcc +lat_1=60 +lat_2=46 +lat_0=44 +lon_0=-68.5 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs"
LAEA<-"+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs"
latlong<-"+proj=longlat +datum=WGS84 +no_defs"
LCC <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#projection(quebec)<-QLCC
plot(quebec)
#change resolution from 90x90 to 250x250
resampleFactor <- 250/90
inCols <- ncol(quebec)
inRows <- nrow(quebec)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
extent(resampledRaster) <- extent(quebec)
res(resampledRaster)<-250#set to exactly 250 m before resampling occurs
resampledRaster <- resample(quebec,resampledRaster,datatype="INT1U",method='bilinear')

quebec<-resampledRaster#but crs is now latlong (which doesn't go with the extent)
projection(quebec)<-QLCC

#Load quebec 2020 Landsat Layers
#Landsat metrics 150-m scale
qc2020 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020",pattern=".tif$")
setwd("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) {
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
rs2020.rp<-projectRaster(rs2020,quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_150m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 250-m scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
rs2020.rp<-projectRaster(rs2020,quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_250m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 1000-m scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
rs2020.rp<-projectRaster(rs2020,quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_1000m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 2000-m scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2020",pattern=".tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2020/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  projection(ras)<-LAEA
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("qc2020_","",names(rs2020))
rs2020.rp<-projectRaster(rs2020,quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_2000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics local scale
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_v1",".local",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_local.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 250 m
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m",pattern="_250m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/250 m/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_250m",".250m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_250m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 1000 m
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m",pattern="_1000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/1000 m/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_1000m",".1000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_1000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 2000 m
qc2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m",pattern="_2000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Beaudoin/2011/Processed/2000 m/")
rs2020 <- stack(raster(qc2020[1]))
rs2020[is.na(rs2020[])] <- 0
for (i in 2:length(qc2020)) { 
  ras<-raster(qc2020[i])
  ras[is.na(ras[])] <- 0
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_2000m",".2000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_2000m.grd", format="raster",overwrite=TRUE)

#Load swamp rasters
rlist <- list.files("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",pattern="Quebec")
#According to ArcGIS projection of base raster is NAD 1983 Quebec Lambert
QLCC<-"+proj=lcc +lat_1=60 +lat_2=46 +lat_0=44 +lon_0=-68.5 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs"
for(i in rlist){
  rs2020<-raster(paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Wetland data/resampled to 250 m/",i))
  projection(rs2020)<-QLCC#set correct projection: latlong is wrong
  names(rs2020)<-gsub("Quebec","",names(rs2020))
  rs2020[is.na(rs2020[])] <- 0
  #rs2020.rp<-resample(rs2020, quebec, method="bilinear")
  extent(rs2020)<-extent(quebec)
  #for some reason the extents don't line up and I lose 
  #rs2020 values unless I change rs2020 extent before reprojecting
  #Had to change from projectRaster to resample for Quebec
  #rs2020.rp<-projectRaster(rs2020, quebec)
  rs2020.rp<-resample(rs2020, quebec, method="bilinear")
  preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
  preds2020 <- mask(preds2020,quebec)
  writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
}

#Load road data
#Major roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/CanVec roads/AllMajorRoads_LCC150/AllMajorRoads_LCC150/AllMajorRoads_LCC150.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"MajorRoad150"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)
preds2020 <- mask(preds2020,quebec)
#values(preds2020)<-ifelse(is.na(values(preds2020)),0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Any Roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/roadonoff/roadonoff.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"Roadside150"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
#values(preds2020)<-ifelse(!values(preds2020)==1,0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".tif"), overwrite=TRUE)

#Exceedance05
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.05"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Exceedance20
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"exceedance.20"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Elevation
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/NA_Reference_files_ASCII/elevWOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"elev"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Slope
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/slopeLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"slope"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TPI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/tpiLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TPI"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TRI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/raw/topo/triLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TRI"
rs2020.rp<-projectRaster(rs2020, quebec)
preds2020 <- crop(rs2020.rp,quebec)#rs2020.rp
preds2020 <- mask(preds2020,quebec)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

landsat150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_150m.grd")
landsat250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_250m.grd")
landsat1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_1000m.grd")
landsat2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Landsat2020_2000m.grd")
beaudoinlocal<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_local.grd")
beaudoin250<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_250m.grd")
beaudoin1000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_1000m.grd")
beaudoin2000<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Beaudoin2011_2000m.grd")
elev<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.elev.grd")
exceedance.05<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.exceedance.05.grd")
exceedance.20<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.exceedance.20.grd")
MajorRoad150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.MajorRoad150.grd")
Roadside150<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.Roadside150.grd")
slope<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.slope.grd")
swamp.150m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.swamp.150m.grd")
swamp.250m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.swamp.250m.grd")
swamp.1000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.swamp.1000m.grd")
swamp.2000m<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.swamp.2000m.grd")
TPI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.TPI.grd")
TRI<-stack("E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/qc.TRI.grd")

pred_landis_stlLowlands<-stack(landsat150,landsat250,landsat1000,landsat2000,beaudoinlocal,beaudoin250,beaudoin1000,beaudoin2000,MajorRoad150,Roadside150,elev,exceedance.05,exceedance.20,slope,swamp.150m,swamp.250m,swamp.1000m,swamp.2000m,TPI,TRI,quick=TRUE)
names(pred_landis_stlLowlands)
writeRaster(pred_landis_stlLowlands, filename="E:/CWS Wood Thrush Contract/CHID-Regionalmodel/0_data/processed/prediction rasters/lowLands_landTypes/pred_landis_stlLowlands.grd", format="raster",overwrite=TRUE)


