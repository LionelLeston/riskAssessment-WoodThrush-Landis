memory.limit(size=56000)
# Load packages and data
library(colorspace)
library(data.table)
library(dplyr)
library(ggplot2)
library(ggspatial)
library(gridExtra)
library(lubridate)
library(maptools)
library(raster)
library(reshape2)
library(rgdal)
library(RColorBrewer)
#library(rgeos)
library(RODBC)
library(sf)
library(sp)
library(tidyr)


#Get point counts used in earlier GW models.  Prior to 
#running GW models we extracted a lot of variables to 
#those point counts, so we'll get the point counts from
#a point after we added that data
load("0_data/raw/WOTH counts combined/WOTH_GWmodelDAT_joinedtosurveys.RData")
#copied to CHID-Regionalmodel project
ls()
#"d1"       "SScombo"  "SScombo2"
str(d1)#d1 stores the point counts along with existing covariates
str(SScombo)#just the covariates
str(SScombo2)#spatial points data frame used in extraction
rm(SScombo, SScombo2)
gc()
#These will be recreated fresh later.

#Filter to final WOTH study region (parts of BCR 12, 13, and 14 but
#within Updated Canadian range shapefile based on kernel density
#estimation

#create spatial data frame from regular data frame SScombo to extract GIS data
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

Cdn.range<-st_read("0_data/raw/UpdatedCanadianRangeKernelDensity/UpdatedCanadianRangeKernelDensity.shp")

basemap.new <- st_transform(Cdn.range, latlong)
str(basemap.new)

ggplot() +
  geom_sf(data = basemap.new, size = 0.25, color = "blue", fill = "cyan1") +
  ggtitle("Study Area for Wood Thrush") +
  coord_sf()

#Now that the study area is in same the projection as the BAM points,
#I can use this shapefile to filter out just points within the study area
#but it needs to be a single polygon. Alternatively, I may want to extract
#data from the polygons in the study area to the points, then keep the
#points that get data (occur within the polygon)

sf <- sf::st_as_sf(d1, coords = c("lon","lat"))
sf <- st_set_crs(sf, "+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

## intersect polygons with points, keeping the information from both
pli = st_intersection(sf, basemap.new)
nrow(pli)#271699 obs. of  32 variable
str(pli)

ggplot() +
  geom_sf(data = basemap.new, size = 0.25, color = "blue", fill = "cyan1") +
  geom_sf(data = pli, size = 1, color = "darkred", fill = "red") +
  ggtitle("Study Area for Wood Thrush") +
  coord_sf()

## transform into a 'data.frame' by removing the geometry
#st_geometry(pli) = NULL
#head(pli)
st_write(pli, "0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv", layer_options = "GEOMETRY=AS_XY")
#coordinates saved will be lat/long


SScombo<-read.csv("0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv", header=TRUE)
nrow(SScombo)#238954 surveys
str(SScombo)#variables include elevation, topography, land cover, height, tree cover, roadyesno, climate, province
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

#The Landsat data and swamp data have been tabulated in 
#separate provinces and years. So we need to split up the 
#point counts by province and year in order to extract data
SScombo$YEAR<-year(SScombo$dt)
SScombo.ON<-SScombo[SScombo$STATEABB=="CA-ON",]
SScombo.ON.2011<-SScombo.ON[SScombo.ON$YEAR<2013,]
SScombo.ON.2015<-SScombo.ON[SScombo.ON$YEAR>2012&SScombo.ON$YEAR<2018,]
SScombo.ON.2020<-SScombo.ON[SScombo.ON$YEAR>2017,]
nrow(SScombo.ON.2011)#115460
nrow(SScombo.ON.2015)#21929
nrow(SScombo.ON.2020)#9270
SScombo.QC<-SScombo[SScombo$STATEABB=="CA-QC",]
SScombo.QC.2011<-SScombo.QC[SScombo.QC$YEAR<2013,]
SScombo.QC.2015<-SScombo.QC[SScombo.QC$YEAR>2012&SScombo.QC$YEAR<2018,]
SScombo.QC.2020<-SScombo.QC[SScombo.QC$YEAR>2017,]
nrow(SScombo.QC.2011)#40892
nrow(SScombo.QC.2015)#10130
nrow(SScombo.QC.2020)#4637
SScombo.NB<-SScombo[SScombo$STATEABB=="CA-NB",]
SScombo.NB.2011<-SScombo.NB[SScombo.NB$YEAR<2013,]
SScombo.NB.2015<-SScombo.NB[SScombo.NB$YEAR>2012&SScombo.NB$YEAR<2018,]
SScombo.NB.2020<-SScombo.NB[SScombo.NB$YEAR>2017,]
nrow(SScombo.NB.2011)#14019
nrow(SScombo.NB.2015)#3592
nrow(SScombo.NB.2020)#1414
SScombo.NS<-SScombo[SScombo$STATEABB=="CA-NS",]
SScombo.NS.2011<-SScombo.NS[SScombo.NS$YEAR<2013,]
SScombo.NS.2015<-SScombo.NS[SScombo.NS$YEAR>2012&SScombo.NS$YEAR<2018,]
SScombo.NS.2020<-SScombo.NS[SScombo.NS$YEAR>2017,]
nrow(SScombo.NS.2011)#11083
nrow(SScombo.NS.2015)#3658
nrow(SScombo.NS.2020)#1416

#Agriculture Canada Annual Cover Layers
#Use the 250-m resolution layers I created
#New Brunswick 2011
SScombo2.NB.2011<-SpatialPointsDataFrame(coords=SScombo.NB.2011[,c("X","Y")],data=SScombo.NB.2011, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2011",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.NB.2011<-spTransform(SScombo2.NB.2011, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2011/",i))
  names(rlayer)<-gsub("nb2011_","",names(rlayer))
  SScombo.NB.2011 <- cbind(SScombo.NB.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2011$X, SScombo2.NB.2011$Y)))) 
  names(SScombo.NB.2011)[ncol(SScombo.NB.2011)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2011",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2011/",i))
  names(rlayer)<-gsub("nb2011_","",names(rlayer))
  SScombo.NB.2011 <- cbind(SScombo.NB.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2011$X, SScombo2.NB.2011$Y)))) 
  names(SScombo.NB.2011)[ncol(SScombo.NB.2011)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2011",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2011/",i))
  names(rlayer)<-gsub("nb2011_","",names(rlayer))
  SScombo.NB.2011 <- cbind(SScombo.NB.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2011$X, SScombo2.NB.2011$Y)))) 
  names(SScombo.NB.2011)[ncol(SScombo.NB.2011)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2011",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2011/",i))
  names(rlayer)<-gsub("nb2011_","",names(rlayer))
  SScombo.NB.2011 <- cbind(SScombo.NB.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2011$X, SScombo2.NB.2011$Y)))) 
  names(SScombo.NB.2011)[ncol(SScombo.NB.2011)] <- names(rlayer)
}

#New Brunswick 2015
SScombo2.NB.2015<-SpatialPointsDataFrame(coords=SScombo.NB.2015[,c("X","Y")],data=SScombo.NB.2015, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2015",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.NB.2015<-spTransform(SScombo2.NB.2015, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2015/",i))
  names(rlayer)<-gsub("nb2015_","",names(rlayer))
  SScombo.NB.2015 <- cbind(SScombo.NB.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2015$X, SScombo2.NB.2015$Y)))) 
  names(SScombo.NB.2015)[ncol(SScombo.NB.2015)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2015",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2015/",i))
  names(rlayer)<-gsub("nb2015_","",names(rlayer))
  SScombo.NB.2015 <- cbind(SScombo.NB.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2015$X, SScombo2.NB.2015$Y)))) 
  names(SScombo.NB.2015)[ncol(SScombo.NB.2015)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2015",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2015/",i))
  names(rlayer)<-gsub("nb2015_","",names(rlayer))
  SScombo.NB.2015 <- cbind(SScombo.NB.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2015$X, SScombo2.NB.2015$Y)))) 
  names(SScombo.NB.2015)[ncol(SScombo.NB.2015)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2015",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2015/",i))
  names(rlayer)<-gsub("nb2015_","",names(rlayer))
  SScombo.NB.2015 <- cbind(SScombo.NB.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2015$X, SScombo2.NB.2015$Y)))) 
  names(SScombo.NB.2015)[ncol(SScombo.NB.2015)] <- names(rlayer)
}


#New Brunswick 2020
SScombo2.NB.2020<-SpatialPointsDataFrame(coords=SScombo.NB.2020[,c("X","Y")],data=SScombo.NB.2020, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2020",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.NB.2020<-spTransform(SScombo2.NB.2020, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/nb2020/",i))
  names(rlayer)<-gsub("nb2020_","",names(rlayer))
  SScombo.NB.2020 <- cbind(SScombo.NB.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2020$X, SScombo2.NB.2020$Y)))) 
  names(SScombo.NB.2020)[ncol(SScombo.NB.2020)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2020",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/nb2020/",i))
  names(rlayer)<-gsub("nb2020_","",names(rlayer))
  SScombo.NB.2020 <- cbind(SScombo.NB.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2020$X, SScombo2.NB.2020$Y)))) 
  names(SScombo.NB.2020)[ncol(SScombo.NB.2020)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2020",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/nb2020/",i))
  names(rlayer)<-gsub("nb2020_","",names(rlayer))
  SScombo.NB.2020 <- cbind(SScombo.NB.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2020$X, SScombo2.NB.2020$Y)))) 
  names(SScombo.NB.2020)[ncol(SScombo.NB.2020)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2020",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/nb2020/",i))
  names(rlayer)<-gsub("nb2020_","",names(rlayer))
  SScombo.NB.2020 <- cbind(SScombo.NB.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.2020$X, SScombo2.NB.2020$Y)))) 
  names(SScombo.NB.2020)[ncol(SScombo.NB.2020)] <- names(rlayer)
}

#Nova Scotia 2011
SScombo2.NS.2011<-SpatialPointsDataFrame(coords=SScombo.NS.2011[,c("X","Y")],data=SScombo.NS.2011, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2011",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.NS.2011<-spTransform(SScombo2.NS.2011, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2011/",i))
  names(rlayer)<-gsub("ns2011_","",names(rlayer))
  SScombo.NS.2011 <- cbind(SScombo.NS.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2011$X, SScombo2.NS.2011$Y)))) 
  names(SScombo.NS.2011)[ncol(SScombo.NS.2011)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2011",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2011/",i))
  names(rlayer)<-gsub("ns2011_","",names(rlayer))
  SScombo.NS.2011 <- cbind(SScombo.NS.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2011$X, SScombo2.NS.2011$Y)))) 
  names(SScombo.NS.2011)[ncol(SScombo.NS.2011)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2011",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2011/",i))
  names(rlayer)<-gsub("ns2011_","",names(rlayer))
  SScombo.NS.2011 <- cbind(SScombo.NS.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2011$X, SScombo2.NS.2011$Y)))) 
  names(SScombo.NS.2011)[ncol(SScombo.NS.2011)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2011",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2011/",i))
  names(rlayer)<-gsub("ns2011_","",names(rlayer))
  SScombo.NS.2011 <- cbind(SScombo.NS.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2011$X, SScombo2.NS.2011$Y)))) 
  names(SScombo.NS.2011)[ncol(SScombo.NS.2011)] <- names(rlayer)
}

#Nova Scotia 2015
SScombo2.NS.2015<-SpatialPointsDataFrame(coords=SScombo.NS.2015[,c("X","Y")],data=SScombo.NS.2015, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2015",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.NS.2015<-spTransform(SScombo2.NS.2015, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2015/",i))
  names(rlayer)<-gsub("ns2015_","",names(rlayer))
  SScombo.NS.2015 <- cbind(SScombo.NS.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2015$X, SScombo2.NS.2015$Y)))) 
  names(SScombo.NS.2015)[ncol(SScombo.NS.2015)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2015",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2015/",i))
  names(rlayer)<-gsub("ns2015_","",names(rlayer))
  SScombo.NS.2015 <- cbind(SScombo.NS.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2015$X, SScombo2.NS.2015$Y)))) 
  names(SScombo.NS.2015)[ncol(SScombo.NS.2015)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2015",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2015/",i))
  names(rlayer)<-gsub("ns2015_","",names(rlayer))
  SScombo.NS.2015 <- cbind(SScombo.NS.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2015$X, SScombo2.NS.2015$Y)))) 
  names(SScombo.NS.2015)[ncol(SScombo.NS.2015)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2015",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2015/",i))
  names(rlayer)<-gsub("ns2015_","",names(rlayer))
  SScombo.NS.2015 <- cbind(SScombo.NS.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2015$X, SScombo2.NS.2015$Y)))) 
  names(SScombo.NS.2015)[ncol(SScombo.NS.2015)] <- names(rlayer)
}


#Nova Scotia 2020
SScombo2.NS.2020<-SpatialPointsDataFrame(coords=SScombo.NS.2020[,c("X","Y")],data=SScombo.NS.2020, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2020",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.NS.2020<-spTransform(SScombo2.NS.2020, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/ns2020/",i))
  names(rlayer)<-gsub("ns2020_","",names(rlayer))
  SScombo.NS.2020 <- cbind(SScombo.NS.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2020$X, SScombo2.NS.2020$Y)))) 
  names(SScombo.NS.2020)[ncol(SScombo.NS.2020)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2020",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/ns2020/",i))
  names(rlayer)<-gsub("ns2020_","",names(rlayer))
  SScombo.NS.2020 <- cbind(SScombo.NS.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2020$X, SScombo2.NS.2020$Y)))) 
  names(SScombo.NS.2020)[ncol(SScombo.NS.2020)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2020",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/ns2020/",i))
  names(rlayer)<-gsub("ns2020_","",names(rlayer))
  SScombo.NS.2020 <- cbind(SScombo.NS.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2020$X, SScombo2.NS.2020$Y)))) 
  names(SScombo.NS.2020)[ncol(SScombo.NS.2020)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2020",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/ns2020/",i))
  names(rlayer)<-gsub("ns2020_","",names(rlayer))
  SScombo.NS.2020 <- cbind(SScombo.NS.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.2020$X, SScombo2.NS.2020$Y)))) 
  names(SScombo.NS.2020)[ncol(SScombo.NS.2020)] <- names(rlayer)
}


#Ontario 2011
SScombo2.ON.2011<-SpatialPointsDataFrame(coords=SScombo.ON.2011[,c("X","Y")],data=SScombo.ON.2011, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2011",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.ON.2011<-spTransform(SScombo2.ON.2011, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2011/",i))
  names(rlayer)<-gsub("on2011_","",names(rlayer))
  SScombo.ON.2011 <- cbind(SScombo.ON.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2011$X, SScombo2.ON.2011$Y)))) 
  names(SScombo.ON.2011)[ncol(SScombo.ON.2011)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2011",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2011/",i))
  names(rlayer)<-gsub("on2011_","",names(rlayer))
  SScombo.ON.2011 <- cbind(SScombo.ON.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2011$X, SScombo2.ON.2011$Y)))) 
  names(SScombo.ON.2011)[ncol(SScombo.ON.2011)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2011",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2011/",i))
  names(rlayer)<-gsub("on2011_","",names(rlayer))
  SScombo.ON.2011 <- cbind(SScombo.ON.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2011$X, SScombo2.ON.2011$Y)))) 
  names(SScombo.ON.2011)[ncol(SScombo.ON.2011)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2011",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2011/",i))
  names(rlayer)<-gsub("on2011_","",names(rlayer))
  SScombo.ON.2011 <- cbind(SScombo.ON.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2011$X, SScombo2.ON.2011$Y)))) 
  names(SScombo.ON.2011)[ncol(SScombo.ON.2011)] <- names(rlayer)
}

#Ontario 2015
SScombo2.ON.2015<-SpatialPointsDataFrame(coords=SScombo.ON.2015[,c("X","Y")],data=SScombo.ON.2015, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2015",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.ON.2015<-spTransform(SScombo2.ON.2015, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2015/",i))
  names(rlayer)<-gsub("on2015_","",names(rlayer))
  SScombo.ON.2015 <- cbind(SScombo.ON.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2015$X, SScombo2.ON.2015$Y)))) 
  names(SScombo.ON.2015)[ncol(SScombo.ON.2015)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2015",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2015/",i))
  names(rlayer)<-gsub("on2015_","",names(rlayer))
  SScombo.ON.2015 <- cbind(SScombo.ON.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2015$X, SScombo2.ON.2015$Y)))) 
  names(SScombo.ON.2015)[ncol(SScombo.ON.2015)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2015",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2015/",i))
  names(rlayer)<-gsub("on2015_","",names(rlayer))
  SScombo.ON.2015 <- cbind(SScombo.ON.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2015$X, SScombo2.ON.2015$Y)))) 
  names(SScombo.ON.2015)[ncol(SScombo.ON.2015)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2015",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2015/",i))
  names(rlayer)<-gsub("on2015_","",names(rlayer))
  SScombo.ON.2015 <- cbind(SScombo.ON.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2015$X, SScombo2.ON.2015$Y)))) 
  names(SScombo.ON.2015)[ncol(SScombo.ON.2015)] <- names(rlayer)
}


#Ontario 2020
SScombo2.ON.2020<-SpatialPointsDataFrame(coords=SScombo.ON.2020[,c("X","Y")],data=SScombo.ON.2020, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2020",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.ON.2020<-spTransform(SScombo2.ON.2020, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/on2020/",i))
  names(rlayer)<-gsub("on2020_","",names(rlayer))
  SScombo.ON.2020 <- cbind(SScombo.ON.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2020$X, SScombo2.ON.2020$Y)))) 
  names(SScombo.ON.2020)[ncol(SScombo.ON.2020)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2020",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2020/",i))
  names(rlayer)<-gsub("on2020_","",names(rlayer))
  SScombo.ON.2020 <- cbind(SScombo.ON.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2020$X, SScombo2.ON.2020$Y)))) 
  names(SScombo.ON.2020)[ncol(SScombo.ON.2020)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2020",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/on2020/",i))
  names(rlayer)<-gsub("on2020_","",names(rlayer))
  SScombo.ON.2020 <- cbind(SScombo.ON.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2020$X, SScombo2.ON.2020$Y)))) 
  names(SScombo.ON.2020)[ncol(SScombo.ON.2020)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2020",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/on2020/",i))
  names(rlayer)<-gsub("on2020_","",names(rlayer))
  SScombo.ON.2020 <- cbind(SScombo.ON.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.2020$X, SScombo2.ON.2020$Y)))) 
  names(SScombo.ON.2020)[ncol(SScombo.ON.2020)] <- names(rlayer)
}


#Quebec 2011
SScombo2.QC.2011<-SpatialPointsDataFrame(coords=SScombo.QC.2011[,c("X","Y")],data=SScombo.QC.2011, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2011",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.QC.2011<-spTransform(SScombo2.QC.2011, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2011/",i))
  names(rlayer)<-gsub("qc2011_","",names(rlayer))
  SScombo.QC.2011 <- cbind(SScombo.QC.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2011$X, SScombo2.QC.2011$Y)))) 
  names(SScombo.QC.2011)[ncol(SScombo.QC.2011)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2011",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2011/",i))
  names(rlayer)<-gsub("qc2011_","",names(rlayer))
  SScombo.QC.2011 <- cbind(SScombo.QC.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2011$X, SScombo2.QC.2011$Y)))) 
  names(SScombo.QC.2011)[ncol(SScombo.QC.2011)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2011",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2011/",i))
  names(rlayer)<-gsub("qc2011_","",names(rlayer))
  SScombo.QC.2011 <- cbind(SScombo.QC.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2011$X, SScombo2.QC.2011$Y)))) 
  names(SScombo.QC.2011)[ncol(SScombo.QC.2011)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2011",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2011/",i))
  names(rlayer)<-gsub("qc2011_","",names(rlayer))
  SScombo.QC.2011 <- cbind(SScombo.QC.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2011$X, SScombo2.QC.2011$Y)))) 
  names(SScombo.QC.2011)[ncol(SScombo.QC.2011)] <- names(rlayer)
}

#Quebec 2015
SScombo2.QC.2015<-SpatialPointsDataFrame(coords=SScombo.QC.2015[,c("X","Y")],data=SScombo.QC.2015, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2015",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.QC.2015<-spTransform(SScombo2.QC.2015, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2015/",i))
  names(rlayer)<-gsub("qc2015_","",names(rlayer))
  SScombo.QC.2015 <- cbind(SScombo.QC.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2015$X, SScombo2.QC.2015$Y)))) 
  names(SScombo.QC.2015)[ncol(SScombo.QC.2015)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2015",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2015/",i))
  names(rlayer)<-gsub("qc2015_","",names(rlayer))
  SScombo.QC.2015 <- cbind(SScombo.QC.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2015$X, SScombo2.QC.2015$Y)))) 
  names(SScombo.QC.2015)[ncol(SScombo.QC.2015)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2015",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2015/",i))
  names(rlayer)<-gsub("qc2015_","",names(rlayer))
  SScombo.QC.2015 <- cbind(SScombo.QC.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2015$X, SScombo2.QC.2015$Y)))) 
  names(SScombo.QC.2015)[ncol(SScombo.QC.2015)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2015",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2015/",i))
  names(rlayer)<-gsub("qc2015_","",names(rlayer))
  SScombo.QC.2015 <- cbind(SScombo.QC.2015, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2015$X, SScombo2.QC.2015$Y)))) 
  names(SScombo.QC.2015)[ncol(SScombo.QC.2015)] <- names(rlayer)
}

#Quebec 2020
SScombo2.QC.2020<-SpatialPointsDataFrame(coords=SScombo.QC.2020[,c("X","Y")],data=SScombo.QC.2020, proj4string = latlong)

rlist <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020",pattern="150m.tif$")
#annual cover layers' projection:
#+proj=longlat +datum=WGS84 +no_defs

#or is it
#+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs
SScombo2.QC.2020<-spTransform(SScombo2.QC.2020, CRS="+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/150 m/qc2020/",i))
  names(rlayer)<-gsub("qc2020_","",names(rlayer))
  SScombo.QC.2020 <- cbind(SScombo.QC.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2020$X, SScombo2.QC.2020$Y)))) 
  names(SScombo.QC.2020)[ncol(SScombo.QC.2020)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2020",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/qc2020/",i))
  names(rlayer)<-gsub("qc2020_","",names(rlayer))
  SScombo.QC.2020 <- cbind(SScombo.QC.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2020$X, SScombo2.QC.2020$Y)))) 
  names(SScombo.QC.2020)[ncol(SScombo.QC.2020)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2020",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/1000 m/qc2020/",i))
  names(rlayer)<-gsub("qc2020_","",names(rlayer))
  SScombo.QC.2020 <- cbind(SScombo.QC.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2020$X, SScombo2.QC.2020$Y)))) 
  names(SScombo.QC.2020)[ncol(SScombo.QC.2020)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2020",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/2000 m/qc2020/",i))
  names(rlayer)<-gsub("qc2020_","",names(rlayer))
  SScombo.QC.2020 <- cbind(SScombo.QC.2020, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.2020$X, SScombo2.QC.2020$Y)))) 
  names(SScombo.QC.2020)[ncol(SScombo.QC.2020)] <- names(rlayer)
}

#replace what's currently in SScombo.NB, SScombo.NS, SScombo.ON, SScombo.QC
SScombo.NB<-bind_rows(SScombo.NB.2011,SScombo.NB.2015,SScombo.NB.2020)
SScombo.NS<-bind_rows(SScombo.NS.2011,SScombo.NS.2015,SScombo.NS.2020)
SScombo.ON<-bind_rows(SScombo.ON.2011,SScombo.ON.2015,SScombo.ON.2020)
SScombo.QC<-bind_rows(SScombo.QC.2011,SScombo.QC.2015,SScombo.QC.2020)

#Swamp Layers - Since Treed Wetlands May Provide Wood Thrush Habitat
#Before we recombine the separate provinces, we need to extract swamp
#data from separate provinces

#New Brunswick Swamps
SScombo2.NB.swamp<-SpatialPointsDataFrame(coords=SScombo.NB[,c("X","Y")],data=SScombo.NB, proj4string = latlong)

rlist <- list.files("0_data/raw/Wetland data/resampled to 250 m/",pattern="NewBrunswick")
#According to ArcGIS projection of base raster is NAD 1983 CSRS New Brunswick Stereographic
#+proj=sterea +lat_0=46.5 +lon_0=-66.5 +k=0.999912 +x_0=2500000 +y_0=7500000 +ellps=GRS80 +units=m +no_defs
SScombo2.NB.swamp<-spTransform(SScombo2.NB.swamp, CRS="+proj=sterea +lat_0=46.5 +lon_0=-66.5 +k=0.999912 +x_0=2500000 +y_0=7500000 +ellps=GRS80 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Wetland data/resampled to 250 m/",i))
  names(rlayer)<-gsub("NewBrunswick","",names(rlayer))
  SScombo.NB <- cbind(SScombo.NB, raster::extract(rlayer, as.matrix(cbind(SScombo2.NB.swamp$X, SScombo2.NB.swamp$Y)))) 
  names(SScombo.NB)[ncol(SScombo.NB)] <- names(rlayer)
}

#Nova Scotia Swamps
SScombo2.NS.swamp<-SpatialPointsDataFrame(coords=SScombo.NS[,c("X","Y")],data=SScombo.NS, proj4string = latlong)

rlist <- list.files("0_data/raw/Wetland data/resampled to 250 m/",pattern="NovaScotia")
#According to ArcGIS projection of base raster is NAD 1983 CSRS UTM Zone 20N
#+proj=utm +zone=20 +ellps=GRS80 +units=m +no_defs
SScombo2.NS.swamp<-spTransform(SScombo2.NS.swamp, CRS="+proj=utm +zone=20 +ellps=GRS80 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Wetland data/resampled to 250 m/",i))
  names(rlayer)<-gsub("NovaScotia","",names(rlayer))
  SScombo.NS <- cbind(SScombo.NS, raster::extract(rlayer, as.matrix(cbind(SScombo2.NS.swamp$X, SScombo2.NS.swamp$Y)))) 
  names(SScombo.NS)[ncol(SScombo.NS)] <- names(rlayer)
}


#Ontario Swamps
SScombo2.ON.swamp<-SpatialPointsDataFrame(coords=SScombo.ON[,c("X","Y")],data=SScombo.ON, proj4string = latlong)

rlist <- list.files("0_data/raw/Wetland data/resampled to 250 m/",pattern="OLC")
#OLC layer from which Ontario swamp layer is derived:
#+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs

SScombo2.ON.swamp<-spTransform(SScombo2.ON.swamp, CRS="+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Wetland data/resampled to 250 m/",i))
  names(rlayer)<-gsub("OLC","",names(rlayer))
  SScombo.ON <- cbind(SScombo.ON, raster::extract(rlayer, as.matrix(cbind(SScombo2.ON.swamp$X, SScombo2.ON.swamp$Y)))) 
  names(SScombo.ON)[ncol(SScombo.ON)] <- names(rlayer)
}


#Quebec Swamps
SScombo2.QC.swamp<-SpatialPointsDataFrame(coords=SScombo.QC[,c("X","Y")],data=SScombo.QC, proj4string = latlong)

rlist <- list.files("0_data/raw/Wetland data/resampled to 250 m/",pattern="Quebec")
#According to ArcGIS projection of base raster is NAD 1983 Quebec Lambert
#+proj=lcc +lat_1=60 +lat_2=46 +lat_0=44 +lon_0=-68.5 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs
SScombo2.QC.swamp<-spTransform(SScombo2.QC.swamp, CRS="+proj=lcc +lat_1=60 +lat_2=46 +lat_0=44 +lon_0=-68.5 +x_0=0 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Wetland data/resampled to 250 m/",i))
  names(rlayer)<-gsub("Quebec","",names(rlayer))
  SScombo.QC <- cbind(SScombo.QC, raster::extract(rlayer, as.matrix(cbind(SScombo2.QC.swamp$X, SScombo2.QC.swamp$Y)))) 
  names(SScombo.QC)[ncol(SScombo.QC)] <- names(rlayer)
}

SScombo.recombined<-bind_rows(SScombo.NB,
                              SScombo.NS,
                              SScombo.ON,
                              SScombo.QC)
names(SScombo.recombined)
save(SScombo.NB,
     SScombo.NS,
     SScombo.ON,
     SScombo.QC,
     SScombo.recombined, file="0_data/processed/pointswithdataApril5.RData")

#Beaudoin Layers for Stand Age and Biomass
#Split the data into years closer to 2001 and those closer to 2011
load("0_data/processed/pointswithdataApril5.RData")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

SScombo.recombined.2001<-SScombo.recombined[SScombo.recombined$YEAR<2006,]
SScombo.recombined.2011<-SScombo.recombined[SScombo.recombined$YEAR>2005,]
nrow(SScombo.recombined.2001)
nrow(SScombo.recombined.2011)
#a fairly even split

#2001 Beaudoin layers
SScombo2.recombined.2001<-SpatialPointsDataFrame(coords=SScombo.recombined.2001[,c("X","Y")],data=SScombo.recombined.2001, proj4string = latlong)

rlist <- list.files("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea",pattern="_v1.tif$")
#Beaudoin layers' projection: Canadian Lambert Conformal Conic

SScombo2.recombined.2001<-spTransform(SScombo2.recombined.2001, CRS="+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_v1",".local",names(rlayer))
  SScombo.recombined.2001 <- cbind(SScombo.recombined.2001, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2001$X, SScombo2.recombined.2001$Y)))) 
  names(SScombo.recombined.2001)[ncol(SScombo.recombined.2001)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Beaudoin/2001/Processed/250 m",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/250 m/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_250m",".250m",names(rlayer))
  SScombo.recombined.2001 <- cbind(SScombo.recombined.2001, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2001$X, SScombo2.recombined.2001$Y)))) 
  names(SScombo.recombined.2001)[ncol(SScombo.recombined.2001)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Beaudoin/2001/Processed/1000 m",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/1000 m/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_1000m",".1000m",names(rlayer))
  SScombo.recombined.2001 <- cbind(SScombo.recombined.2001, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2001$X, SScombo2.recombined.2001$Y)))) 
  names(SScombo.recombined.2001)[ncol(SScombo.recombined.2001)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Beaudoin/2001/Processed/2000 m",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/2000 m/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_2000m",".2000m",names(rlayer))
  SScombo.recombined.2001 <- cbind(SScombo.recombined.2001, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2001$X, SScombo2.recombined.2001$Y)))) 
  names(SScombo.recombined.2001)[ncol(SScombo.recombined.2001)] <- names(rlayer)
}


#2011 Beaudoin layers
SScombo2.recombined.2011<-SpatialPointsDataFrame(coords=SScombo.recombined.2011[,c("X","Y")],data=SScombo.recombined.2011, proj4string = latlong)

rlist <- list.files("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
#Beaudoin layers' projection: Canadian Lambert Conformal Conic

SScombo2.recombined.2011<-spTransform(SScombo2.recombined.2011, CRS="+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")

for(i in rlist){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_v1",".local",names(rlayer))
  SScombo.recombined.2011 <- cbind(SScombo.recombined.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2011$X, SScombo2.recombined.2011$Y)))) 
  names(SScombo.recombined.2011)[ncol(SScombo.recombined.2011)] <- names(rlayer)
}

rlist2 <- list.files("0_data/raw/Beaudoin/2011/Processed/250 m",pattern="250m.tif$")

for(i in rlist2){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/250 m/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_250m",".250m",names(rlayer))
  SScombo.recombined.2011 <- cbind(SScombo.recombined.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2011$X, SScombo2.recombined.2011$Y)))) 
  names(SScombo.recombined.2011)[ncol(SScombo.recombined.2011)] <- names(rlayer)
}

rlist3 <- list.files("0_data/raw/Beaudoin/2011/Processed/1000 m",pattern="1000m.tif$")

for(i in rlist3){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/1000 m/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_1000m",".1000m",names(rlayer))
  SScombo.recombined.2011 <- cbind(SScombo.recombined.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2011$X, SScombo2.recombined.2011$Y)))) 
  names(SScombo.recombined.2011)[ncol(SScombo.recombined.2011)] <- names(rlayer)
}

rlist4 <- list.files("0_data/raw/Beaudoin/2011/Processed/2000 m",pattern="2000m.tif$")

for(i in rlist4){
  rlayer<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/2000 m/",i))
  names(rlayer)<-gsub("local_","",names(rlayer))
  names(rlayer)<-gsub("_2000m",".2000m",names(rlayer))
  SScombo.recombined.2011 <- cbind(SScombo.recombined.2011, raster::extract(rlayer, as.matrix(cbind(SScombo2.recombined.2011$X, SScombo2.recombined.2011$Y)))) 
  names(SScombo.recombined.2011)[ncol(SScombo.recombined.2011)] <- names(rlayer)
}

SScombo.recombinedB<-rbind(SScombo.recombined.2001,
                           SScombo.recombined.2011)
nrow(SScombo.recombinedB)#237500
#at this point look for any NA values in the landscape metrics you extracted
#There will at least be some for the swamp data. NA values can be replaced 
#with zeroes. E.g.:
nrow(SScombo.recombinedB[is.na(SScombo.recombinedB$swamp.150m),])#55374
nrow(SScombo.recombinedB[is.na(SScombo.recombinedB$swamp.250m),])#40451
nrow(SScombo.recombinedB[is.na(SScombo.recombinedB$swamp.1000m),])#29955
nrow(SScombo.recombinedB[is.na(SScombo.recombinedB$swamp.2000m),])#23955

names(SScombo.recombinedB)
#columns 72:151 are the landscape metrics I added
SScombo.recombinedB[72:151][is.na(SScombo.recombinedB[72:151])] <- 0

#Road Data for Classifying Stations as Roadside or Not
#and Near Major Road or Not (Distance estimated in ArcGIS)

Anyroad<-read.csv("0_data/raw/CanVec roads/PointDistanceToNearestAnyRoad.csv", header=TRUE)
str(Anyroad)
Anyroad$NEAR_DIST.Anyroad<-Anyroad$NEAR_DIST
Anyroad<-unique(Anyroad[,c("SS","NEAR_DIST.Anyroad","Roadside150")])
nrow(Anyroad)#96548
AnyroadB<-Anyroad[Anyroad$SS %in% levels(as.factor(SScombo.recombinedB$SS)),]
nrow(AnyroadB)#66602

Majorroad<-read.csv("0_data/raw/CanVec roads/PointDistanceToNearestMajorRoad.csv", header=TRUE)
str(Majorroad)
Majorroad$NEAR_DIST.MajorRoad<-Majorroad$NEAR_DIST
Majorroad<-unique(Majorroad[,c("SS","NEAR_DIST.MajorRoad","MajorRoad150")])
nrow(Majorroad)#96548
MajorroadB<-Majorroad[Majorroad$SS %in% levels(as.factor(SScombo.recombinedB$SS)),]
nrow(MajorroadB)#66602

AnyroadB<-AnyroadB[!is.na(AnyroadB$SS),]
nrow(AnyroadB)#66602
AnyroadC<-AnyroadB[!duplicated(AnyroadB$SS),]
nlevels(as.factor(AnyroadB$SS))#65724
SScombo.recombinedC<-merge(SScombo.recombinedB, Anyroad, by="SS", all.x=TRUE)
nrow(SScombo.recombinedC)#263455
SScombo.recombinedD<-merge(SScombo.recombinedC, Majorroad, by="SS", all.x=TRUE)
nrow(SScombo.recombinedD)#316241
#There are extra observations, probably from roadside data 
#(in Canada but outside study area) that will need to be dealt with

nrow(SScombo.recombinedD[is.na(SScombo.recombinedD$swamp.150m),])#0
nrow(SScombo.recombinedD[is.na(SScombo.recombinedD$swamp.250m),])#0
nrow(SScombo.recombinedD[is.na(SScombo.recombinedD$swamp.1000m),])#0
nrow(SScombo.recombinedD[is.na(SScombo.recombinedD$swamp.2000m),])#0

save(SScombo.recombinedB,
     SScombo.recombinedC,
     SScombo.recombinedD, file="0_data/processed/pointswithdataApril5_B.RData")

load("0_data/processed/pointswithdataApril5_B.RData")

#Get forest age in year of survey.
#For point counts earlier than 2006, stand ages were extracted from
#Beaudoin 2001 layers, so stand age in survey year will be
#StandAge - (2001-YEAR).
#For point counts after 2005, stand ages were extracted from
#Beaudoin 2011 layers, so stand age in survey year will be
#StandAge - (2011-YEAR).

SScombo.recombinedD$ForestAge.SurveyYear.local<-ifelse(SScombo.recombinedD$YEAR<2006,
                                                       (SScombo.recombinedD$Structure_Stand_Age.local-(2001-SScombo.recombinedD$YEAR)),
                                                       (SScombo.recombinedD$Structure_Stand_Age.local-(2011-SScombo.recombinedD$YEAR)))
range(SScombo.recombinedD$ForestAge.SurveyYear.local)
nrow(SScombo.recombinedD[SScombo.recombinedD$ForestAge.SurveyYear.local<0,])
#11416, just under 5% of point counts would have negative forest age
#These are probably point counts that were cut or disturbed more recently
#after a survey year, so forest was probably older

cor(SScombo.recombinedD$ForestAge.SurveyYear.local, 
    SScombo.recombinedD$Structure_Stand_Age.local)#0.99
#With such a high correlation we can opt to ignore 
#stand age corrected for survey year


#Some roadside points were not correctly classified. There
#are BBS point counts classified as offroad and some FBMP point
#counts classified as roadside or near a major road. We can
#at least correct these point count errors.

levels(as.factor(SScombo.recombinedD$PCODE))
SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSNB"]<-1
SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSNS"]<-1
SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSON"]<-1
SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSQU"]<-1
SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="FBMP"]<-0

range(SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSNB"],na.rm=TRUE)#1 1
range(SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSNS"],na.rm=TRUE)#1 1
range(SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSON"],na.rm=TRUE)#1 1
range(SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="BBSQU"],na.rm=TRUE)#1 1
range(SScombo.recombinedD$Roadside150[SScombo.recombinedD$PCODE=="FBMP"],na.rm=TRUE)#0 0

range(SScombo.recombinedD$MajorRoad150[SScombo.recombinedD$PCODE=="FBMP"],na.rm=TRUE)#0 1
SScombo.recombinedD$MajorRoad150[SScombo.recombinedD$PCODE=="FBMP"]<-0
range(SScombo.recombinedD$MajorRoad150[SScombo.recombinedD$PCODE=="FBMP"],na.rm=TRUE)#0 0

#Weighted Updated Forest Age (30-m resolution, from Beaudoin 2011 and Landsat)
SScombo2.recombinedD<-SpatialPointsDataFrame(coords=SScombo.recombinedD[,c("X","Y")],data=SScombo.recombinedD, proj4string = latlong)

UpdatedStandAge2015<-raster("0_data/processed/recalculate forest age/UpdatedStandAge2015.tif", RAT=TRUE)
SScombo2.recombinedD <-spTransform(SScombo2.recombinedD, proj4string(UpdatedStandAge2015))

SScombo.recombinedD <- cbind(SScombo.recombinedD,"upd.loc.for.age.2015"=raster::extract(UpdatedStandAge2015, SScombo2.recombinedD@coords))
nrow(SScombo.recombinedD[is.na(SScombo.recombinedD$upd.loc.for.age.2015),])#107
#look at these NA values outside R
SScombo.recombinedE<-SScombo.recombinedD[is.na(SScombo.recombinedD$upd.loc.for.age.2015),]#107
write.csv(SScombo.recombinedE, file="0_data/processed/SScombo.recombinedE.csv")
#Not ironclad evidence, but values of other variables suggest a lack of forest

#For these NA values assign a random updated age between 0 and 9
SScombo.recombinedD$upd.loc.for.age.2015[is.na(SScombo.recombinedD$upd.loc.for.age.2015)]<-runif(1, min=0, max=9)

cor(SScombo.recombinedD$upd.loc.for.age.2015, 
    SScombo.recombinedD$Structure_Stand_Age.local)#0.89
cor(SScombo.recombinedD$upd.loc.for.age.2015, 
    SScombo.recombinedD$ForestAge.SurveyYear.local)#0.88
#Very strong correlations still so we can opt to use the 
#original forest age variable (Beaudoin), updated stand age
#(Beaudoin + Landsat), or survey-year corrected stand age


#Exceedance Layers
exceedance.05 <- raster("0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif")
crs.exceedance.05<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
SScombo2.recombinedD<-spTransform(SScombo2.recombinedD, CRS=crs.exceedance.05)
SScombo.recombinedD <- cbind(SScombo.recombinedD,"exceedance.05"=raster::extract(exceedance.05,SScombo2.recombinedD@coords))
nrow(SScombo.recombinedD[!is.na(SScombo.recombinedD$exceedance.05),])
#188098 points with exceedance values; leave NA as is

exceedance.20 <- raster("0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
crs.exceedance.20<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
SScombo2.recombinedD<-spTransform(SScombo2.recombinedD, CRS=crs.exceedance.20)
SScombo.recombinedD <- cbind(SScombo.recombinedD,"exceedance.20"=raster::extract(exceedance.20,SScombo2.recombinedD@coords))
nrow(SScombo.recombinedD[!is.na(SScombo.recombinedD$exceedance.20),])
#188098 points with exceedance values; leave NA as is
#about two-thirds of the point counts?

SScombo.recombinedE<-SScombo.recombinedD[!is.na(SScombo.recombinedD$exceedance.20),]
save(SScombo.recombinedD,
     SScombo.recombinedE, file="0_data/processed/pointswithdataApril5_C.RData")
#At this point, I should be able to use these data in BRTs
#If I run models with exceedance, I'll use SScombo.recombinedE;
#if I run models without exceedance, I can use SScombo.recombinedD.


### set up weight matrix for SS, and calculate weight values for each row in dat2011
load("0_data/processed/pointswithdataApril5_C.RData")
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

exceedance.20 <- raster("0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif")
r2 <- projectRaster(exceedance.20, crs=latlong)
values(r2)<-1
#take raster the size of whole study area and put in same CRS that
#point count data would initially be (latlong)

samprast2011 <- rasterize(cbind(SScombo.recombinedD$X,SScombo.recombinedD$Y), r2, field=1)
sampsum25 <- focal(samprast2011, w=matrix(1/25, nc=5, nr=5), na.rm=TRUE)
SScombo.recombinedD <- cbind(SScombo.recombinedD,raster::extract(sampsum25, as.matrix(cbind(SScombo.recombinedD$X,SScombo.recombinedD$Y))))
names(SScombo.recombinedD)[ncol(SScombo.recombinedD)] <- "sampsum25"
SScombo.recombinedD$wt <- 1/SScombo.recombinedD$sampsum25
range(SScombo.recombinedD$X, na.rm=TRUE)
range(SScombo.recombinedD$Y, na.rm=TRUE)
range(SScombo.recombinedD$sampsum25, na.rm=TRUE)
range(SScombo.recombinedD$wt, na.rm=TRUE)
#SScombo.recombinedD$sampsum25 and wt values appear sensible
sum(SScombo.recombinedD$wt, na.rm=TRUE)
sum(SScombo.recombinedD$sampsum25, na.rm=TRUE)

samprast2011 <- rasterize(cbind(SScombo.recombinedE$X,SScombo.recombinedE$Y), r2, field=1)
sampsum25 <- focal(samprast2011, w=matrix(1/25, nc=5, nr=5), na.rm=TRUE)
SScombo.recombinedE <- cbind(SScombo.recombinedE,raster::extract(sampsum25, as.matrix(cbind(SScombo.recombinedE$X,SScombo.recombinedE$Y))))
names(SScombo.recombinedE)[ncol(SScombo.recombinedE)] <- "sampsum25"
SScombo.recombinedE$wt <- 1/SScombo.recombinedE$sampsum25
range(SScombo.recombinedE$X, na.rm=TRUE)
range(SScombo.recombinedE$Y, na.rm=TRUE)
range(SScombo.recombinedE$wt, na.rm=TRUE)
range(SScombo.recombinedE$sampsum25, na.rm=TRUE)
#SScombo.recombinedE$sampsum25 and wt values appear sensible
sum(SScombo.recombinedE$wt, na.rm=TRUE)
sum(SScombo.recombinedE$sampsum25, na.rm=TRUE)


save(SScombo.recombinedD,
     SScombo.recombinedE, file="0_data/processed/pointswithdataApril5_D.RData")



