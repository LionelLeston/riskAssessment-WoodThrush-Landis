#The purpose of this script is to show how to obtain
#outputs from current density layers and Landis scenarios for 
#Wood Thrush in southern Quebec, Nova Scotia, and New Brunswick. The
#outputs we are interested in will serve as some of the 
#inputs for Zonation scenarios. 

#We are specifically interested in two items from each scenario. 
#First, we need rasters of mean predicted density in 2020 and 
#2100. To save time, I am using the current density layers that I 
#created and only require the future density layers from Yan Boulanger,
#who is generating Landis predictions for me.
 
#Some current predicted densities (<<<1% of a study area's pixels) are unusually high 
#compared to observed Wood Thrush densities in real life in different areas
#These current predicted densities are adjusted to a threshold density (currently 1.0)
#before creating the estimating population sizes, and 
#identifying best-case, medium-case, and worst-case Zonation exercises. 

#For an example of where to change the threshold values, see line 108 in this script.

#Second, we need rasters of the uncertainty (standard
#deviation) in those years' estimates for each 250-m pixel.

#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So ideally, our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.
#There may not be time to get predicted densities for all 5 simulation
#runs, so for now 1 simulation run is used in this script. However,
#the raster stacks containing the variables necessary for getting
#predictions for all simulation runs are complete and will be 
#available.

#Once we have the necessary raster inputs, we set up a
#Zonation scenario outside of R and ran it. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

#get rasters for the start and end years of each Landis scenario, 
#for both the mean density prediction out of 250 predictions for 
#simulation run 1, as well as the uncertainty in that mean density 
#estimate.

#For each region, the layers for year 0 are the same for all Landis 
#scenarios.

########################################
#                                      #
#                                      #
#               NEW BRUNSWICK          #
#                                      #
#                                      #
########################################
library(maptools)
library(raster)
library(rgdal)
library(sp)

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_NewBrunswick.tif")
sdDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_NewBrunswick.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.nb

#The prediction rasters include parts of provinces and ocean outside of
#New Brunswick that we don't want to rank in Zonation. So we need a
#mask of New Brunswick.

provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
NewBrunswick<-provs[provs$PRENAME=="New Brunswick",]
#needs to be reprojected to lcc_crs
NewBrunswickB<-spTransform(NewBrunswick, CRS=lcc_crs)

#meanDens2020B<-projectRaster(meanDens2020, crs=lcc_crs)
#resolution was changed from 250 to 253x252
#try using a Landis output to clip and mask the present density file
meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")

meanDens2020B<-projectRaster(meanDens2020, meanDens1)
meanDens2020crop<-crop(meanDens2020B, meanDens1)
meanDens2020C<-mask(meanDens2020crop, meanDens1)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.

ncell(meanDens2020D)#2895096
ncell(meanDens2020D[!is.na(meanDens2020D)])#1028991
#Total Area: 1028991*6.25 = 6,431,194
density_brt_2020_250m.nb<-meanDens2020D*6.25
popsize2020.nb<-cellStats(density_brt_2020_250m.nb, stat=sum, na.rm=T) 
#169926.4 THIS IS ESTIMATED CURRENT POPULATION SIZE IN NEW BRUNSWICK.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.
writeRaster(density_brt_2020_250m.nb, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/meandens_2020.nb.tif", format="GTiff",overwrite=TRUE)

sdDens2020B<-projectRaster(sdDens2020, meanDens1)
sdDens2020crop<-crop(sdDens2020B, meanDens1)
sdDens2020C<-mask(sdDens2020crop, meanDens1)
#This layer represents the amount of uncertainty in the estimated
#density of Wood Thrush in each pixel. Pixels with high density and 
#low uncertainty (low standard deviation) are assigned higher 
#priority for conservation or management.
writeRaster(sdDens2020B, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/SDdens_2020.nb.tif", format="GTiff",overwrite=TRUE)


#2100 Best-case scenario (RCP 85 - With Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP85_GrowthBudwormProjectedFireBaselineHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

#not sure that reprojecting, cropping, and masking are still necessary
#meanDens2100B<-projectRaster(meanDens2100, crs=lcc_crs)
#meanDens2100.crop<-crop(meanDens2100B, NewBrunswickB)
#meanDens2100C<-mask(meanDens2100.crop, NewBrunswickB)
density_brt_2100_250m<-meanDens2100*6.25
#some predictions seem unrealistically high (17.024 max per 250-m cell)
plot(density_brt_2100_250m)
#"clip" out values from Landis pixels that are not in current density layer
density_brt_2100_250m[is.na(density_brt_2020_250m.nb)]<-NA
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#384710.6 (runs 1-5)
#The population in 2020 is 44.17 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/BestCasemeandens_2100.nb.tif", format="GTiff",overwrite=TRUE)

#sdDens2100B<-projectRaster(sdDens2100, crs=lcc_crs)
#sdDens2100.crop<-crop(sdDens2100B, NewBrunswickB)
#sdDens2100C<-mask(sdDens2100.crop, NewBrunswickB)

#"clip" out values from Landis pixels that are not in current density layer
sdDens2100[is.na(density_brt_2020_250m.nb)]<-NA
writeRaster(sdDens2100, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/BestCaseSDdens_2100.nb.tif", format="GTiff",overwrite=TRUE)


#2100 Medium-case scenario (RCP 45 - With Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_RCP45_GrowthBudwormProjectedFireBaselineHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

#meanDens2100B<-projectRaster(meanDens2100, crs=lcc_crs)
#meanDens2100.crop<-crop(meanDens2100B, NewBrunswickB)
#meanDens2100C<-mask(meanDens2100.crop, NewBrunswickB)
density_brt_2100_250m<-meanDens2100*6.25
#"clip" out values from Landis pixels that are not in current density layer
density_brt_2100_250m[is.na(density_brt_2020_250m.nb)]<-NA
#some predictions seem unrealistically high (13 max per 250-m cell)
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#279793.2 (runs 1-5)
#The population in 2020 is 60.73 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/MediumCasemeandens_2100.nb.tif", format="GTiff",overwrite=TRUE)

#sdDens2100B<-projectRaster(sdDens2100, crs=lcc_crs)
#sdDens2100.crop<-crop(sdDens2100B, NewBrunswickB)
#sdDens2100C<-mask(sdDens2100.crop, NewBrunswickB)

#"clip" out values from Landis pixels that are not in current density layer
sdDens2100[is.na(density_brt_2020_250m.nb)]<-NA
writeRaster(sdDens2100, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/MediumCaseSDdens_2100.nb.tif", format="GTiff",overwrite=TRUE)


#2100 Worst-case scenario (Baseline Scenario - With Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_baseline_BudwormBaselineFireBaselineHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

#meanDens2100B<-projectRaster(meanDens2100, crs=lcc_crs)
#meanDens2100.crop<-crop(meanDens2100B, NewBrunswickB)
#meanDens2100C<-mask(meanDens2100.crop, NewBrunswickB)
density_brt_2100_250m<-meanDens2100*6.25
#"clip" out values from Landis pixels that are not in current density layer
density_brt_2100_250m[is.na(density_brt_2020_250m.nb)]<-NA
#some predictions seem unrealistically high (59.3836 max per 250-m cell)
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#220447.7 (runs 1-5)
#The population in 2020 is 77.08 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WorstCasemeandens_2100.nb.tif", format="GTiff",overwrite=TRUE)

#sdDens2100B<-projectRaster(sdDens2100, crs=lcc_crs)
#sdDens2100.crop<-crop(sdDens2100B, NewBrunswickB)
#sdDens2100C<-mask(sdDens2100.crop, NewBrunswickB)

#"clip" out values from Landis pixels that are not in current density layer
sdDens2100[is.na(density_brt_2020_250m.nb)]<-NA
writeRaster(sdDens2100, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WorstCaseSDdens_2100.nb.tif", format="GTiff",overwrite=TRUE)

#Extract the locations of known Wood Thrush occurrence within
#New Brunswick, with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get WOTH point locations used in BRTs to create text file "SSI_WOTH_CH_NB"
WOTHcounts<-read.csv("0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv")
str(WOTHcounts)
#X=long, Y=lat, spp=Abundance. 
#We need coordinates in LCC (projection that the rasters are in)

library(sf)
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.nb
WOTH.sf<-sf::st_as_sf(WOTHcounts, coords=c("X","Y"))
p1 <- st_set_crs(WOTH.sf, "+proj=longlat +datum=NAD83 +no_defs")
p1 <- st_transform(p1, lcc_crs)
st_write(p1, "3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WOTHcounts_LCC_NB.csv", layer_options = "GEOMETRY=AS_XY")
#needs to be written separately to a CSV file from when it was done for other
#provinces because projection of XY coordinates is different.

datcombo<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WOTHcounts_LCC_NB.csv", header=TRUE)
SSI_WOTH_CH<-datcombo[,c("X","Y","spp")]
str(SSI_WOTH_CH)#238954
SSI_WOTH_CH<-SSI_WOTH_CH[SSI_WOTH_CH$spp>0,]
str(SSI_WOTH_CH)#12358
#Now get rid of the points outside the New Brunswick study area
extent(meanDens2020C)
#class      : Extent 
#xmin       : 1921692 
#xmax       : 2358370 
#ymin       : 6582013 
#ymax       : 7013185    

#remove WOTH occurrences outside of New Brunswick extent
SSI_WOTH_CH_NB<-SSI_WOTH_CH[SSI_WOTH_CH$X>1921692,]
SSI_WOTH_CH_NB<-SSI_WOTH_CH_NB[SSI_WOTH_CH_NB$X<2358370,]
SSI_WOTH_CH_NB<-SSI_WOTH_CH_NB[SSI_WOTH_CH_NB$Y>6582013,]
SSI_WOTH_CH_NB<-SSI_WOTH_CH_NB[SSI_WOTH_CH_NB$Y<7013185,]
write.csv(SSI_WOTH_CH_NB, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/SSI_WOTH_CH_NB.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file

########################################
#                                      #
#                                      #
#            NOVA SCOTIA               #
#                                      #
#                                      #
########################################

library(maptools)
library(raster)
library(rgdal)
library(sp)


#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_NovaScotiaSep2021.tif")
sdDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_NovaScotiaSep2021.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.ns

#The prediction rasters include parts of provinces and ocean outside of
#Nova Scotia that we don't want to rank in Zonation. So we need a
#mask of Nova Scotia.
provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")

NovaScotia<-provs[provs$PRENAME=="Nova Scotia",]
#needs to be reprojected to lcc_crs
NovaScotiaB<-spTransform(NovaScotia, CRS=lcc_crs)

#meanDens2020B<-projectRaster(meanDens2020, crs=lcc_crs)
#resolution was changed from 250 to 253x252
#try using a Landis output to clip and mask the present density file
meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP85_GrowthBudwormProjectedFire_1_2100_WOTH.tif")

meanDens2020B<-projectRaster(meanDens2020, meanDens1)
meanDens2020crop<-crop(meanDens2020B, meanDens1)
meanDens2020C<-mask(meanDens2020crop, meanDens1)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.

ncell(meanDens2020D)#3448396
ncell(meanDens2020D[!is.na(meanDens2020D)])#813678
#Total area: 813678*6.25 = 5,085,488 ha

density_brt_2020_250m.ns<-meanDens2020D*6.25
popsize2020.ns<-cellStats(density_brt_2020_250m.ns, stat=sum, na.rm=T) 
#71533.03 THIS IS ESTIMATED CURRENT POPULATION SIZE IN NOVA SCOTIA.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.
writeRaster(density_brt_2020_250m.ns, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/meandens_2020.ns.tif", format="GTiff",overwrite=TRUE)

sdDens2020B<-projectRaster(sdDens2020, meanDens1)
sdDens2020crop<-crop(sdDens2020B, meanDens1)
sdDens2020C<-mask(sdDens2020crop, meanDens1)
#This layer represents the amount of uncertainty in the estimated
#density of Wood Thrush in each pixel. Pixels with high density and 
#low uncertainty (low standard deviation) are assigned higher 
#priority for conservation or management.
writeRaster(sdDens2020C, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/SDdens_2020.ns.tif", format="GTiff",overwrite=TRUE)


#2100 Best-case scenario (RCP 85 - Historic Clearcut or High CPRS Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP85_GrowthBudwormProjectedFireHighCPRSHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

meanDens2100B<-projectRaster(meanDens2100, meanDens2020D)
meanDens2100.crop<-crop(meanDens2100B, meanDens2020D)
meanDens2100C<-mask(meanDens2100.crop, meanDens2020D)
density_brt_2100_250m<-meanDens2100C*6.25
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#268721 (runs 1-5)
#The population in 2020 is 26.62 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/BestCasemeandens_2100.ns.tif", format="GTiff",overwrite=TRUE)

sdDens2100B<-projectRaster(sdDens2100, meanDens2020D)
sdDens2100.crop<-crop(sdDens2100B, meanDens2020D)
sdDens2100C<-mask(sdDens2100.crop, meanDens2020D)

writeRaster(sdDens2100C, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/BestCaseSDdens_2100.ns.tif", format="GTiff",overwrite=TRUE)


#2100 Medium-case scenario (Baseline climate - Historic Clear-cut (High CPRS))
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_baseline_BudwormBaselineFireHighCPRSHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

meanDens2100B<-projectRaster(meanDens2100, meanDens2020D)
meanDens2100.crop<-crop(meanDens2100B, meanDens2020D)
meanDens2100C<-mask(meanDens2100.crop, meanDens2020D)
density_brt_2100_250m<-meanDens2100C*6.25
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#205325.7 (runs 1-5)
#The population in 2020 is 34.84 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/MediumCasemeandens_2100.ns.tif", format="GTiff",overwrite=TRUE)

sdDens2100B<-projectRaster(sdDens2100, meanDens2020D)
sdDens2100.crop<-crop(sdDens2100B, meanDens2020D)
sdDens2100C<-mask(sdDens2100.crop, meanDens2020D)
plot(sdDens2100C)
writeRaster(sdDens2100C, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/MediumCaseSDdens_2100.ns.tif", format="GTiff",overwrite=TRUE)


#2100 Worst-case scenario (RCP 4.5 - No Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_RCP45_GrowthBudwormProjectedFire_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

meanDens2100B<-projectRaster(meanDens2100, meanDens2020D)
meanDens2100.crop<-crop(meanDens2100B, meanDens2020D)
meanDens2100C<-mask(meanDens2100.crop, meanDens2020D)
density_brt_2100_250m<-meanDens2100C*6.25
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#199405.2 (runs 1-5)
#The population in 2020 is 35.87 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WorstCasemeandens_2100.ns.tif", format="GTiff",overwrite=TRUE)

sdDens2100B<-projectRaster(sdDens2100, meanDens2020D)
sdDens2100.crop<-crop(sdDens2100B, meanDens2020D)
sdDens2100C<-mask(sdDens2100.crop, meanDens2020D)

writeRaster(sdDens2100C, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WorstCaseSDdens_2100.ns.tif", format="GTiff",overwrite=TRUE)


#Extract the locations of known Wood Thrush occurrence within
#Nova Scotia, with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get WOTH point locations used in BRTs to create text file "SSI_WOTH_CH_NB"
WOTHcounts<-read.csv("0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv")
str(WOTHcounts)
#X=long, Y=lat, spp=Abundance. 
#We need coordinates in LCC (projection that the rasters are in)

library(sf)
lcc_crs <- "+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
WOTH.sf<-sf::st_as_sf(WOTHcounts, coords=c("X","Y"))
p1 <- st_set_crs(WOTH.sf, "+proj=longlat +datum=NAD83 +no_defs")
p1 <- st_transform(p1, lcc_crs)
st_write(p1, "3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WOTHcounts_LCC_NS.csv", layer_options = "GEOMETRY=AS_XY")
#needs to be written separately to a CSV file from when it was done for other
#provinces because projection of XY coordinates is different.

datcombo<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WOTHcounts_LCC_NS.csv", header=TRUE)
SSI_WOTH_CH<-datcombo[,c("X","Y","spp")]
str(SSI_WOTH_CH)#238954
SSI_WOTH_CH<-SSI_WOTH_CH[SSI_WOTH_CH$spp>0,]
str(SSI_WOTH_CH)#12358
#Now get rid of the points outside the Nova Scotia study area
extent(meanDens2020C)
#class      : Extent 
#xmin       : 2251487 
#xmax       : 2669571 
#ymin       : 6484866 
#ymax       : 7099656   

#remove WOTH occurrences outside of Nova Scotia extent
SSI_WOTH_CH_NS<-SSI_WOTH_CH[SSI_WOTH_CH$X>2251487,]
SSI_WOTH_CH_NS<-SSI_WOTH_CH_NS[SSI_WOTH_CH_NS$X<2669571,]
SSI_WOTH_CH_NS<-SSI_WOTH_CH_NS[SSI_WOTH_CH_NS$Y>6484866,]
SSI_WOTH_CH_NS<-SSI_WOTH_CH_NS[SSI_WOTH_CH_NS$Y<7099656,]
write.csv(SSI_WOTH_CH_NS, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/SSI_WOTH_CH_NS.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file


########################################
#                                      #
#                                      #
#            QUEBEC                    #
#                                      #
#                                      #
########################################

library(maptools)
library(raster)
library(rgdal)
library(sp)

#The Quebec study area was divided into 3 subunits (123est, 345ouest, 45est)
#for the Landis scenarios. They should be stitched together with the stitched
#filled-in future rasters, then clipped with the current density layer.
scenario<-c("baseline_BudwormBaselineFire")
for (i in scenario){
  mean.123est<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/mean_BS_123est_",i,"_1_2100_WOTH.tif"))
}
#get the projection for one Landis raster in Quebec. It will be the same as in the 
#stitched layer

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
sdDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_Quebec.tif")
#need to be reprojected in Lambert Conformal Conic used in Quebec Landis rasters
lcc_crs <- "+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"

meanDens2020B<-projectRaster(meanDens2020, mean.123est)
meanDens2020C<-meanDens2020B
meanDens2020C[meanDens2020B>1]<-1
density_brt_2020_250m.qu<-meanDens2020C*6.25

#provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
#Ontario<-provs[provs$PRENAME=="Ontario",]
#needs to be reprojected to lcc_crs
#OntarioB<-spTransform(Ontario, CRS=lcc_crs)

#cut out the bits in Quebec current density layer that are in other provinces,
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
#density_brt_2020_250m.qu.CL <- mask(density_brt_2020_250m.qu, OntarioB, inverse = TRUE)
#plot(density_brt_2020_250m.qu.CL)
#plot(density_brt_2020_250m.qu)
#plot(density_brt_2020_250m.qu.CL)#worked

#SOME BITS OF ONTARIO AND NEW BRUNSWICK NEED TO BE CLIPPED OFF FIRST
#POSSIBLY SOME QUEBEC AREAS OUTSIDE OF THE WOOD THRUSH RANGE IN QUEBEC TOO

wothrange<-readOGR("0_data/raw/UpdatedCanadianRangeKernelDensity/UpdatedCanadianRangeKernelDensity.shp")
wothrangeB<-spTransform(wothrange, CRS=lcc_crs)
levels(as.factor(wothrangeB$STATEABB))
wothrangeC<-wothrangeB[!is.na(wothrangeB$STATEABB),]
wothrangeD<-wothrangeC[wothrangeC$STATEABB=="CA-QC",]
density_brt_2020_250m.qu.crop<-crop(density_brt_2020_250m.qu, wothrangeD)
density_brt_2020_250m.qu.mask<-mask(density_brt_2020_250m.qu.crop, wothrangeD)
plot(density_brt_2020_250m.qu.mask)#I think it worked


ncell(density_brt_2020_250m.qu.mask)#4638090
ncell(density_brt_2020_250m.qu.mask[!is.na(density_brt_2020_250m.qu.mask)])#1961338
#Total Area: 1961338*6.25 = 12,258,363
popsize2020.qu<-cellStats(density_brt_2020_250m.qu.mask, stat=sum, na.rm=T) 
#612379.6 THIS IS ESTIMATED CURRENT POPULATION SIZE IN QUEBEC.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.
writeRaster(density_brt_2020_250m.qu.mask, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/meandens_2020.qu.tif", format="GTiff",overwrite=TRUE)

sdDens2020B<-projectRaster(sdDens2020, mean.123est)
#This layer represents the amount of uncertainty in the estimated
#density of Wood Thrush in each pixel. Pixels with high density and 
#low uncertainty (low standard deviation) are assigned higher 
#priority for conservation or management.
SDdensity_brt_2020_250m.qu.crop<-crop(sdDens2020B, wothrangeD)
SDdensity_brt_2020_250m.qu.mask<-mask(SDdensity_brt_2020_250m.qu.crop, wothrangeD)
writeRaster(SDdensity_brt_2020_250m.qu.mask, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/SDdens_2020.qu.tif", format="GTiff",overwrite=TRUE)


#generate list for scenario names
scenario<-c("baseline_BudwormBaselineFire",
            "baseline_BudwormBaselineFireBaselineHarvest",
            "RCP45_GrowthBudwormProjectedFire",
            "RCP45_GrowthBudwormProjectedFireBaselineHarvest",
            "RCP85_GrowthBudwormProjectedFire",
            "RCP85_GrowthBudwormProjectedFireBaselineHarvest")

landisResults<-list()#empty list each time we draw a new number of samples
k<-1

for (i in scenario){
  for (j in 1:5){
    mean.123est<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/mean_BS_123est_",i,"_",j,"_2100_WOTH.tif"))
    sdDensity.123est<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/sd_BS_123est_",i,"_",j,"_2100_WOTH.tif"))

    mean.345ouest<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/mean_BS_345ouest_",i,"_",j,"_2100_WOTH.tif"))
    sdDensity.345ouest<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/sd_BS_345ouest_",i,"_",j,"_2100_WOTH.tif"))
    
    mean.45est<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/mean_BS_45est_",i,"_",j,"_2100_WOTH.tif"))
    sdDensity.45est<-raster(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/sd_BS_45est_",i,"_",j,"_2100_WOTH.tif"))
    
    #now stitch the mean and SD rasters
    meanDensity.2100.stitched<-mosaic(mean.123est, mean.345ouest, mean.45est, fun=mean)
    sdDensity.2100.stitched<-mosaic(sdDensity.123est, sdDensity.345ouest, sdDensity.45est, fun=mean)
    #need to clip the stitched layers to the Wood Thrush range in Quebec
    meanDensity.2100.cropped<-crop(meanDensity.2100.stitched, density_brt_2020_250m.qu.mask)
    meanDensity.2100.masked<-mask(meanDensity.2100.cropped, density_brt_2020_250m.qu.mask)
    writeRaster(meanDensity.2100.masked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    #crops each stitched density layer to the Wood Thrush range in Quebec
    
    sdDensity.2100.cropped<-crop(sdDensity.2100.stitched, density_brt_2020_250m.qu.mask)
    sdDensity.2100.masked<-mask(sdDensity.2100.cropped, density_brt_2020_250m.qu.mask)
    writeRaster(sdDensity.2100.masked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    #crops each stitched SD density layer to the Wood Thrush range in Quebec
    Year<-2100
    Scenario<-i
    Replicate<-j
    
    LCL.2100.masked<-meanDensity.2100.masked-1.96*sdDensity.2100.masked
    UCL.2100.masked<-meanDensity.2100.masked+1.96*sdDensity.2100.masked
    AdjustedMeanDensity<-mean(values(meanDensity.2100.masked),na.rm=TRUE)#replaced meanDensity.2100.stitched with meanDensity.2100.masked
    AdjustedPopSize<-sum(values(meanDensity.2100.masked),na.rm=TRUE)*6.25#replaced meanDensity.2100.stitched with meanDensity.2100.masked
    AdjustedPopSize.95LCL<-sum(values(LCL.2100.masked),na.rm=TRUE)*6.25#replaced meanDensity.2100.stitched with meanDensity.2100.masked
    AdjustedPopSize.95UCL<-sum(values(UCL.2100.masked),na.rm=TRUE)*6.25#replaced meanDensity.2100.stitched with meanDensity.2100.masked
    landisResults[[k]]<-data.frame(Year,
                                   Scenario,
                                   Replicate,
                                   AdjustedMeanDensity,
                                   AdjustedPopSize,
                                   AdjustedPopSize.95LCL,
                                   AdjustedPopSize.95UCL)#append temporary data frame at each loop iteration to the list
    k<-k+1
  }
}
drawnresults = do.call(rbind, landisResults)#bind data frames together
write.csv(drawnresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/DensityTotal.csv")

library(dplyr)
library(tidyr)
drawnresults<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/DensityTotal.csv", header=TRUE)
summresults<-drawnresults%>%
  group_by(Scenario)%>%
  summarize(AdjustedPopulationSizeIn2100=mean(AdjustedPopSize),
            PopulationSizeIn2100.95LCL=mean(AdjustedPopSize.95LCL),
            PopulationSizeIn2100.95UCL=mean(AdjustedPopSize.95UCL))
write.csv(summresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/SummarizedPopulationSize.csv")



#2100 Best-case scenario (RCP 85 - No Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFire_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFire_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFire_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFire_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFire_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFire_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFire_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFire_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFire_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFire_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

#meanDens2100B<-projectRaster(meanDens2100, QuebecLandis250)
#meanDens2100.crop<-crop(meanDens2100B, QuebecLandis250)
#meanDens2100C<-mask(meanDens2100.crop, QuebecLandis250)
density_brt_2100_250m<-meanDens2100*6.25
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#1264308 (runs 1-5)
#The population in 2020 is 48.435 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/BestCasemeandens_2100.qu.tif", format="GTiff",overwrite=TRUE)

writeRaster(sdDens2100, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/BestCaseSDdens_2100.qu.tif", format="GTiff",overwrite=TRUE)


#2100 Medium-case scenario (RCP 85 - With Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_RCP85_GrowthBudwormProjectedFireBaselineHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

density_brt_2100_250m<-meanDens2100*6.25
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#1196494 (runs 1-5)
#The population in 2020 is 51.18 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/MediumCasemeandens_2100.qu.tif", format="GTiff",overwrite=TRUE)

writeRaster(sdDens2100, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/MediumCaseSDdens_2100.qu.tif", format="GTiff",overwrite=TRUE)


#2100 Worst-case scenario (Baseline Scenario - With Harvest)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_1_2100_WOTH.tif")
meanDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_2_2100_WOTH.tif")
meanDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_3_2100_WOTH.tif")
meanDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_4_2100_WOTH.tif")
meanDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/mean_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_5_2100_WOTH.tif")
#get the mean of means
meanDens2100<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_1_2100_WOTH.tif")
sdDens2<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_2_2100_WOTH.tif")
sdDens3<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_3_2100_WOTH.tif")
sdDens4<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_4_2100_WOTH.tif")
sdDens5<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-stitched-results.filled/sd_BS_stitched_baseline_BudwormBaselineFireBaselineHarvest_5_2100_WOTH.tif")
#get the overall SD
sdDens2100<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

density_brt_2100_250m<-meanDens2100*6.25
plot(density_brt_2100_250m)
popsize2100<-cellStats(density_brt_2100_250m, stat=sum, na.rm=T) 
#1170333 (runs 1-5)
#The population in 2020 is 52.33 % (all 5 runs) of what is expected in 2100 AD
writeRaster(density_brt_2100_250m, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WorstCasemeandens_2100.qu.tif", format="GTiff",overwrite=TRUE)

writeRaster(sdDens2100, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WorstCaseSDdens_2100.qu.tif", format="GTiff",overwrite=TRUE)

#Extract the locations of known Wood Thrush occurrence within
#Quebec (123est), with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get WOTH point locations used in BRTs to create text file "SSI_WOTH_CH_NB"
WOTHcounts<-read.csv("0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv")
str(WOTHcounts)
#X=long, Y=lat, spp=Abundance. 
#We need coordinates in LCC (projection that the rasters are in)

library(sf)
#need to be reprojected in Lambert Conformal Conic used in Quebec Landis rasters
lcc_crs <- "+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
WOTH.sf<-sf::st_as_sf(WOTHcounts, coords=c("X","Y"))
p1 <- st_set_crs(WOTH.sf, "+proj=longlat +datum=NAD83 +no_defs")
p1 <- st_transform(p1, lcc_crs)
#same projection as Quebec Landis rasters
st_write(p1, "3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WOTHcounts_LCC_QU.csv", layer_options = "GEOMETRY=AS_XY")
#needs to be written separately to a CSV file from when it was done for other
#provinces because projection of XY coordinates is different.

datcombo<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/WOTHcounts_LCC_QU.csv", header=TRUE)
SSI_WOTH_CH<-datcombo[,c("X","Y","spp")]
str(SSI_WOTH_CH)#238954
SSI_WOTH_CH<-SSI_WOTH_CH[SSI_WOTH_CH$spp>0,]
str(SSI_WOTH_CH)#24716
#Now get rid of the points outside the Quebec WOTH range/stitched-together study area
extent(density_brt_2020_250m.qu.mask)
#class      : Extent 
#xmin       : -783338.7 
#xmax       : -32838.7 
#ymin       : 118264.3 
#ymax       : 504514.3     

#remove WOTH occurrences outside of Nova Scotia extent
SSI_WOTH_CH_QU<-SSI_WOTH_CH[SSI_WOTH_CH$X> (-783338.7),]
SSI_WOTH_CH_QU<-SSI_WOTH_CH_QU[SSI_WOTH_CH_QU$X< (-32838.7),]
SSI_WOTH_CH_QU<-SSI_WOTH_CH_QU[SSI_WOTH_CH_QU$Y>118264.3,]
SSI_WOTH_CH_QU<-SSI_WOTH_CH_QU[SSI_WOTH_CH_QU$Y<504514.3,]
write.csv(SSI_WOTH_CH_QU, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/SSI_WOTH_CH_QU.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file


########################################
#                                      #
#                                      #
#            QUEBEC 345ouest?          #
#                                      #
#                                      #
########################################

########################################
#                                      #
#                                      #
#            QUEBEC 45est?             #
#                                      #
#                                      #
########################################

#Once we have the necessary raster inputs, we set up 
#Zonation scenarios outside of R and ran them. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

