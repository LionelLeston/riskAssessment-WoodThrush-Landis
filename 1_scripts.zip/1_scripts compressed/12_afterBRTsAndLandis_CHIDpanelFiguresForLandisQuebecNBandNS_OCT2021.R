#The purpose of this script is to process specific outputs
#from each self-contained Zonation exercise that has been 
#run, creating custom-designed plots in R from that output.

#There is a "current", "best case", "medium case", and 
#"worst case" Zonation exercise for each Landis-II study area
#in Quebec, New Brunswick, and Nova Scotia. "Best case" refers to
#the Landis scenario with the highest predicted Wood Thrush population
#in 2100 AD for a given study area. "Worst case" refers to the Landis
#scenario with the lowest predicted Wood Thrush population in 2100 AD
#for a given study area. "Medium case refers to a/the Landis scenario 
#with a 2100 AD population between the best-case and worst-case 
#scenarios.

#For each Landis-II study area, I created two
#sets of maps for each Zonation exercise. Each set will contain a panel colouring
#pixels according to their conservation priority on a continuous
#gradient. The second panel will identify all the pixels
#that are required for conservation to maintain 50/75/90/100 % of the current
#population of Wood Thrush in the study area.

#############################################
#                                           #
#                                           #
#         QUEBEC                            #
#                                           #
#                                           #
#############################################

library(sp)
library(sf)
library(viridis)
library(lattice)
library(latticeExtra)
library(rasterVis)
library(raster)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#need to be reprojected in Lambert Conformal Conic used in Quebec's Zonation and Landis-II rasters
lcc_crs <- "+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"

provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data/raw/Protected Areas/CPCAD2019.shp") 
PA.Quebec<-PAs[PAs$LOC_E=="Quebec",]
PAproj <- spTransform(PA.Quebec, CRSobj = lcc_crs) # reproject PA rasters to be lcc


#Priority ranks from Zonation rasters: 


current.quebec<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_Quebec/Zonation_current_only_QU/Zonation_current_only_QU.rank.compressed.tif")
current.quebec.rp<-projectRaster(current.quebec, crs=lcc_crs)
current.2100.quebec.best<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Best/outputs/Zonation_current_plus_2100_Quebec_Best.rank.compressed.tif")
current.2100.quebec.best.rp<-projectRaster(current.2100.quebec.best, crs=lcc_crs)
current.2100.quebec.medium<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Medium/outputs/Zonation_current_plus_2100_Quebec_Medium.rank.compressed.tif")
current.2100.quebec.medium.rp<-projectRaster(current.2100.quebec.medium, crs=lcc_crs)
current.2100.quebec.worst<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Worst/outputs/Zonation_current_plus_2100_Quebec_Worst.rank.compressed.tif")
current.2100.quebec.worst.rp<-projectRaster(current.2100.quebec.worst, crs=lcc_crs)
iStack<-stack(current.quebec.rp, 
              current.2100.quebec.best.rp,
              current.2100.quebec.medium.rp,
              current.2100.quebec.worst.rp)


names(iStack) <- c("Current", "Best", "Medium", "Worst")#rename the files for the panel plot 'names'

#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))


#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/QuebecMultipanelZonationRanks.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#Quebec Current Distribution 
current.quebec.b <- current.quebec
#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0.004
current.quebec.b[current.quebec < (0.004)] <- 0 
#what land you can lose (~0.4%) before starting to lose habitat for 100 % of current population
current.quebec.b[current.quebec >= 0.004] <- 1 
#what land you need to maintain habitat for 100 % of current population
current.quebec.b[current.quebec >= 0.32995] <- 2 
#what land you need to maintain habitat for 90 % of current population
current.quebec.b[current.quebec >= 0.60591] <- 3 
#what land you need to maintain habitat for 75 % of current population
current.quebec.b[current.quebec >= 0.84888] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(current.quebec.b)

#view
tm_shape(current.quebec.b) + tm_raster()
plot(current.quebec.b)
writeRaster(current.quebec.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_Quebec/Zonation_current_only_QU/Zonation_current_only_QU.perc_popn_range.tif", overwrite=TRUE)

#Quebec - Best Case
current.2100.quebec.best.b <- current.2100.quebec.best

#The current population in Year 0 is 48.435 % what is expected in 2100 (best case)

current.2100.quebec.best.b[current.2100.quebec.best < (0.11898)] <- 0 
#what land you can lose (~94.862) before starting to lose habitat for 100 % of current population 
#or 48.435 % of 2100 population(100*0.48435 = 48.435 % of 2100 population)
current.2100.quebec.best.b[current.2100.quebec.best >= 0.11898] <- 1 
#what land you need to maintain habitat (5.14%) for 100 % of current population in 2100
current.2100.quebec.best.b[current.2100.quebec.best >= 0.57292] <- 2 
#what land you can lose (~95.661) before starting to lose habitat for 90 % of current population
#or 40.059 % of 2100 population(90*0.4451 = 40.059 % of 2100 population)
current.2100.quebec.best.b[current.2100.quebec.best >= 0.77189] <- 3 
#what land you can lose (~96.881) before starting to lose habitat for 75 % of current population
#or 33.3825 % of 2100 population(75*0.4451 = 33.3825 % of 2100 population)
current.2100.quebec.best.b[current.2100.quebec.best >= 0.90687] <- 4 
#what land you can lose (~98.21) before starting to lose habitat for 50 % of current population
#or 22.255 % of 2100 population(50*0.4451 = 22.255 % of 2100 population)
plot(current.2100.quebec.best.b)

#view
tm_shape(current.2100.quebec.best.b) + tm_raster()
plot(current.2100.quebec.best.b)
writeRaster(current.2100.quebec.best.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Best/outputs/Zonation_current_plus_2100_Quebec_Best.perc_popn_range.tif", overwrite=TRUE)

#Quebec - Medium Case
current.2100.quebec.medium.b <- current.2100.quebec.medium
#The current population in Year 0 is 51.18 % what is expected in 2100 (medium case)
current.2100.quebec.medium.b[current.2100.quebec.medium < (0.11998)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.quebec.medium.b[current.2100.quebec.medium >= 0.11998] <- 1 
#what land you need to maintain habitat (5.14%) for 100 % of current population in 2100
current.2100.quebec.medium.b[current.2100.quebec.medium >= 0.57292] <- 2 
#what land you can lose (~95.161) before starting to lose habitat for 90 % of current population
#or 42.975 % of 2100 population(90*0.4775 = 42.975 % of 2100 population)
current.2100.quebec.medium.b[current.2100.quebec.medium >= 0.77189] <- 3 
#what land you can lose (~96.411) before starting to lose habitat for 75 % of current population
#or 35.8125 % of 2100 population(75*0.4775 = 35.8125 % of 2100 population)
current.2100.quebec.medium.b[current.2100.quebec.medium >= 0.90637] <- 4 
#what land you can lose (~98.06) before starting to lose habitat for 50 % of current population
#or 23.875 % of 2100 population(50*0.4775 = 23.875 % of 2100 population)
plot(current.2100.quebec.medium.b)

#view
tm_shape(current.2100.quebec.medium.b) + tm_raster()
plot(current.2100.quebec.medium.b)
writeRaster(current.2100.quebec.medium.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Medium/outputs/Zonation_current_plus_2100_Quebec_Medium.perc_popn_range.tif", overwrite=TRUE)

#Quebec - Worst Case
current.2100.quebec.worst.b <- current.2100.quebec.worst
#The current population in Year 0 is 52.33 % what is expected in 2100 (worst case)
current.2100.quebec.worst.b[current.2100.quebec.worst < (0.11798)] <- 0 
#what land you can lose (~93.962) before starting to lose habitat for 100 % of current population 
#or 48.75 % of 2100 population(100*0.4875 = 48.75 % of 2100 population)
current.2100.quebec.worst.b[current.2100.quebec.worst >= 0.11798] <- 1 
#what land you need to maintain habitat (6.04%) for 100 % of current population in 2100
current.2100.quebec.worst.b[current.2100.quebec.worst >= 0.57292] <- 2 
#what land you can lose (~94.962) before starting to lose habitat for 90 % of current population
#or 43.875 % of 2100 population(90*0.4875 = 43.875 % of 2100 population)
current.2100.quebec.worst.b[current.2100.quebec.worst >= 0.77189] <- 3 
#what land you can lose (~96.301) before starting to lose habitat for 75 % of current population
#or 36.5625 % of 2100 population(75*0.4875 = 36.5625 % of 2100 population)
current.2100.quebec.worst.b[current.2100.quebec.worst >= 0.90687] <- 4 
#what land you can lose (~98.06) before starting to lose habitat for 50 % of current population
#or 24.375 % of 2100 population(50*0.4875 = 24.375 % of 2100 population)
plot(current.2100.quebec.worst.b)

#view
tm_shape(current.2100.quebec.worst.b) + tm_raster()
plot(current.2100.quebec.worst.b)
writeRaster(current.2100.quebec.worst.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Worst/outputs/Zonation_current_plus_2100_Quebec_Worst.perc_popn_range.tif", overwrite=TRUE)



#stack the rasters for the panel plot
current.quebec.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_Quebec/Zonation_current_only_QU/Zonation_current_only_QU.perc_popn_range.tif")
current.quebec.b.rp<-projectRaster(current.quebec.b, crs=lcc_crs)

current.2100.quebec.best.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Best/outputs/Zonation_current_plus_2100_Quebec_Best.perc_popn_range.tif")
current.2100.quebec.best.b.rp<-projectRaster(current.2100.quebec.best.b, crs=lcc_crs)

current.2100.quebec.medium.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Medium/outputs/Zonation_current_plus_2100_Quebec_Medium.perc_popn_range.tif")
current.2100.quebec.medium.b.rp<-projectRaster(current.2100.quebec.medium.b, crs=lcc_crs)

current.2100.quebec.worst.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Worst/outputs/Zonation_current_plus_2100_Quebec_Worst.perc_popn_range.tif")
current.2100.quebec.worst.b.rp<-projectRaster(current.2100.quebec.worst.b, crs=lcc_crs)


iStackB <- stack(current.quebec.b.rp, 
                 current.2100.quebec.best.b.rp,
                 current.2100.quebec.medium.b.rp,
                 current.2100.quebec.worst.b.rp)


names(iStackB) <- c("Current", "Best",
                    "Medium", "Worst")#rename the files for the panel plot 'names'

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

#heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090","#FDAE61","#F46D43", "#D73027", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
#cuts <- c(0.00, 0.60, 0.80,0.85, 0.90, 0.95, 1.00) #set breaks in ranking


heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
tiff('3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Quebecpercentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=heatramp) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))#+ # extra shapefile data I want overlayed
dev.off()

#Runtime plots
library(ggplot2)
library(grid)
library(gridExtra)

mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

current.quebec.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_Quebec/Zonation_current_only_QU/Zonation_current_only_QU.runtimeplot.csv")
plot1<- ggplot(data=current.quebec.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.004,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.32995,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 90 % of current population
  geom_vline(xintercept = 0.60591,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.8988,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in s. Quebec", y="Proportion of Current Population Left", size=5)+
  annotate("text", x= 0.05, y = 0.125,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.35, y = 0.125,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.63, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.87, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot1, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_Quebec/Zonation_current_only_QU/Zonation_current_only_QU.runtimeplot.png", units="in", width=10, height=8)

current.2100.quebec.best.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Best/outputs/Zonation_current_plus_2100_Quebec_Best.runtimeplot.csv")
plot2<- ggplot(data=current.2100.quebec.best.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.11898,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 100 % of current population 
  geom_vline(xintercept = 0.57292,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.77189,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.90687,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in s. Quebec (Best case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.13, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.59, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.79, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.92, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot2, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Best/outputs/Zonation_current_plus_2100_Quebec_Best.runtimeplot.png", units="in", width=10, height=8)

current.2100.quebec.medium.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Medium/outputs/Zonation_current_plus_2100_Quebec_Medium.runtimeplot.csv")
plot3<- ggplot(data=current.2100.quebec.medium.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.11998,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.57292,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.77189,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.90637,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in s. Quebec (Medium case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.13, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.59, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.79, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.92, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot3, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Medium/outputs/Zonation_current_plus_2100_Quebec_Medium.runtimeplot.png", units="in", width=10, height=8)

current.2100.quebec.worst.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Worst/outputs/Zonation_current_plus_2100_Quebec_Worst.runtimeplot.csv")
plot4<- ggplot(data=current.2100.quebec.worst.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.11798,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.57292,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.77189,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.90687,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in s. Quebec (Worst case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.13, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.59, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.79, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.92, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot4, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_Quebec_Worst/outputs/Zonation_current_plus_2100_Quebec_Worst.runtimeplot.png", units="in", width=10, height=8)

plot5<-grid.arrange(plot1,plot2,plot3,plot4,nrow=2,ncol=2)
ggsave(plot5, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_Quebec.runtimeplots.png", units="in", width=12, height=8)


#############################################
#                                           #
#                                           #
#         NEW BRUNSWICK                     #
#                                           #
#                                           #
#############################################

library(sp)
library(sf)
library(viridis)
library(lattice)
library(latticeExtra)
library(rasterVis)
library(raster)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#need to be reprojected in Lambert Conformal Conic used in New Brunswick's Zonation and Landis-II rasters
lcc_crs <- "+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs"

provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data/raw/Protected Areas/CPCAD2019.shp") 
PA.NewBrunswick<-PAs[PAs$LOC_E=="New Brunswick",]
PAproj <- spTransform(PA.NewBrunswick, CRSobj = lcc_crs) # reproject PA rasters to be lcc


#Priority ranks from Zonation rasters: 
current.nb<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NewBrunswick/Zonation_current_only_NB/Zonation_current_only_NB.rank.compressed.tif")
current.nb.rp<-projectRaster(current.nb, crs=lcc_crs)
current.2100.nb.best<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Best/outputs/Zonation_current_plus_2100_NB_Best.rank.compressed.tif")
current.2100.nb.best.rp<-projectRaster(current.2100.nb.best, crs=lcc_crs)
current.2100.nb.best.crop<-crop(current.2100.nb.best.rp, current.nb.rp)
current.2100.nb.best.mask<-crop(current.2100.nb.best.crop, current.nb.rp)

current.2100.nb.medium<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Medium/outputs/Zonation_current_plus_2100_NB_Medium.rank.compressed.tif")
current.2100.nb.medium.rp<-projectRaster(current.2100.nb.medium, crs=lcc_crs)
current.2100.nb.medium.crop<-crop(current.2100.nb.medium.rp, current.nb.rp)
current.2100.nb.medium.mask<-crop(current.2100.nb.medium.crop, current.nb.rp)

current.2100.nb.worst<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Worst/outputs/Zonation_current_plus_2100_NB_Worst.rank.compressed.tif")
current.2100.nb.worst.rp<-projectRaster(current.2100.nb.worst, crs=lcc_crs)
current.2100.nb.worst.crop<-crop(current.2100.nb.worst.rp, current.nb.rp)
current.2100.nb.worst.mask<-crop(current.2100.nb.worst.crop, current.nb.rp)

iStack<-stack(current.nb.rp, 
              current.2100.nb.best.mask,
              current.2100.nb.medium.mask,
              current.2100.nb.worst.mask)


names(iStack) <- c("Current", "Best", "Medium", "Worst")#rename the files for the panel plot 'names'

#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))


#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/NewBrunswickMultipanelZonationRanks.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#New Brunswick Current Distribution 
current.nb.b <- current.nb
#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0.004
current.nb.b[current.nb < (0.004)] <- 0 
#what land you can lose (~0.4%) before starting to lose habitat for 100 % of current population
current.nb.b[current.nb >= 0.004] <- 1 
#what land you can lose and maintain habitat for 100 % of current population
current.nb.b[current.nb >= 0.32073] <- 2 
#what land you can lose and maintain habitat for 90 % of current population
current.nb.b[current.nb >= 0.58351] <- 3 
#what land you can lose and maintain habitat for 75 % of current population
current.nb.b[current.nb >= 0.8263] <- 4 
#what land you can lose and maintain habitat for 50 % of current population
plot(current.nb.b)

#view
tm_shape(current.nb.b) + tm_raster()
plot(current.nb.b)
writeRaster(current.nb.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NewBrunswick/Zonation_current_only_NB/Zonation_current_only_NB.perc_popn_range.tif", overwrite=TRUE)

#New Brunswick - Best Case
current.2100.nb.best.b <- current.2100.nb.best

#The current population in Year 0 is 44.17 % what is expected in 2100 (best case)

current.2100.nb.best.b[current.2100.nb.best < (0.19584)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.nb.best.b[current.2100.nb.best >= 0.19584] <- 1 
#what land you need to maintain habitat (100-19.584) for 100 % of current population in 2100
current.2100.nb.best.b[current.2100.nb.best >= 0.68842] <- 2 
#what land you can lose before starting to lose habitat for 90 % of current population
current.2100.nb.best.b[current.2100.nb.best >= 0.8238] <- 3 
#what land you can lose before starting to lose habitat for 75 % of current population
current.2100.nb.best.b[current.2100.nb.best >= 0.93021] <- 4 
#what land you can lose before starting to lose habitat for 50 % of current population
plot(current.2100.nb.best.b)

#view
tm_shape(current.2100.nb.best.b) + tm_raster()
plot(current.2100.nb.best.b)
writeRaster(current.2100.nb.best.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Best/outputs/Zonation_current_plus_2100_NB_Best.perc_popn_range.tif", overwrite=TRUE)

#nb - Medium Case
current.2100.nb.medium.b <- current.2100.nb.medium

#The current population in Year 0 is 60.73 % what is expected in 2100 (medium case)

current.2100.nb.medium.b[current.2100.nb.medium < (0.20883)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.nb.medium.b[current.2100.nb.medium >= 0.20833] <- 1 
#what land you need to maintain habitat for 100 % of current population in 2100
current.2100.nb.medium.b[current.2100.nb.medium >= 0.68942] <- 2 
#what land you can lose before starting to lose habitat for 90 % of current population
current.2100.nb.medium.b[current.2100.nb.medium >= 0.8243] <- 3 
#what land you can lose before starting to lose habitat for 75 % of current population
current.2100.nb.medium.b[current.2100.nb.medium >= 0.93021] <- 4 
#what land you can lose before starting to lose habitat for 50 % of current population
plot(current.2100.nb.medium.b)

#view
tm_shape(current.2100.nb.medium.b) + tm_raster()
plot(current.2100.nb.medium.b)
writeRaster(current.2100.nb.medium.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Medium/outputs/Zonation_current_plus_2100_NB_Medium.perc_popn_range.tif", overwrite=TRUE)

#nb - Worst Case
current.2100.nb.worst.b <- current.2100.nb.worst

#The current population in Year 0 is 77.08 % what is expected in 2100 (worst case)

current.2100.nb.worst.b[current.2100.nb.worst < (0.21382)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.nb.worst.b[current.2100.nb.worst >= 0.21382] <- 1 
#what land you need to maintain habitat for 100 % of current population in 2100
current.2100.nb.worst.b[current.2100.nb.worst >= 0.69042] <- 2 
#what land you can lose before starting to lose habitat for 90 % of current population
current.2100.nb.worst.b[current.2100.nb.worst >= 0.8243] <- 3 
#what land you can lose before starting to lose habitat for 75 % of current population
current.2100.nb.worst.b[current.2100.nb.worst >= 0.93021] <- 4 
#what land you can lose before starting to lose habitat for 50 % of current population
plot(current.2100.nb.worst.b)

#view
tm_shape(current.2100.nb.worst.b) + tm_raster()
plot(current.2100.nb.worst.b)
writeRaster(current.2100.nb.worst.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Worst/outputs/Zonation_current_plus_2100_NB_Worst.perc_popn_range.tif", overwrite=TRUE)

#stack the rasters for the panel plot
current.nb.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NewBrunswick/Zonation_current_only_NB/Zonation_current_only_NB.perc_popn_range.tif")
current.nb.b.rp<-projectRaster(current.nb.b, crs=lcc_crs)

current.2100.nb.best.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Best/outputs/Zonation_current_plus_2100_NB_Best.perc_popn_range.tif")
current.2100.nb.best.b.rp<-projectRaster(current.2100.nb.best.b, crs=lcc_crs)

current.2100.nb.medium.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Medium/outputs/Zonation_current_plus_2100_NB_Medium.perc_popn_range.tif")
current.2100.nb.medium.b.rp<-projectRaster(current.2100.nb.medium.b, crs=lcc_crs)

current.2100.nb.worst.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Worst/outputs/Zonation_current_plus_2100_NB_Worst.perc_popn_range.tif")
current.2100.nb.worst.b.rp<-projectRaster(current.2100.nb.worst.b, crs=lcc_crs)


iStackB <- stack(current.nb.b.rp, 
                 current.2100.nb.best.b.rp,
                 current.2100.nb.medium.b.rp,
                 current.2100.nb.worst.b.rp)


names(iStackB) <- c("Current", "Best",
                    "Medium", "Worst")#rename the files for the panel plot 'names'

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

#heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090","#FDAE61","#F46D43", "#D73027", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
#cuts <- c(0.00, 0.60, 0.80,0.85, 0.90, 0.95, 1.00) #set breaks in ranking


heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
tiff('3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/NewBrunswickpercentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=heatramp) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))#+ # extra shapefile data I want overlayed
#latticeExtra::layer(sp.lines(AlPacproj, col="black",lwd = 1.5)) 
# extra shapefile data I want overlayed but won't overlay for unknown reason
dev.off()

#Runtime plots
library(ggplot2)
library(grid)
library(gridExtra)

mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

current.nb.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NewBrunswick/Zonation_current_only_NB/Zonation_current_only_NB.runtimeplot.csv")
plot1<- ggplot(data=current.nb.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.004,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.32073,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 90 % of current population
  geom_vline(xintercept = 0.58351,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.8263,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in New Brunswick", y="Proportion of Current Population Left", size=5)+
  annotate("text", x= 0.05, y = 0.125,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.34, y = 0.125,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.60, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.84, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot1, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NewBrunswick/Zonation_current_only_NB/Zonation_current_only_NB.runtimeplot.png", units="in", width=10, height=8)

current.2100.nb.best.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Best/outputs/Zonation_current_plus_2100_NB_Best.runtimeplot.csv")
plot2<- ggplot(data=current.2100.nb.best.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.19584,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.68842,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.8328,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.93021,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in New Brunswick (Best case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.21, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.70, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.85, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.95, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot2, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Best/outputs/Zonation_current_plus_2100_NB_Best.runtimeplot.png", units="in", width=10, height=8)

current.2100.nb.medium.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Medium/outputs/Zonation_current_plus_2100_NB_Medium.runtimeplot.csv")
plot3<- ggplot(data=current.2100.nb.medium.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.20883,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.68942,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.8243,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.93021,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in New Brunswick (Medium case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.22, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.70, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.84, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.95, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot3, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Medium/outputs/Zonation_current_plus_2100_NB_Medium.runtimeplot.png", units="in", width=10, height=8)

current.2100.quebec.worst.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Worst/outputs/Zonation_current_plus_2100_NB_Worst.runtimeplot.csv")
plot4<- ggplot(data=current.2100.quebec.worst.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.21382,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.69042,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.8243,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.93021,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in New Brunswick (Worst case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.23, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.71, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.84, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.95, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot4, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NB_Worst/outputs/Zonation_current_plus_2100_NB_Worst.runtimeplot.png", units="in", width=10, height=8)

plot5<-grid.arrange(plot1,plot2,plot3,plot4,nrow=2,ncol=2)
ggsave(plot5, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_NewBrunswick.runtimeplots.png", units="in", width=12, height=8)



#############################################
#                                           #
#                                           #
#         NOVA SCOTIA                       #
#                                           #
#                                           #
#############################################

library(sp)
library(sf)
library(viridis)
library(lattice)
library(latticeExtra)
library(rasterVis)
library(raster)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#need to be reprojected in Lambert Conformal Conic used in Nova Scotia's Zonation and Landis-II rasters
lcc_crs <- "+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"

provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data/raw/Protected Areas/CPCAD2019.shp") 
PA.NovaScotia<-PAs[PAs$LOC_E=="Nova Scotia",]
PAproj <- spTransform(PA.NovaScotia, CRSobj = lcc_crs) # reproject PA rasters to be lcc


#Priority ranks from Zonation rasters: 


current.ns<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NovaScotia/Zonation_current_only_NS/Zonation_current_only_NS.rank.compressed.tif")
current.ns.rp<-projectRaster(current.ns, crs=lcc_crs)
current.2100.ns.best<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Best/outputs/Zonation_current_plus_2100_NS_Best.rank.compressed.tif")
current.2100.ns.best.rp<-projectRaster(current.2100.ns.best, crs=lcc_crs)
current.2100.ns.best.crop<-crop(current.2100.ns.best.rp, current.ns.rp)
current.2100.ns.best.mask<-crop(current.2100.ns.best.crop, current.ns.rp)

current.2100.ns.medium<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Medium/outputs/Zonation_current_plus_2100_NS_Medium.rank.compressed.tif")
current.2100.ns.medium.rp<-projectRaster(current.2100.ns.medium, crs=lcc_crs)
current.2100.ns.medium.crop<-crop(current.2100.ns.medium.rp, current.ns.rp)
current.2100.ns.medium.mask<-crop(current.2100.ns.medium.crop, current.ns.rp)

current.2100.ns.worst<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Worst/outputs/Zonation_current_plus_2100_NS_Worst.rank.compressed.tif")
current.2100.ns.worst.rp<-projectRaster(current.2100.ns.worst, crs=lcc_crs)
current.2100.ns.worst.crop<-crop(current.2100.ns.worst.rp, current.ns.rp)
current.2100.ns.worst.mask<-crop(current.2100.ns.worst.crop, current.ns.rp)

iStack<-stack(current.ns.rp, 
              current.2100.ns.best.mask,
              current.2100.ns.medium.mask,
              current.2100.ns.worst.mask)


names(iStack) <- c("Current", "Best", "Medium", "Worst")#rename the files for the panel plot 'names'

#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))


#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/NovaScotiaMultipanelZonationRanks.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#Nova Scotia Current Distribution 
current.ns.b <- current.ns
#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0.004
current.ns.b[current.ns < (0.004)] <- 0 
#what land you can lose (~0.4%) before starting to lose habitat for 100 % of current population
current.ns.b[current.ns >= 0.004] <- 1 
#what land you can lose and maintain habitat for 100 % of current population
current.ns.b[current.ns >= 0.32578] <- 2 
#what land you can lose and maintain habitat for 90 % of current population
current.ns.b[current.ns >= 0.56762] <- 3 
#what land you can lose and maintain habitat for 75 % of current population
current.ns.b[current.ns >= 0.82344] <- 4 
#what land you can lose and maintain habitat for 50 % of current population
plot(current.ns.b)

#view
tm_shape(current.ns.b) + tm_raster()
plot(current.ns.b)
writeRaster(current.ns.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NovaScotia/Zonation_current_only_NS/Zonation_current_only_NS.perc_popn_range.tif", overwrite=TRUE)

#Nova Scotia - Best Case
current.2100.ns.best.b <- current.2100.ns.best
#The current population in Year 0 is 26.62 % what is expected in 2100 (best case)
current.2100.ns.best.b[current.2100.ns.best < (0.50466)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.ns.best.b[current.2100.ns.best >= 0.50466] <- 1 
#what land you need to maintain habitat for 100 % of current population in 2100
current.2100.ns.best.b[current.2100.ns.best >= 0.84243] <- 2 
#what land you can lose before starting to lose habitat for 90 % of current population
current.2100.ns.best.b[current.2100.ns.best >= 0.92038] <- 3 
#what land you can lose before starting to lose habitat for 75 % of current population
current.2100.ns.best.b[current.2100.ns.best >= 0.97434] <- 4 
#what land you can lose before starting to lose habitat for 50 % of current population
plot(current.2100.ns.best.b)

#view
tm_shape(current.2100.ns.best.b) + tm_raster()
plot(current.2100.ns.best.b)
writeRaster(current.2100.ns.best.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Best/outputs/Zonation_current_plus_2100_NS_Best.perc_popn_range.tif", overwrite=TRUE)

#Nova Scotia - Medium Case
current.2100.ns.medium.b <- current.2100.ns.medium
#The current population in Year 0 is 34.84 % what is expected in 2100 (medium case)
current.2100.ns.medium.b[current.2100.ns.medium < (0.49966)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.ns.medium.b[current.2100.ns.medium >= 0.49966] <- 1 
#what land you need to maintain habitat for 100 % of current population in 2100
current.2100.ns.medium.b[current.2100.ns.medium >= 0.84843] <- 2 
#what land you can lose before starting to lose habitat for 90 % of current population
current.2100.ns.medium.b[current.2100.ns.medium >= 0.92138] <- 3 
#what land you can lose before starting to lose habitat for 75 % of current population
current.2100.ns.medium.b[current.2100.ns.medium >= 0.97434] <- 4 
#what land you can lose before starting to lose habitat for 50 % of current population
plot(current.2100.ns.medium.b)

#view
tm_shape(current.2100.ns.medium.b) + tm_raster()
plot(current.2100.ns.medium.b)
writeRaster(current.2100.ns.medium.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Medium/outputs/Zonation_current_plus_2100_NS_Medium.perc_popn_range.tif", overwrite=TRUE)

#Nova Scotia - Worst Case
current.2100.ns.worst.b <- current.2100.ns.worst
#The current population in Year 0 is 35.87 % what is expected in 2100 (worst case)
current.2100.ns.worst.b[current.2100.ns.worst < (0.50966)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2100.ns.worst.b[current.2100.ns.worst >= 0.50966] <- 1 
#what land you need to maintain habitat for 100 % of current population in 2100
current.2100.ns.worst.b[current.2100.ns.worst >= 0.84883] <- 2 
#what land you can lose before starting to lose habitat for 90 % of current population
current.2100.ns.worst.b[current.2100.ns.worst >= 0.92238] <- 3 
#what land you can lose before starting to lose habitat for 75 % of current population
current.2100.ns.worst.b[current.2100.ns.worst >= 0.97534] <- 4 
#what land you can lose before starting to lose habitat for 50 % of current population
plot(current.2100.ns.worst.b)

#view
tm_shape(current.2100.ns.worst.b) + tm_raster()
plot(current.2100.ns.worst.b)
writeRaster(current.2100.ns.worst.b, filename="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Worst/outputs/Zonation_current_plus_2100_NS_Worst.perc_popn_range.tif", overwrite=TRUE)



#stack the rasters for the panel plot
current.ns.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NovaScotia/Zonation_current_only_NS/Zonation_current_only_NS.perc_popn_range.tif")
current.ns.b.rp<-projectRaster(current.ns.b, crs=lcc_crs)

current.2100.ns.best.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Best/outputs/Zonation_current_plus_2100_NS_Best.perc_popn_range.tif")
current.2100.ns.best.b.rp<-projectRaster(current.2100.ns.best.b, crs=lcc_crs)

current.2100.ns.medium.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Medium/outputs/Zonation_current_plus_2100_NS_Medium.perc_popn_range.tif")
current.2100.ns.medium.b.rp<-projectRaster(current.2100.ns.medium.b, crs=lcc_crs)

current.2100.ns.worst.b<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Worst/outputs/Zonation_current_plus_2100_NS_Worst.perc_popn_range.tif")
current.2100.ns.worst.b.rp<-projectRaster(current.2100.ns.worst.b, crs=lcc_crs)


iStackB <- stack(current.ns.b.rp, 
                 current.2100.ns.best.b.rp,
                 current.2100.ns.medium.b.rp,
                 current.2100.ns.worst.b.rp)


names(iStackB) <- c("Current", "Best",
                    "Medium", "Worst")#rename the files for the panel plot 'names'

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

#heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090","#FDAE61","#F46D43", "#D73027", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
#cuts <- c(0.00, 0.60, 0.80,0.85, 0.90, 0.95, 1.00) #set breaks in ranking


heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
tiff('3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/NovaScotiapercentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=heatramp) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))#+ # extra shapefile data I want overlayed
#latticeExtra::layer(sp.lines(AlPacproj, col="black",lwd = 1.5)) 
# extra shapefile data I want overlayed but won't overlay for unknown reason
dev.off()

#Runtime plots
library(ggplot2)
library(grid)
library(gridExtra)

mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

current.ns.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NovaScotia/Zonation_current_only_NS/Zonation_current_only_NS.runtimeplot.csv")
plot1<- ggplot(data=current.ns.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.004,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.32578,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 90 % of current population
  geom_vline(xintercept = 0.56762,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.82344,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia", y="Proportion of Current Population Left", size=5)+
  annotate("text", x= 0.05, y = 0.125,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.34, y = 0.125,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.60, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.84, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot1, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_only_NovaScotia/Zonation_current_only_NS/Zonation_current_only_NS.runtimeplot.png", units="in", width=10, height=8)

current.2100.ns.best.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Best/outputs/Zonation_current_plus_2100_NS_Best.runtimeplot.csv")
plot2<- ggplot(data=current.2100.ns.best.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.50466,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.84243,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.92038,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.97434,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia (Best case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.52, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.86, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.94, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.99, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot2, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Best/outputs/Zonation_current_plus_2100_NS_Best.runtimeplot.png", units="in", width=10, height=8)

current.2100.ns.medium.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Medium/outputs/Zonation_current_plus_2100_NS_Medium.runtimeplot.csv")
plot3<- ggplot(data=current.2100.ns.medium.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.49966,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.84843,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.92138,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.97434,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia (Medium case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.51, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.86, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.94, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.99, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot3, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Medium/outputs/Zonation_current_plus_2100_NS_Medium.runtimeplot.png", units="in", width=10, height=8)

current.2100.quebec.worst.rt<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Worst/outputs/Zonation_current_plus_2100_NS_Worst.runtimeplot.csv")
plot4<- ggplot(data=current.2100.quebec.worst.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.50966,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 100 % of current population in 2100
  geom_vline(xintercept = 0.84883,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 90 % of current population
  geom_vline(xintercept = 0.92238,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 75 % of current population
  geom_vline(xintercept = 0.97534,  size=0.5, linetype="dashed")+
  #what land you can lose before starting to lose habitat for 50 % of current population
  labs(x = "Proportion of WOTH range lost in Nova Scotia (Worst case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.52, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.86, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.94, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.99, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot4, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_current_plus_2100_NS_Worst/outputs/Zonation_current_plus_2100_NS_Worst.runtimeplot.png", units="in", width=10, height=8)

plot5<-grid.arrange(plot1,plot2,plot3,plot4,nrow=2,ncol=2)
ggsave(plot5, file="3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/Zonation_NovaScotia.runtimeplots.png", units="in", width=12, height=8)

