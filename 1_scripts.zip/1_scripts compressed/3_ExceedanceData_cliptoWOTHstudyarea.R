library(data.table)
library(dismo)
library(dplyr)
library(ggplot2)
library(ggspatial)
library(raster)
library(rpart)
library(maptools)
library(rgdal)
theme_set(theme_bw())
library(sf)
lcc_crs <-"+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0
+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"

prov <- st_read("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
str(prov)
WOTHarea<-prov[prov$PRENAME=="Quebec"|prov$PRENAME=="Ontario"|prov$PRENAME=="New Brunswick"|prov$PRENAME=="Nova Scotia"|prov$PRENAME=="Prince Edward Island",]
WOTHsf <- st_transform(WOTHarea, lcc_crs)
ggplot() + 
  geom_sf(data = WOTHsf, size = 0.5, color = "black", fill = "white") + 
  ggtitle("Wood Thrush study area") + 
  coord_sf()

#need to dissolve provincial boundaries before using 
#Wood Thrush study area as a shape-file filter for
#clipping other shape-files
WOTHsf$area<-st_area(WOTHsf)
WOTHsf.D <-
  WOTHsf %>%
  summarise(area = sum(area))

#Exceedance measurements for critical loads sufficient to kill/damage 5 % of an area's trees
exceed.05 <- st_read("0_data/raw/Acidity/soilCL05_exc_2010/soilCL05_exc_2010.shp")

#all spatial polygon data frames in which crs = 
#"crs         : +proj=longlat +datum=NAD83 +no_defs" 
#From GNM-National scripts on Github
lcc_crs <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
exceed.05.sf <- sf::st_as_sf(exceed.05)
sf1 <- st_set_crs(exceed.05.sf, "+proj=longlat +datum=NAD83 +no_defs")
sf1 <- st_transform(sf1, lcc_crs)

ggplot() + 
  geom_sf(data = sf1, size = 0.5, color = "blue", fill = "cyan1") + 
  ggtitle("Exceedance Map - CL 5 %") + 
  coord_sf()
#This layer is mostly Canada wide except for parts of Prairie
#Provinces and southeast Ontario

#filter exceedance shape-files to just Wood Thrush study area
exceed.05.woth = 
  sf1 %>% 
  filter(st_contains(WOTHsf.D, ., sparse = FALSE))
ggplot() + 
  geom_sf(data = exceed.05.woth, size = 0.25, color = "blue", fill = "cyan1") + 
  geom_sf(data = WOTHsf, size = 0.25, color = "darkred", fill = NA) + 
  ggtitle("WOTH study area - Exceedance CL 5 %") + 
  coord_sf()

#now look at data: Exceedance
exceed.05.woth$Exceedance6655<-exceed.05.woth$Exceedance+6656
#Exceedance values made positive by adding 6656 to original values
#because colours can't be assigned to negative numbers
ggplot() + 
  geom_sf(data = exceed.05.woth, size = 0, color = exceed.05.woth$Exceedance6655, fill = exceed.05.woth$Exceedance6655) + 
  geom_sf(data = WOTHsf, size = 0.25, color = "darkred", fill = NA) + 
  ggtitle("WOTH study area - Exceedance CL 5 %") + 
  coord_sf()

#Now create rasters for each variable of interest in the shape-file
library(fasterize)
#use Wood Thrush study area raster as a template
wothstudyareamask<-raster("0_data/raw/Canada shapefile/wothstudyareamask.tif")

r.exceed.05.woth.exceedance<-fasterize(
  exceed.05.woth,
  wothstudyareamask,
  field = "Exceedance",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.05.woth.exceedance)

LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")

Cdn.range<-readOGR("0_data/raw/UpdatedCanadianRangeKernelDensity/UpdatedCanadianRangeKernelDensity.shp")

basemap.new <- spTransform(Cdn.range, lcc_crs)
str(basemap.new)

SScombo<-read.csv("0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv", header=TRUE)
nrow(SScombo)#238954 surveys
str(SScombo)#variables include elevation, topography, land cover, height, tree cover, roadyesno, climate, province
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")
SScombo2<-SpatialPointsDataFrame(coords=SScombo[,c("X","Y")],data=SScombo, proj4string = latlong)
SScombo2<-spTransform(SScombo2, CRS=lcc_crs)

png('0_data/raw/Acidity/raster layers I made/Exceedance.05.map.with.points.png', width = 20, height = 8, units = "in", res=300)
par(mfrow=c(1,2))
plot(r.exceed.05.woth.exceedance)
plot(basemap.new, add=TRUE, legend=FALSE)
plot(r.exceed.05.woth.exceedance)
plot(SScombo2, add=TRUE, pch=16, col="blue", fill=NA, cex=0.0025, alpha=I(1/2))
plot(basemap.new, add=TRUE, legend=FALSE)
dev.off()

png('0_data/raw/Acidity/raster layers I made/Exceedance.05.map.with.points.png', width = 10, height = 8, units = "in", res=300)
plot(r.exceed.05.woth.exceedance)
plot(SScombo2, add=TRUE, pch=16, col="blue", fill=NA, cex=0.0025, alpha=I(1/2))
plot(basemap.new, add=TRUE, legend=FALSE)
dev.off()

writeRaster(r.exceed.05.woth.exceedance, filename="0_data/raw/Acidity/raster layers I made/Exceedance05.WOTH.tif", overwrite=TRUE)
#saves exceedance values for critical loads of nitrogen and sulfur,
#above which 5 % of trees are negatively affected, as a raster layer

r.exceed.05.woth.ndep<-fasterize(
  exceed.05.woth,
  wothstudyareamask,
  field = "ndep",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.05.woth.ndep)
writeRaster(r.exceed.05.woth.ndep, filename="0_data/raw/Acidity/raster layers I made/DepositedN.WOTH.tif", overwrite=TRUE)
#saves total deposited nitrogen as a raster layer

r.exceed.05.woth.sdep<-fasterize(
  exceed.05.woth,
  wothstudyareamask,
  field = "sdep",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.05.woth.sdep)
writeRaster(r.exceed.05.woth.sdep, filename="0_data/raw/Acidity/raster layers I made/DepositedS.WOTH.tif", overwrite=TRUE)
#saves total deposited sulfur as a raster layer

r.exceed.05.woth.CL05N<-fasterize(
  exceed.05.woth,
  wothstudyareamask,
  field = "CLMAXN_5",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.05.woth.CL05N)
writeRaster(r.exceed.05.woth.CL05N, filename="0_data/raw/Acidity/raster layers I made/CLMAXN_5percentTrees.WOTH.tif", overwrite=TRUE)
#saves max critical load of nitrogen before 5 % of trees are
#negatively affected, as raster layer

r.exceed.05.woth.CL05S<-fasterize(
  exceed.05.woth,
  wothstudyareamask,
  field = "CLMAXS_5",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.05.woth.CL05S)
writeRaster(r.exceed.05.woth.CL05S, filename="0_data/raw/Acidity/raster layers I made/CLMAXS_5percentTrees.WOTH.tif", overwrite=TRUE)
#saves max critical load of sulfur before 5 % of trees are
#negatively affected, as raster layer


#Now do the same steps for the exceedance shape file based
#on critical loads before 20 % of an area's trees are negatively
#affected
#Exceedance measurements for critical loads sufficient to kill/damage 5 % of an area's trees
exceed.20 <- st_read("0_data/raw/Acidity/soilCL20_exc_2010/soilCL20_exc_2010.shp")

#all spatial polygon data frames in which crs = 
#"crs         : +proj=longlat +datum=NAD83 +no_defs" 
#From GNM-National scripts on Github
lcc_crs <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
exceed.20.sf <- sf::st_as_sf(exceed.20)
sf2 <- st_set_crs(exceed.20.sf, "+proj=longlat +datum=NAD83 +no_defs")
sf2 <- st_transform(sf2, lcc_crs)

ggplot() + 
  geom_sf(data = sf2, size = 0.5, color = "blue", fill = "cyan1") + 
  ggtitle("Exceedance Map - CL 20 %") + 
  coord_sf()
#This layer is mostly Canada wide except for parts of Prairie
#Provinces and southeast Ontario

#filter exceedance shape-files to just Wood Thrush study area
exceed.20.woth = 
  sf2 %>% 
  filter(st_contains(WOTHsf.D, ., sparse = FALSE))
ggplot() + 
  geom_sf(data = exceed.20.woth, size = 0.25, color = "blue", fill = "cyan1") + 
  geom_sf(data = WOTHsf, size = 0.25, color = "darkred", fill = NA) + 
  ggtitle("WOTH study area - Exceedance CL 20 %") + 
  coord_sf()

#now look at data: Exceedance
exceed.20.woth$Exceedance11796<-exceed.20.woth$Exceedance+11797
#Exceedance values made positive by adding 6656 to original values
#because colours can't be assigned to negative numbers
ggplot() + 
  geom_sf(data = exceed.20.woth, size = 0, color = exceed.20.woth$Exceedance11796, fill = exceed.20.woth$Exceedance11796) + 
  geom_sf(data = WOTHsf, size = 0.25, color = "darkred", fill = NA) + 
  ggtitle("WOTH study area - Exceedance CL 20 %") + 
  coord_sf()

r.exceed.20.woth.exceedance<-fasterize(
  exceed.20.woth,
  wothstudyareamask,
  field = "Exceedance",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.20.woth.exceedance)
writeRaster(r.exceed.20.woth.exceedance, filename="0_data/raw/Acidity/raster layers I made/Exceedance20.WOTH.tif", overwrite=TRUE)
#saves exceedance values for critical loads of nitrogen and sulfur,
#above which 20 % of trees are negatively affected, as a raster layer

r.exceed.20.woth.CL20N<-fasterize(
  exceed.20.woth,
  wothstudyareamask,
  field = "CLMAXN_20",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.20.woth.CL20N)
writeRaster(r.exceed.20.woth.CL20N, filename="0_data/raw/Acidity/raster layers I made/CLMAXN_20percentTrees.WOTH.tif", overwrite=TRUE)
#saves max critical load of nitrogen before 20 % of trees are
#negatively affected, as raster layer

r.exceed.20.woth.CL20S<-fasterize(
  exceed.20.woth,
  wothstudyareamask,
  field = "CLMAXS_20",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.exceed.20.woth.CL20S)
writeRaster(r.exceed.20.woth.CL20S, filename="0_data/raw/Acidity/raster layers I made/CLMAXS_20percentTrees.WOTH.tif", overwrite=TRUE)
#saves max critical load of sulfur before 20 % of trees are
#negatively affected, as raster layer

