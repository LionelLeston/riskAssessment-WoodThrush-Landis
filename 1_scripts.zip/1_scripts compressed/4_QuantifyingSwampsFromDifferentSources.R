memory.limit(size=500000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

#Ag Canada annual cover layers for individual provinces in 2011, 2015, 2019: 30-
#These data do not separate out swamp from other wetland types.
#Wood Thrush use swamps as habitat according to Karl Heide.
#Some Shrub pixels in Ag Can Landsat layers may actually be swamps

#Swamp layers must be compiled from separate sources since there are no 
#national layers.

#Once a 30-m raster is created for each province, process it the same way
#as the annual cover layers

#read in raster

#Ontario Swamp Layer
swamp<-c("OLCswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data/raw/Wetlands/Ontario Land Cover/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data/raw/Wetlands/Ontario Land Cover/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}

#Quebec Swamp Layer
swamp<-c("Quebecswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}

#New Brunswick Swamp Layer
swamp<-c("NewBrunswickswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}

#Nova Scotia Swamp Layer
swamp<-c("NovaScotiaswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data/raw/Wetlands/Wetlands From Nova Scotia Forest Inventory/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data/raw/Wetlands/Wetlands From Nova Scotia Forest Inventory/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}


#Aggregate (resample to coarser resolution to speed up processing)
#Ontario
rlist <- list.files("0_data/raw/Wetlands/Ontario Land Cover/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data/raw/Wetlands/Ontario Land Cover/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data/raw/Wetlands/Ontario Land Cover/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}

rlist2 <- list.files("0_data/raw/Wetlands/Ontario Land Cover/150 m/",pattern="150m.tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data/raw/Wetlands/Ontario Land Cover/150 m/",i))
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("150m","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data/raw/Wetlands/Ontario Land Cover/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}


rlist3 <- list.files("0_data/raw/Wetlands/Ontario Land Cover/150 m/",pattern="150m.tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data/raw/Wetlands/Ontario Land Cover/150 m/",i))
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("150m","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data/raw/Wetlands/Ontario Land Cover/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

rlist4 <- list.files("0_data/raw/Wetlands/Ontario Land Cover/150 m/",pattern="150m.tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data/raw/Wetlands/Ontario Land Cover/150 m/",i))
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("150m","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data/raw/Wetlands/Ontario Land Cover/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
}


#Quebec
rlist <- list.files("0_data/raw/Wetlands/Quebec Wetland Inventory/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}

rlist2 <- list.files("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",pattern="150m.tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",i))
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("150m","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}


rlist3 <- list.files("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",pattern="150m.tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",i))
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("150m","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

rlist4 <- list.files("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",pattern="150m.tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/150 m/",i))
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("150m","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data/raw/Wetlands/Quebec Wetland Inventory/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
}


#New Brunswick
rlist <- list.files("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}

rlist2 <- list.files("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",pattern="150m.tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",i))
  #ras<-raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("150m","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}


rlist3 <- list.files("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",pattern="150m.tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",i))
  #ras<-raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("150m","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

rlist4 <- list.files("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",pattern="150m.tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",i))
  #ras<-raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("150m","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
}


#Nova Scotia
rlist <- list.files("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}

rlist2 <- list.files("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",pattern="150m.tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",i))
  #ras<-raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("150m","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}


rlist3 <- list.files("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",pattern="150m.tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",i))
  #ras<-raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("150m","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

rlist4 <- list.files("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",pattern="150m.tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",i))
  #ras<-raster("0_data/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("150m","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
}

#Resampling to 250-m resolution
rlist5 <- list.files("0_data/raw/Wetlands/150 m/",pattern=".tif$")
for (i in rlist5){
  ras<-raster(paste0("0_data/raw/Wetlands/150 m/",i))
  #change resolution from 150x150 to 250x250
  resampleFactor <- 250/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-250#set to exactly 250 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data/raw/Wetlands/resampled to 250 m/150 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

rlist6 <- list.files("0_data/raw/Wetlands/250 m/",pattern=".tif$")
for (i in rlist6){
  ras<-raster(paste0("0_data/raw/Wetlands/250 m/",i))
  #change resolution from 150x150 to 250x250
  resampleFactor <- 250/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-250#set to exactly 250 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data/raw/Wetlands/resampled to 250 m/250 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

rlist7 <- list.files("0_data/raw/Wetlands/1000 m/",pattern=".tif$")
for (i in rlist7){
  ras<-raster(paste0("0_data/raw/Wetlands/1000 m/",i))
  #change resolution from 150x150 to 250x250
  resampleFactor <- 250/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-250#set to exactly 250 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data/raw/Wetlands/resampled to 250 m/1000 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

rlist8 <- list.files("0_data/raw/Wetlands/2000 m/",pattern=".tif$")
for (i in rlist8){
  ras<-raster(paste0("0_data/raw/Wetlands/2000 m/",i))
  #change resolution from 150x150 to 250x250
  resampleFactor <- 250/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-250#set to exactly 250 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data/raw/Wetlands/resampled to 250 m/2000 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}
