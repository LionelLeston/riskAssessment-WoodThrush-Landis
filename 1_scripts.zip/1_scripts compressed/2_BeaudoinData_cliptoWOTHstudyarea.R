library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

#Beaudoin layers: these Canada-wide layers 
#have been used to describe forest structure for birds in
#other Boreal Avian Project models and for Canada Warbler 
#critical habitat models developed by Francisco Denes.
#They can also be used to fill in gaps in the 
#vegetation data, which by default would be CASFRI. 

#A decision was made to not use the individual tree species data within
#the Beaudoin layers for regional models of Wood Thrush and 
#to use other more recent land cover data at finer spatial resolution
#to describe forests (albeit as coniferous, mixedwood, or deciduous)
#and swamps.

#Other Beaudoin forest structure and composition variables that
#are output from Landis scenarios (age, biomass) will be considered.

#After national layers relevant to the Wood Thrush study area are read into R,
#they are clipped with crop and mask functions to a Wood Thrush study area
#shapefile comprising Ontario, Quebec, New Brunswick, and Nova Scotia. Data 
#from 2001 and 2011 are clipped to the study area and stored separately. 
#The stacks can later be used with a Gaussian filter to summarize data at 
#larger spatial scales.

####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#                   STEP ONE - CLIP NATIONAL LAYERS                #
#                        TO SMALLER AREA                           #
#                                                                  #
#                                                                  #
####################################################################


#First, we need a tif file of the Wood Thrush study area
library(sf)
lcc_crs <-"+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0
+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
lat_long <- "+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0"

#setwd("E:/Beaudoin/")
prov <- st_read("0_data/raw/UpdatedCanadianRangeKernelDensity/UpdatedCanadianRangeKernelDensity.shp")
str(prov)
#on<-prov[prov$STATEABB=="CA-ON",]
#st_write(on, "0_data/raw/UpdatedCanadianRangeKernelDensity/UpdatedRangeKD_JustOntario.shp")

st_crs(prov)<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0"
WOTHsf <- st_transform(prov, lcc_crs)
ggplot() + 
  geom_sf(data = WOTHsf, size = 0.5, color = "black", fill = "white") + 
  ggtitle("Wood Thrush study area") + 
  coord_sf()

extent(WOTHsf)
#e. Now use the raster package to convert to a raster and set its CRS
#r.0E = raster()#default
#extent(r.0E) = extent(bcsf)
#projection(r.0E) = CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0
#+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")
#res(r.0E)<-250#set resolution to 250 m, same as Beaudoin
#rp <- rasterize(bcsf, r.0E, 'PRNAME')

b2001 <- list.files("0_data/raw/Beaudoin/2001/CanadaWideLayers/",pattern="tif$")
#Beaudoin 2001 layers
for (i in 1:length(b2001)) { 
  bs2001 <- raster(paste0("0_data/raw/Beaudoin/2001/CanadaWideLayers/",b2001[i]))
  names(bs2001) <- gsub("NFI_MODIS250m_2001_kNN","local",names(bs2001))
  bs2001.crop<-crop(bs2001, WOTHsf)
  bs2001.mask<-crop(bs2001.crop, WOTHsf)
  writeRaster(bs2001.mask, filename=paste0("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",names(bs2001.crop),".tif"),overwrite=TRUE)
}


b2011 <- list.files("0_data/raw/Beaudoin/2011/CanadaWideLayers/",pattern="tif$")
#Beaudoin 2011 layers
for (i in 1:length(b2011)) { 
  bs2011 <- raster(paste0("0_data/raw/Beaudoin/2011/CanadaWideLayers/",b2011[i]))
  names(bs2011) <- gsub("NFI_MODIS250m_2011_kNN","local",names(bs2011))
  bs2011.crop<-crop(bs2011, WOTHsf)
  bs2011.mask<-crop(bs2011.crop, WOTHsf)
  writeRaster(bs2011.mask, filename=paste0("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",names(bs2011.crop),".tif"),overwrite=TRUE)
}

#once 2011 local rasters are made, create a total biomass raster

live<-raster("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/local_Structure_Biomass_TotalLiveAboveGround_v1.tif")
dead<-raster("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/local_Structure_Biomass_TotalDead_v1.tif")
total<-live+dead
writeRaster(total, filename="0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/local_TotalBiomass_v1.tif",overwrite=TRUE)

####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#                   STEP TWO - GET LANDSCAPE METRICS               #
#                        FROM 2001 DATA                            #
#                                                                  #
#                                                                  #
####################################################################

#Once you clipped each raster to the study area, you will use it to extract
#landscape metrics at larger spatial scales.
rlist2 <- list.files("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",pattern=".tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",i))
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("v1","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data/raw/Beaudoin/2001/Processed/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}


rlist3 <- list.files("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",pattern=".tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",i))
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("v1","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data/raw/Beaudoin/2001/Processed/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

rlist4 <- list.files("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",pattern=".tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data/raw/Beaudoin/2001/Processed/Beaudoin 2001 TIFFs WOTHstudyarea/",i))
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("v1","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data/raw/Beaudoin/2001/Processed/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
  rm(ras, ras_Gauss2000)
  gc()
}



####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#                   STEP THREE - GET LANDSCAPE METRICS             #
#                        FROM 2011 DATA                            #
#                                                                  #
#                                                                  #
####################################################################


#Once you clipped each raster to the study area, you will use it to extract
#landscape metrics at larger spatial scales.
rlist2 <- list.files("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",pattern=".tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",i))
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("v1","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data/raw/Beaudoin/2011/Processed/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}

#once 250-m rasters for 2011 are made, create a total biomass raster
live<-raster("0_data/raw/Beaudoin/2011/Processed/250 m/local_Structure_Biomass_TotalLiveAboveGround_250m.tif")
dead<-raster("0_data/raw/Beaudoin/2011/Processed/250 m/local_Structure_Biomass_TotalDead_250m.tif")
total<-live+dead
writeRaster(total, filename="0_data/raw/Beaudoin/2011/Processed/250 m/local_TotalBiomass_250m.tif",overwrite=TRUE)


rlist3 <- list.files("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",pattern=".tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",i))
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("v1","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data/raw/Beaudoin/2011/Processed/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

#once 1000-m rasters for 2011 are made, create a total biomass raster
live<-raster("0_data/raw/Beaudoin/2011/Processed/1000 m/local_Structure_Biomass_TotalLiveAboveGround_1000m.tif")
dead<-raster("0_data/raw/Beaudoin/2011/Processed/1000 m/local_Structure_Biomass_TotalDead_1000m.tif")
total<-live+dead
writeRaster(total, filename="0_data/raw/Beaudoin/2011/Processed/1000 m/local_TotalBiomass_1000m.tif",overwrite=TRUE)

rlist4 <- list.files("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",pattern=".tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/",i))
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("v1","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data/raw/Beaudoin/2011/Processed/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
  rm(ras, ras_Gauss2000)
  gc()
}

#once 2000-m rasters for 2011 are made, create a total biomass raster
live<-raster("0_data/raw/Beaudoin/2011/Processed/2000 m/local_Structure_Biomass_TotalLiveAboveGround_2000m.tif")
dead<-raster("0_data/raw/Beaudoin/2011/Processed/2000 m/local_Structure_Biomass_TotalDead_2000m.tif")
total<-live+dead
writeRaster(total, filename="0_data/raw/Beaudoin/2011/Processed/2000 m/local_TotalBiomass_2000m.tif",overwrite=TRUE)
