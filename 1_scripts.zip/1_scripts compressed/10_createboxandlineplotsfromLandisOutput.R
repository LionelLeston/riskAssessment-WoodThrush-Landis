#The purpose of this script is to generate box plots and
#line plots of projected Wood Thrush population under 
#different land use scenarios in different study areas.

#Some current predicted densities (<<<1% of a study area's pixels) are unusually high 
#compared to observed Wood Thrush densities in real life in different areas
#These current predicted densities are adjusted to a threshold density (currently 1.0)
#before creating the estimating population sizes, and 
#identifying best-case, medium-case, and worst-case Zonation exercises. 

#For an example of where to change the threshold values, see line 108 in this script.


###############################################
#                                             #
#                                             #
#              QUEBEC 123est                  #
#                                             #
#                                             #
###############################################

#Make a box plot showing projected populations by 2100 under different scenarios

popproj2100<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/DensityTotal.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2100)
#'data.frame':	30 obs. of  6 variables:
#$ X          : int  1 2 3 4 5 6 7 8 9 10 ...
#$ Year       : int  2100 2100 2100 2100 2100 2100 2100 2100 2100 2100 ...
#$ Scenario   : chr  "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" ...
#$ Replicate  : int  1 2 3 4 5 1 2 3 4 5 ...
#$ MeanDensity: num  0.106 0.106 0.106 0.106 0.106 ...
#$ PopSize    : num  1368567 1368766 1367770 1369195 1369378 ...
#$ AdjustedMeanDensity: num  0.102 0.102 0.102 0.102 0.102 ...
#$ AdjustedPopSize    : num  1318032 1318701 1317938 1320501 1320436 ...

#levels(as.factor(popproj2100$Scenario))
#[1] "baseline_BudwormBaselineFire"                   
#[2] "baseline_BudwormBaselineFireBaselineHarvest"    
#[3] "RCP45_GrowthBudwormProjectedFire"               
#[4] "RCP45_GrowthBudwormProjectedFireBaselineHarvest"
#[5] "RCP85_GrowthBudwormProjectedFire"               
#[6] "RCP85_GrowthBudwormProjectedFireBaselineHarvest"
popproj2100$Scenario.Renamed<-popproj2100$Scenario
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFire"]<-"Baseline No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFireBaselineHarvest"]<-"Baseline With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFire"]<-"RCP45 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP45 With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFire"]<-"RCP85 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP85 With Harvest"

#there are 6 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 4.5, and RCP 8.5
# grouped boxplot

P1<-ggplot(popproj2100, aes(x=Scenario.Renamed, y=AdjustedPopSize, col=Scenario, fill=Scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest and Climate Scenario")+
  ylab("Wood Thrush Projected 2100 Population - \n Quebec 123est Study Area")+ 
  theme(axis.text.x=element_text(angle=45,hjust=1))+
  guides(col=FALSE)
ggsave(P1, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/WOTH2100.box.harvestXclimateL.png", units="in", width=10, height=4)


#Make a simple line plot

library(maptools)
library(raster)
library(rgdal)
library(sp)

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs <- "+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs"

#get Landis study area mask for Quebec
QuebecLandis<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/123est.ras.tif")
QuebecLandisB<-projectRaster(QuebecLandis, crs=lcc_crs)

meanDens2020B<-projectRaster(meanDens2020, QuebecLandisB)
meanDens2020.crop<-crop(meanDens2020B, QuebecLandisB)
meanDens2020C<-mask(meanDens2020.crop, QuebecLandisB)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.
density_brt_2020_250m.qu<-meanDens2020D*6.25
popsize2020.qu<-cellStats(density_brt_2020_250m.qu, stat=sum, na.rm=T) 
#648801.2 THIS IS ESTIMATED CURRENT POPULATION SIZE IN QUEBEC IN THE 123est STUDY AREA.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.

popproj2020<-popproj2100
#create a data frame with same number of observations and variables as
#popproj2100 but switch out the year and popsize values with Year 0 estimate
#for 2020
popproj2020$Year<-2020
popproj2020$AdjustedPopSize<-popsize2020.qu

popproj2020.2100<-rbind(popproj2020, popproj2100)

P2<-ggplot(popproj2020.2100, aes(x=Year, y=PopSize, col=Scenario.Renamed, fill=Scenario.Renamed)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Wood Thrush Projected 2100 Population - \n Quebec 123est Study Area")#+ 
#Do not use Popsize
ggsave(P2, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/WOTH2020-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)

###############################################
#                                             #
#                                             #
#              QUEBEC 345ouest                #
#                                             #
#                                             #
###############################################

#Make a box plot showing projected populations by 2100 under different scenarios

popproj2100<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/DensityTotal.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2100)

#levels(as.factor(popproj2100$Scenario))
#[1] "baseline_BudwormBaselineFire"                   
#[2] "baseline_BudwormBaselineFireBaselineHarvest"    
#[3] "RCP45_GrowthBudwormProjectedFire"               
#[4] "RCP45_GrowthBudwormProjectedFireBaselineHarvest"
#[5] "RCP85_GrowthBudwormProjectedFire"               
#[6] "RCP85_GrowthBudwormProjectedFireBaselineHarvest"
popproj2100$Scenario.Renamed<-popproj2100$Scenario
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFire"]<-"Baseline No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFireBaselineHarvest"]<-"Baseline With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFire"]<-"RCP45 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP45 With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFire"]<-"RCP85 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP85 With Harvest"

#there are 6 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 4.5, and RCP 8.5
# grouped boxplot

P1<-ggplot(popproj2100, aes(x=Scenario.Renamed, y=AdjustedPopSize, col=Scenario, fill=Scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest and Climate Scenario")+
  ylab("Wood Thrush Projected 2100 Population - \n Quebec 345ouest Study Area")+ 
  theme(axis.text.x=element_text(angle=45,hjust=1))+
  guides(col=FALSE)
#Do not use Popsize
ggsave(P1, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/WOTH2100.box.harvestXclimateL.png", units="in", width=10, height=4)


#Make a simple line plot

library(maptools)
library(raster)
library(rgdal)
library(sp)

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs<-"+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.345ouest

#get Landis study area mask for Quebec
QuebecLandis<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/345ouest.ras.tif")
QuebecLandisB<-projectRaster(QuebecLandis, crs=lcc_crs)

meanDens2020B<-projectRaster(meanDens2020, QuebecLandisB)
meanDens2020.crop<-crop(meanDens2020B, QuebecLandisB)
meanDens2020C<-mask(meanDens2020.crop, QuebecLandisB)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.
density_brt_2020_250m.qu<-meanDens2020D*6.25
popsize2020.qu<-cellStats(density_brt_2020_250m.qu, stat=sum, na.rm=T) 
#469311.7 THIS IS ESTIMATED CURRENT POPULATION SIZE IN QUEBEC IN THE 345ouest STUDY AREA.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.

popproj2020<-popproj2100
#create a data frame with same number of observations and variables as
#popproj2100 but switch out the year and popsize values with Year 0 estimate
#for 2020
popproj2020$Year<-2020
popproj2020$AdjustedPopSize<-popsize2020.qu

popproj2020.2100<-rbind(popproj2020, popproj2100)

P2<-ggplot(popproj2020.2100, aes(x=Year, y=AdjustedPopSize, col=Scenario.Renamed, fill=Scenario.Renamed)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Wood Thrush Projected 2100 Population - \n Quebec 345ouest Study Area")#+ 
#Do not use Popsize
ggsave(P2, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/WOTH2020-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)


###############################################
#                                             #
#                                             #
#              QUEBEC 45est                   #
#                                             #
#                                             #
###############################################

#Make a box plot showing projected populations by 2100 under different scenarios

popproj2100<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/DensityTotal.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2100)

#levels(as.factor(popproj2100$Scenario))
#[1] "baseline_BudwormBaselineFire"                   
#[2] "baseline_BudwormBaselineFireBaselineHarvest"    
#[3] "RCP45_GrowthBudwormProjectedFire"               
#[4] "RCP45_GrowthBudwormProjectedFireBaselineHarvest"
#[5] "RCP85_GrowthBudwormProjectedFire"               
#[6] "RCP85_GrowthBudwormProjectedFireBaselineHarvest"
popproj2100$Scenario.Renamed<-popproj2100$Scenario
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFire"]<-"Baseline No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFireBaselineHarvest"]<-"Baseline With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFire"]<-"RCP45 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP45 With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFire"]<-"RCP85 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP85 With Harvest"

#there are 6 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 4.5, and RCP 8.5
# grouped boxplot

P1<-ggplot(popproj2100, aes(x=Scenario.Renamed, y=AdjustedPopSize, col=Scenario, fill=Scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest and Climate Scenario")+
  ylab("Wood Thrush Projected 2100 Population - \n Quebec 45est Study Area")+ 
  theme(axis.text.x=element_text(angle=45,hjust=1))+
  guides(col=FALSE)
ggsave(P1, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/WOTH2100.box.harvestXclimateL.png", units="in", width=10, height=4)


#Make a simple line plot

library(maptools)
library(raster)
library(rgdal)
library(sp)

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs <- "+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"

#get Landis study area mask for Quebec
QuebecLandis<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/45est.ras.tif")
QuebecLandisB<-projectRaster(QuebecLandis, crs=lcc_crs)

meanDens2020B<-projectRaster(meanDens2020, QuebecLandisB)
meanDens2020.crop<-crop(meanDens2020B, QuebecLandisB)
meanDens2020C<-mask(meanDens2020.crop, QuebecLandisB)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.
density_brt_2020_250m.qu<-meanDens2020D*6.25
popsize2020.qu<-cellStats(density_brt_2020_250m.qu, stat=sum, na.rm=T) 
#168889.4 THIS IS ESTIMATED CURRENT POPULATION SIZE IN QUEBEC IN THE 45est STUDY AREA.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.

popproj2020<-popproj2100
#create a data frame with same number of observations and variables as
#popproj2100 but switch out the year and popsize values with Year 0 estimate
#for 2020
popproj2020$Year<-2020
popproj2020$AdjustedPopSize<-popsize2020.qu

popproj2020.2100<-rbind(popproj2020, popproj2100)

P2<-ggplot(popproj2020.2100, aes(x=Year, y=AdjustedPopSize, col=Scenario.Renamed, fill=Scenario.Renamed)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Wood Thrush Projected 2100 Population - \n Quebec 45est Study Area")#+ 
#Do not use Popsize

ggsave(P2, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/WOTH2020-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)


###############################################
#                                             #
#                                             #
#              NEW BRUNSWICK                  #
#                                             #
#                                             #
###############################################

#Make a box plot showing projected populations by 2100 under different scenarios

popproj2100<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/DensityTotal.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2100)
#'data.frame':	15 obs. of  6 variables:
#$ X          : int  1 2 3 4 5 6 7 8 9 10 ...
#$ Year       : int  2100 2100 2100 2100 2100 2100 2100 2100 2100 2100 ...
#$ Scenario   : chr  "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" "baseline_BudwormBaselineFire" ...
#$ Replicate  : int  1 2 3 4 5 1 2 3 4 5 ...
# $ MeanDensity: num  0.0353 0.0346 0.0343 0.0357 0.0348 ...
#$ PopSize    : num  264480 259231 256596 267585 260575 ...

#levels(as.factor(popproj2100$Scenario))
#[1] "baseline_BudwormBaselineFire"                   
#[2] "baseline_BudwormBaselineFireBaselineHarvest"    
#[3] "RCP45_GrowthBudwormProjectedFire"               
#[4] "RCP45_GrowthBudwormProjectedFireBaselineHarvest"
#[5] "RCP85_GrowthBudwormProjectedFire"               
#[6] "RCP85_GrowthBudwormProjectedFireBaselineHarvest"
popproj2100$Scenario.Renamed<-popproj2100$Scenario
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFireBaselineHarvest"]<-"Baseline With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP45 With Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFireBaselineHarvest"]<-"RCP85 With Harvest"

#there are 3 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 4.5, and RCP 8.5
# grouped boxplot

P1<-ggplot(popproj2100, aes(x=Scenario.Renamed, y=AdjustedPopSize, col=Scenario, fill=Scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest and Climate Scenario")+
  ylab("Wood Thrush Projected 2100 Population - \n New Brunswick Study Area")+ 
  theme(axis.text.x=element_text(angle=45,hjust=1))+
  guides(col=FALSE)
#do not use Popsize
ggsave(P1, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/WOTH2100.box.harvestXclimateL.png", units="in", width=10, height=4)


#Make a simple line plot

library(maptools)
library(raster)
library(rgdal)
library(sp)

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_NewBrunswick.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.nb

#get Landis study area mask for New Brunswick
provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
NewBrunswick<-provs[provs$PRENAME=="New Brunswick",]
#needs to be reprojected to lcc_crs
NewBrunswickB<-spTransform(NewBrunswick, CRS=lcc_crs)

meanDens2020B<-projectRaster(meanDens2020, crs=lcc_crs)
meanDens2020.crop<-crop(meanDens2020B, NewBrunswickB)
meanDens2020C<-mask(meanDens2020.crop, NewBrunswickB)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.
density_brt_2020_250m.nb<-meanDens2020D*6.25
popsize2020.nb<-cellStats(density_brt_2020_250m.nb, stat=sum, na.rm=T) 
#166639.5 THIS IS ESTIMATED CURRENT POPULATION SIZE IN NEW BRUNSWICK IN THE STUDY AREA.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.

popproj2020<-popproj2100
#create a data frame with same number of observations and variables as
#popproj2100 but switch out the year and popsize values with Year 0 estimate
#for 2020
popproj2020$Year<-2020
popproj2020$AdjustedPopSize<-popsize2020.nb

popproj2020.2100<-rbind(popproj2020, popproj2100)

P2<-ggplot(popproj2020.2100, aes(x=Year, y=AdjustedPopSize, col=Scenario.Renamed, fill=Scenario.Renamed)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Wood Thrush Projected 2100 Population - \n New Brunswick Study Area")#+ 
#do not use Popsize
ggsave(P2, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/WOTH2020-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)


###############################################
#                                             #
#                                             #
#              NOVA SCOTIA                    #
#                                             #
#                                             #
###############################################


#Make a box plot showing projected populations by 2100 under different scenarios

popproj2100<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/DensityTotal.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2100)

levels(as.factor(popproj2100$Scenario))
#[1] "baseline_BudwormBaselineFire"                   
#[2] "baseline_BudwormBaselineFireEBFMHarvest"        
#[3] "baseline_BudwormBaselineFireHighCPRSHarvest"    
#[4] "RCP45_GrowthBudwormProjectedFire"               
#[5] "RCP45_GrowthBudwormProjectedFireEBFMHarvest"    
#[6] "RCP45_GrowthBudwormProjectedFireHighCPRSHarvest"
#[7] "RCP85_GrowthBudwormProjectedFire"               
#[8] "RCP85_GrowthBudwormProjectedFireEBFMHarvest"    
#[9] "RCP85_GrowthBudwormProjectedFireHighCPRSHarvest"
popproj2100$Scenario.Renamed<-popproj2100$Scenario
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFire"]<-"Baseline No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFire"]<-"RCP45 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFire"]<-"RCP85 No Harvest"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFireEBFMHarvest"]<-"Baseline EBFM"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFireEBFMHarvest"]<-"RCP45 EBFM"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFireEBFMHarvest"]<-"RCP85 EBFM"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="baseline_BudwormBaselineFireHighCPRSHarvest"]<-"Baseline Historic Clear-cut"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP45_GrowthBudwormProjectedFireHighCPRSHarvest"]<-"RCP45 Historic Clear-cut"
popproj2100$Scenario.Renamed[popproj2100$Scenario=="RCP85_GrowthBudwormProjectedFireHighCPRSHarvest"]<-"RCP85 Historic Clear-cut"

#there are 3 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 4.5, and RCP 8.5
# grouped boxplot

P1<-ggplot(popproj2100, aes(x=Scenario.Renamed, y=AdjustedPopSize, col=Scenario, fill=Scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest and Climate Scenario")+
  ylab("Wood Thrush Projected 2100 Population - \n Nova Scotia Study Area")+ 
  theme(axis.text.x=element_text(angle=45,hjust=1))+
  guides(col=FALSE)
#do not use Popsize
ggsave(P1, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/WOTH2100.box.harvestXclimateL.png", units="in", width=10, height=4)


#Make a simple line plot

library(maptools)
library(raster)
library(rgdal)
library(sp)

#2020 (Year "0")
meanDens2020<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_NovaScotiaSep2021.tif")
#need to be reprojected in Lambert Conformal Conic
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.ns

#get Landis study area mask for New Brunswick
provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
NovaScotia<-provs[provs$PRENAME=="Nova Scotia",]
#needs to be reprojected to lcc_crs
NovaScotiaB<-spTransform(NovaScotia, CRS=lcc_crs)

meanDens2020B<-projectRaster(meanDens2020, crs=lcc_crs)
meanDens2020.crop<-crop(meanDens2020B, NovaScotiaB)
meanDens2020C<-mask(meanDens2020.crop, NovaScotiaB)
meanDens2020D<-meanDens2020C
meanDens2020D[meanDens2020C>1]<-1
#adjusts unusually high densities to a threshold value of 1
#based on observed densities of Wood Thrush. This threshold can
#be changed.
density_brt_2020_250m.ns<-meanDens2020D*6.25
popsize2020.ns<-cellStats(density_brt_2020_250m.ns, stat=sum, na.rm=T) 
#69613.92 THIS IS ESTIMATED CURRENT POPULATION SIZE IN NOVA SCOTIA IN THE STUDY AREA.
#Knowing this size relative to the regional population size
#in the future will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.

popproj2020<-popproj2100
#create a data frame with same number of observations and variables as
#popproj2100 but switch out the year and popsize values with Year 0 estimate
#for 2020
popproj2020$Year<-2020
popproj2020$AdjustedPopSize<-popsize2020.ns

popproj2020.2100<-rbind(popproj2020, popproj2100)

P2<-ggplot(popproj2020.2100, aes(x=Year, y=AdjustedPopSize, col=Scenario.Renamed, fill=Scenario.Renamed)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Wood Thrush Projected 2100 Population - \n Nova Scotia Study Area")#+ 
#do not use Popsize
ggsave(P2, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/WOTH2020-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)


