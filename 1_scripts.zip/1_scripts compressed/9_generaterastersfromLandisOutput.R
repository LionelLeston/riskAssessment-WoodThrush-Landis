#The purpose of this script is to obtain the rasters from each set of Landis
#outputs for predicted Wood Thrush abundance in the Quebec, New Brunswick, and
#Nova Scotia study areas. Wood Thrush densities have already been predicted from
#the Landis output using the BRT bootstraps from the selected-scales BRT model at
#250-m resolution. However, since only forested areas were simulated and examined
#within Landis, the rasters of Wood Thrush density contain NA values for non-
#forested pixels in each study area.

#So what I will do is 1)extract the Landis raster outputs from each RData file,
#2) retrieve my own rasters of mean and SD current density of each study area,
#3) put my rasters and the Landis rasters in the same projection so that they can
#be stacked and related to each other, then 4) replace the NA values with my 
#values for those pixels.

#Some predicted densities (<<<1% of a study area's pixels) are unusually high 
#compared to observed Wood Thrush densities in real life in different areas
#These predicted densities are adjusted to a threshold density (currently 1.0)
#before creating the final filled-in rasters, estimating population sizes, and 
#identifying best-case, medium-case, and worst-case Zonation exercises. For an 
#example of where to change the threshold values, see line 85 in this script.

#Once I have a set of filled-in rasters, I can generate line plots to compare
#the outcomes of different scenarios, calculate population estimates in 2100 AD,
#and select a best-case, medium-case, and worst-case scenario for Zonation exercises.

###############################################
#                                             #
#                                             #
#              QUEBEC 123est                  #
#                                             #
#                                             #
###############################################

library(raster)
#load my mean and SD rasters
meanQuebec.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
sdQuebec.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_Quebec.tif")
plot(meanQuebec.current)
lcc_crs<-"+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.123est

NAsID.123est<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results/FillSDMeanFix_123est.tif")
#identifies which pixels in Landis outputs have NA values because they were not
#modelled in Landis simulations. Zeroes indicate NA. 
plot(NAsID.123est)

meanQuebec.current.lcc<-projectRaster(meanQuebec.current, NAsID.123est)
sdQuebec.current.lcc<-projectRaster(sdQuebec.current, NAsID.123est)
plot(meanQuebec.current.lcc)

meanQuebec.current.crop<-crop(meanQuebec.current.lcc, NAsID.123est)
meanQuebec.current.123est<-mask(meanQuebec.current.crop, NAsID.123est)
plot(meanQuebec.current.123est)

sdQuebec.current.crop<-crop(sdQuebec.current.lcc, NAsID.123est)
sdQuebec.current.123est<-mask(sdQuebec.current.crop, NAsID.123est)
plot(sdQuebec.current.123est)

#mask to the 123est study area to get rid of the the part of Ontario that was added
#to the Landis output from "meanQuebec.current.123est"
QuebecLandis<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/123est.ras.tif")

#generate list for scenario names
scenario<-c("baseline_BudwormBaselineFire",
            "baseline_BudwormBaselineFireBaselineHarvest",
            "RCP45_GrowthBudwormProjectedFire",
            "RCP45_GrowthBudwormProjectedFireBaselineHarvest",
            "RCP85_GrowthBudwormProjectedFire",
            "RCP85_GrowthBudwormProjectedFireBaselineHarvest")

landisResults<-list()#empty list each time we draw a new number of samples
k<-1

for (i in scenario){
  for (j in 1:5){
    load(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results/birddensityr_meansd_BS_123est_",i,"_",j,"_2100_WOTH.RData"))
    meanDensity.2100<-rasterstack_meansd$mean
    meanDensity.2100.filled<-cover(meanDensity.2100, meanQuebec.current.123est)
    meanDensity.2100.crop<-crop(meanDensity.2100.filled, QuebecLandis)
    meanDensity.2100.filledmasked<-mask(meanDensity.2100.crop, QuebecLandis)
    #some densities are unrealistically high 
    #reset these densities to a maximum threshold density based on observed densities
    #in studies. This threshold density can be changed if necessary.
    meanDensity.2100.adjusted<-meanDensity.2100.filledmasked
    meanDensity.2100.adjusted[meanDensity.2100.filledmasked>1]<-1
    #changes maximum density to 1. Replace the "1"s with another threshold if you want
    writeRaster(meanDensity.2100.adjusted, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/mean_BS_123est_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)

    sdDensity.2100<-rasterstack_meansd$sd
    sdDensity.2100.filled<-cover(sdDensity.2100, sdQuebec.current.123est)
    sdDensity.2100.crop<-crop(sdDensity.2100.filled, QuebecLandis)
    sdDensity.2100.filledmasked<-mask(sdDensity.2100.crop, QuebecLandis)
    writeRaster(sdDensity.2100.filledmasked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/sd_BS_123est_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    Year<-2100
    Scenario<-i
    Replicate<-j
    MeanDensity<-mean(values(meanDensity.2100.filledmasked),na.rm=TRUE)
    PopSize<-sum(values(meanDensity.2100.filledmasked),na.rm=TRUE)*6.25
    AdjustedMeanDensity<-mean(values(meanDensity.2100.adjusted),na.rm=TRUE)
    AdjustedPopSize<-sum(values(meanDensity.2100.adjusted),na.rm=TRUE)*6.25
    landisResults[[k]]<-data.frame(Year,Scenario,Replicate,MeanDensity,PopSize,AdjustedMeanDensity,AdjustedPopSize)#append temporary data frame at each loop iteration to the list
    k<-k+1
  }
}
drawnresults = do.call(rbind, landisResults)#bind data frames together
write.csv(drawnresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/DensityTotal.csv")

library(dplyr)
library(tidyr)
drawnresults<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/DensityTotal.csv", header=TRUE)
summresults<-drawnresults%>%
  group_by(Scenario)%>%
  summarize(PopulationSizeIn2100=mean(PopSize),
            AdjustedPopulationSizeIn2100=mean(AdjustedPopSize))
write.csv(summresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-123est-2021-results.filled/SummarizedPopulationSize.csv")

###############################################
#                                             #
#                                             #
#              QUEBEC 345ouest                #
#                                             #
#                                             #
###############################################

library(raster)
#load my mean and SD rasters
meanQuebec.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
sdQuebec.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_Quebec.tif")
plot(meanQuebec.current)
lcc_crs<-"+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.345ouest

NAsID.345ouest<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results/FillSDMeanFix_345ouest.tif")
#identifies which pixels in Landis outputs have NA values because they were not
#modelled in Landis simulations. Zeroes indicate NA. 
plot(NAsID.345ouest)

meanQuebec.current.lcc<-projectRaster(meanQuebec.current, NAsID.345ouest)
sdQuebec.current.lcc<-projectRaster(sdQuebec.current, NAsID.345ouest)
plot(meanQuebec.current.lcc)

meanQuebec.current.crop<-crop(meanQuebec.current.lcc, NAsID.345ouest)
meanQuebec.current.345ouest<-mask(meanQuebec.current.crop, NAsID.345ouest)
plot(meanQuebec.current.345ouest)

sdQuebec.current.crop<-crop(sdQuebec.current.lcc, NAsID.345ouest)
sdQuebec.current.345ouest<-mask(sdQuebec.current.crop, NAsID.345ouest)
plot(sdQuebec.current.345ouest)

#mask to the 345ouest study area to get rid of the the part of Ontario that was added
#to the Landis output from "meanQuebec.current.123est"
QuebecLandis<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/345ouest.ras.tif")

#generate list for scenario names
scenario<-c("baseline_BudwormBaselineFire",
            "baseline_BudwormBaselineFireBaselineHarvest",
            "RCP45_GrowthBudwormProjectedFire",
            "RCP45_GrowthBudwormProjectedFireBaselineHarvest",
            "RCP85_GrowthBudwormProjectedFire",
            "RCP85_GrowthBudwormProjectedFireBaselineHarvest")

landisResults<-list()#empty list each time we draw a new number of samples
k<-1

for (i in scenario){
  for (j in 1:5){
    load(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results/birddensityr_meansd_BS_345ouest_",i,"_",j,"_2100_WOTH.RData"))
    meanDensity.2100<-rasterstack_meansd$mean
    meanDensity.2100.filled<-cover(meanDensity.2100, meanQuebec.current.345ouest)
    meanDensity.2100.crop<-crop(meanDensity.2100.filled, QuebecLandis)
    meanDensity.2100.filledmasked<-mask(meanDensity.2100.crop, QuebecLandis)
    #some densities are unrealistically high 
    #reset these densities to a maximum threshold density based on observed densities
    #in studies. This threshold density can be changed if necessary.
    meanDensity.2100.adjusted<-meanDensity.2100.filledmasked
    meanDensity.2100.adjusted[meanDensity.2100.filledmasked>1]<-1
    #changes maximum density to 1. Replace the "1"s with another threshold if you want
    writeRaster(meanDensity.2100.adjusted, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/mean_BS_345ouest_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    
    sdDensity.2100<-rasterstack_meansd$sd
    sdDensity.2100.filled<-cover(sdDensity.2100, sdQuebec.current.345ouest)
    sdDensity.2100.crop<-crop(sdDensity.2100.filled, QuebecLandis)
    sdDensity.2100.filledmasked<-mask(sdDensity.2100.crop, QuebecLandis)
    writeRaster(sdDensity.2100.filledmasked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/sd_BS_345ouest_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    Year<-2100
    Scenario<-i
    Replicate<-j
    MeanDensity<-mean(values(meanDensity.2100.filledmasked),na.rm=TRUE)
    PopSize<-sum(values(meanDensity.2100.filledmasked),na.rm=TRUE)*6.25
    AdjustedMeanDensity<-mean(values(meanDensity.2100.adjusted),na.rm=TRUE)
    AdjustedPopSize<-sum(values(meanDensity.2100.adjusted),na.rm=TRUE)*6.25
    landisResults[[k]]<-data.frame(Year,Scenario,Replicate,MeanDensity,PopSize,AdjustedMeanDensity,AdjustedPopSize)#append temporary data frame at each loop iteration to the list
    k<-k+1
  }
}
drawnresults = do.call(rbind, landisResults)#bind data frames together
write.csv(drawnresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/DensityTotal.csv")

library(dplyr)
library(tidyr)
drawnresults<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/DensityTotal.csv", header=TRUE)
summresults<-drawnresults%>%
  group_by(Scenario)%>%
  summarize(PopulationSizeIn2100=mean(PopSize),
            AdjustedPopulationSizeIn2100=mean(AdjustedPopSize))
write.csv(summresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-345ouest-2021-results.filled/SummarizedPopulationSize.csv")


###############################################
#                                             #
#                                             #
#              QUEBEC 45est                   #
#                                             #
#                                             #
###############################################

library(raster)
#load my mean and SD rasters
meanQuebec.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_Quebec.tif")
sdQuebec.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_Quebec.tif")
plot(meanQuebec.current)
lcc_crs<-"+proj=lcc +lat_0=44 +lon_0=-68.5 +lat_1=46 +lat_2=60 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.45est

NAsID.45est<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results/FillSDMeanFix_45est.tif")
#identifies which pixels in Landis outputs have NA values because they were not
#modelled in Landis simulations. Zeroes indicate NA. 
plot(NAsID.45est)

meanQuebec.current.lcc<-projectRaster(meanQuebec.current, NAsID.45est)
sdQuebec.current.lcc<-projectRaster(sdQuebec.current, NAsID.45est)
plot(meanQuebec.current.lcc)

meanQuebec.current.crop<-crop(meanQuebec.current.lcc, NAsID.45est)
meanQuebec.current.45est<-mask(meanQuebec.current.crop, NAsID.45est)
plot(meanQuebec.current.45est)

sdQuebec.current.crop<-crop(sdQuebec.current.lcc, NAsID.45est)
sdQuebec.current.45est<-mask(sdQuebec.current.crop, NAsID.45est)
plot(sdQuebec.current.45est)

#mask to the 45est study area to get rid of the the part of Ontario that was added
#to the Landis output from "meanQuebec.current.123est"
QuebecLandis<-raster("3_BRT_outputs/Version 3 models/pred_CI/Zonation Inputs/45est.ras.tif")

#generate list for scenario names
scenario<-c("baseline_BudwormBaselineFire",
            "baseline_BudwormBaselineFireBaselineHarvest",
            "RCP45_GrowthBudwormProjectedFire",
            "RCP45_GrowthBudwormProjectedFireBaselineHarvest",
            "RCP85_GrowthBudwormProjectedFire",
            "RCP85_GrowthBudwormProjectedFireBaselineHarvest")

landisResults<-list()#empty list each time we draw a new number of samples
k<-1

for (i in scenario){
  for (j in 1:5){
    load(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results/birddensityr_meansd_BS_45est_",i,"_",j,"_2100_WOTH.RData"))
    meanDensity.2100<-rasterstack_meansd$mean
    meanDensity.2100.filled<-cover(meanDensity.2100, meanQuebec.current.45est)
    meanDensity.2100.crop<-crop(meanDensity.2100.filled, QuebecLandis)
    meanDensity.2100.filledmasked<-mask(meanDensity.2100.crop, QuebecLandis)
    #some densities are unrealistically high 
    #reset these densities to a maximum threshold density based on observed densities
    #in studies. This threshold density can be changed if necessary.
    meanDensity.2100.adjusted<-meanDensity.2100.filledmasked
    meanDensity.2100.adjusted[meanDensity.2100.filledmasked>1]<-1
    #changes maximum density to 1. Replace the "1"s with another threshold if you want
    writeRaster(meanDensity.2100.adjusted, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/mean_BS_45est_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    
    sdDensity.2100<-rasterstack_meansd$sd
    sdDensity.2100.filled<-cover(sdDensity.2100, sdQuebec.current.45est)
    sdDensity.2100.crop<-crop(sdDensity.2100.filled, QuebecLandis)
    sdDensity.2100.filledmasked<-mask(sdDensity.2100.crop, QuebecLandis)
    writeRaster(sdDensity.2100.filledmasked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/sd_BS_45est_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    Year<-2100
    Scenario<-i
    Replicate<-j
    MeanDensity<-mean(values(meanDensity.2100.filledmasked),na.rm=TRUE)
    PopSize<-sum(values(meanDensity.2100.filledmasked),na.rm=TRUE)*6.25
    AdjustedMeanDensity<-mean(values(meanDensity.2100.adjusted),na.rm=TRUE)
    AdjustedPopSize<-sum(values(meanDensity.2100.adjusted),na.rm=TRUE)*6.25
    landisResults[[k]]<-data.frame(Year,Scenario,Replicate,MeanDensity,PopSize,AdjustedMeanDensity,AdjustedPopSize)#append temporary data frame at each loop iteration to the list
    k<-k+1
  }
}
drawnresults = do.call(rbind, landisResults)#bind data frames together
write.csv(drawnresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/DensityTotal.csv")

library(dplyr)
library(tidyr)
drawnresults<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/DensityTotal.csv", header=TRUE)
summresults<-drawnresults%>%
  group_by(Scenario)%>%
  summarize(PopulationSizeIn2100=mean(PopSize),
            AdjustedPopulationSizeIn2100=mean(AdjustedPopSize))
write.csv(summresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-Quebec-45est-2021-results.filled/SummarizedPopulationSize.csv")




###############################################
#                                             #
#                                             #
#              NEW BRUNSWICK                  #
#                                             #
#                                             #
###############################################
library(maptools)
library(raster)
library(rgdal)
library(sp)

#load my mean and SD rasters
meanNewBrunswick.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_NewBrunswick.tif")
sdNewBrunswick.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_NewBrunswick.tif")
plot(meanNewBrunswick.current)
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.nb

NAsID.nb<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results/FillSDMeanFix_NewBrunswick.tif")
#identifies which pixels in Landis outputs have NA values because they were not
#modelled in Landis simulations. Zeroes indicate NA. 
plot(NAsID.nb)

#mask to the Landis study area to get rid of the the parts of other provinces 
#that are included with New Brunswick's current predicted densities
provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
NewBrunswick<-provs[provs$PRENAME=="New Brunswick",]
#needs to be reprojected to lcc_crs
NewBrunswickB<-spTransform(NewBrunswick, CRS=lcc_crs)


meanNewBrunswick.current.lcc<-projectRaster(meanNewBrunswick.current, NAsID.nb)
sdNewBrunswick.current.lcc<-projectRaster(sdNewBrunswick.current, NAsID.nb)
plot(meanNewBrunswick.current.lcc)
plot(sdNewBrunswick.current.lcc)

meanNewBrunswick.current.crop<-crop(meanNewBrunswick.current.lcc, NewBrunswickB)
meanNewBrunswick.current.landis<-mask(meanNewBrunswick.current.crop, NewBrunswickB)
plot(meanNewBrunswick.current.landis)

sdNewBrunswick.current.crop<-crop(sdNewBrunswick.current.lcc, NewBrunswickB)
sdNewBrunswick.current.landis<-mask(sdNewBrunswick.current.crop, NewBrunswickB)
plot(sdNewBrunswick.current.landis)

#generate list for scenario names
scenario<-c("baseline_BudwormBaselineFireBaselineHarvest",
            "RCP45_GrowthBudwormProjectedFireBaselineHarvest",
            "RCP85_GrowthBudwormProjectedFireBaselineHarvest")

landisResults<-list()#empty list each time we draw a new number of samples
k<-1

for (i in scenario){
  for (j in 1:5){
    load(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results/birddensityr_meansd_BS_NewBrunswick_",i,"_",j,"_2100_WOTH.RData"))
    meanDensity.2100<-rasterstack_meansd$mean
    meanDensity.2100.filled<-cover(meanDensity.2100, meanNewBrunswick.current.landis)
    meanDensity.2100.crop<-crop(meanDensity.2100.filled, NewBrunswickB)
    meanDensity.2100.filledmasked<-mask(meanDensity.2100.crop, NewBrunswickB)
    #some densities are unrealistically high 
    #reset these densities to a maximum threshold density based on observed densities
    #in studies. This threshold density can be changed if necessary.
    meanDensity.2100.adjusted<-meanDensity.2100.filledmasked
    meanDensity.2100.adjusted[meanDensity.2100.filledmasked>1]<-1
    #changes maximum density to 1. Replace the "1"s with another threshold if you want
    writeRaster(meanDensity.2100.adjusted, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/mean_BS_NewBrunswick_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    
    sdDensity.2100<-rasterstack_meansd$sd
    sdDensity.2100.filled<-cover(sdDensity.2100, sdNewBrunswick.current.landis)
    sdDensity.2100.crop<-crop(sdDensity.2100.filled, NewBrunswickB)
    sdDensity.2100.filledmasked<-mask(sdDensity.2100.crop, NewBrunswickB)
    writeRaster(sdDensity.2100.filledmasked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/sd_BS_NewBrunswick_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    Year<-2100
    Scenario<-i
    Replicate<-j
    MeanDensity<-mean(values(meanDensity.2100.filledmasked),na.rm=TRUE)
    PopSize<-sum(values(meanDensity.2100.filledmasked),na.rm=TRUE)*6.25
    AdjustedMeanDensity<-mean(values(meanDensity.2100.adjusted),na.rm=TRUE)
    AdjustedPopSize<-sum(values(meanDensity.2100.adjusted),na.rm=TRUE)*6.25
    landisResults[[k]]<-data.frame(Year,Scenario,Replicate,MeanDensity,PopSize,AdjustedMeanDensity,AdjustedPopSize)#append temporary data frame at each loop iteration to the list
    k<-k+1
  }
}
drawnresults = do.call(rbind, landisResults)#bind data frames together
write.csv(drawnresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/DensityTotal.csv")


library(dplyr)
library(tidyr)
drawnresults<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/DensityTotal.csv", header=TRUE)
summresults<-drawnresults%>%
  group_by(Scenario)%>%
  summarize(PopulationSizeIn2100=mean(PopSize),
            AdjustedPopulationSizeIn2100=mean(AdjustedPopSize))
write.csv(summresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NewBrunswick-results.filled/SummarizedPopulationSize.csv")

###############################################
#                                             #
#                                             #
#              NOVA SCOTIA                    #
#                                             #
#                                             #
###############################################
library(maptools)
library(raster)
library(rgdal)
library(sp)

#load my mean and SD rasters
meanNovaScotia.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/mean_WOTH_NovaScotiaSep2021.tif")
sdNovaScotia.current<-raster("3_BRT_outputs/Version 3 models/pred_CI/sd_WOTH_NovaScotiaSep2021.tif")
plot(meanNovaScotia.current)
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs and NAsID.ns

NAsID.ns<-raster("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results/FillSDMeanFix_NovaScotia.tif")
#identifies which pixels in Landis outputs have NA values because they were not
#modelled in Landis simulations. Zeroes indicate NA. 
plot(NAsID.ns)

#mask to the Landis study area to get rid of the the parts of other provinces 
#that are included with New Brunswick's current predicted densities
provs <-  readOGR("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
NovaScotia<-provs[provs$PRENAME=="Nova Scotia",]
#needs to be reprojected to lcc_crs
NovaScotiaB<-spTransform(NovaScotia, CRS=lcc_crs)


meanNovaScotia.current.lcc<-projectRaster(meanNovaScotia.current, NAsID.ns)
sdNovaScotia.current.lcc<-projectRaster(sdNovaScotia.current, NAsID.ns)
plot(meanNovaScotia.current.lcc)
plot(sdNovaScotia.current.lcc)

meanNovaScotia.current.crop<-crop(meanNovaScotia.current.lcc, NovaScotiaB)
meanNovaScotia.current.landis<-mask(meanNovaScotia.current.crop, NovaScotiaB)
plot(meanNovaScotia.current.landis)

sdNovaScotia.current.crop<-crop(sdNovaScotia.current.lcc, NovaScotiaB)
sdNovaScotia.current.landis<-mask(sdNovaScotia.current.crop, NovaScotiaB)
plot(sdNovaScotia.current.landis)

#generate list for scenario names
scenario<-c("baseline_BudwormBaselineFire",
            "RCP45_GrowthBudwormProjectedFire",
            "RCP85_GrowthBudwormProjectedFire",
            "baseline_BudwormBaselineFireEBFMHarvest",
            "RCP45_GrowthBudwormProjectedFireEBFMHarvest",
            "RCP85_GrowthBudwormProjectedFireEBFMHarvest",
            "baseline_BudwormBaselineFireHighCPRSHarvest",
            "RCP45_GrowthBudwormProjectedFireHighCPRSHarvest",
            "RCP85_GrowthBudwormProjectedFireHighCPRSHarvest")

landisResults<-list()#empty list each time we draw a new number of samples
k<-1

for (i in scenario){
  for (j in 1:5){
    load(paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results/birddensityr_meansd_BS_NovaScotia_",i,"_",j,"_2100_WOTH.RData"))
    meanDensity.2100<-rasterstack_meansd$mean
    meanDensity.2100.filled<-cover(meanDensity.2100, meanNovaScotia.current.landis)
    meanDensity.2100.crop<-crop(meanDensity.2100.filled, NovaScotiaB)
    meanDensity.2100.filledmasked<-mask(meanDensity.2100.crop, NovaScotiaB)
    #some densities are unrealistically high 
    #reset these densities to a maximum threshold density based on observed densities
    #in studies. This threshold density can be changed if necessary.
    meanDensity.2100.adjusted<-meanDensity.2100.filledmasked
    meanDensity.2100.adjusted[meanDensity.2100.filledmasked>1]<-1
    #changes maximum density to 1. Replace the "1"s with another threshold if you want
    writeRaster(meanDensity.2100.adjusted, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/mean_BS_NovaScotia_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    
    sdDensity.2100<-rasterstack_meansd$sd
    sdDensity.2100.filled<-cover(sdDensity.2100, sdNovaScotia.current.landis)
    sdDensity.2100.crop<-crop(sdDensity.2100.filled, NovaScotiaB)
    sdDensity.2100.filledmasked<-mask(sdDensity.2100.crop, NovaScotiaB)
    writeRaster(sdDensity.2100.filledmasked, filename=paste0("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/sd_BS_NovaScotia_",i,"_",j,"_2100_WOTH.tif"), overwrite=TRUE)
    Year<-2100
    Scenario<-i
    Replicate<-j
    MeanDensity<-mean(values(meanDensity.2100.filledmasked),na.rm=TRUE)
    PopSize<-sum(values(meanDensity.2100.filledmasked),na.rm=TRUE)*6.25
    AdjustedMeanDensity<-mean(values(meanDensity.2100.adjusted),na.rm=TRUE)
    AdjustedPopSize<-sum(values(meanDensity.2100.adjusted),na.rm=TRUE)*6.25
    landisResults[[k]]<-data.frame(Year,Scenario,Replicate,MeanDensity,PopSize,AdjustedMeanDensity,AdjustedPopSize)#append temporary data frame at each loop iteration to the list
    k<-k+1
  }
}
drawnresults = do.call(rbind, landisResults)#bind data frames together
write.csv(drawnresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/DensityTotal.csv")


library(dplyr)
library(tidyr)
drawnresults<-read.csv("3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/DensityTotal.csv", header=TRUE)
summresults<-drawnresults%>%
  group_by(Scenario)%>%
  summarize(PopulationSizeIn2100=mean(PopSize),
            AdjustedPopulationSizeIn2100=mean(AdjustedPopSize))
write.csv(summresults, file="3_BRT_outputs/Version 3 models/pred_CI/Landis-NovaScotia-results.filled/SummarizedPopulationSize.csv")

